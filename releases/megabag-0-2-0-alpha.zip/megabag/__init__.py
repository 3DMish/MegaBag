#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/data/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/data/m7a_nodes/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/data/m7a_quick_pack/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/data/m7a_tool_settings/");

from bpy_sys import ver_more, get_prop, data_path;

if ver_more(2,80,0): sys.path.insert(0, data_path + "/p2_80/");
else: sys.path.insert(0, data_path + "/p2_79/");

import m7a_props, m7a_nodes, m7a_quick_pack, m7a_custom_properties, m7a_dope_sheet;
import m7a_view3d_header, m7a_keyboard, m7a_text_editor, m7a_modifiers;

if ver_more(2,80,0):
    import m7a_tool_settings;

bl_info = {
    "name":        "MegaBag v0.2.0-Alpha",
    "category":    "3DMish",
    "author":      "3DMish (Mish7913)",
    "version":     (0, 2, "0-Alpha-2023.02.13-08.50"),
    "blender":     (3, 3, 0),
    "wiki_url":    "https://3dmish.blogspot.com/p/megabag-wiki-en.html",
    "warning":     "It's an alpha version, can be a bugs in here.",
    "description": "MegaBag - it's a mega pack of different stuff...",
}

def register():
    m7a_props.register();
    m7a_keyboard.register();
    m7a_custom_properties.register();
    
    if get_prop("view3d_upgrade_header"):
        m7a_view3d_header.register();
        if ver_more(2,80,0):
            if (get_prop("view3d_tool_header")): m7a_tool_settings.register();
        
    if (get_prop("text_editor_upgrade")): m7a_text_editor.register();
    if (get_prop("view3d_quick_pack")):   m7a_quick_pack.register();
    if (get_prop("dope_sheet_upgrade")):  m7a_dope_sheet.register();
    if (get_prop("modifiers_upgrade")):   m7a_modifiers.register();
    if (get_prop("node_editor")):         m7a_nodes.register();

def unregister():
    m7a_props.unregister();             m7a_keyboard.unregister();
    m7a_view3d_header.unregister();     m7a_dope_sheet.unregister();
    m7a_custom_properties.unregister(); m7a_text_editor.unregister();
    m7a_quick_pack.unregister();        m7a_nodes.unregister();
    m7a_modifiers.unregister();
    
    if ver_more(2,80,0):
        m7a_tool_settings.unregister();
    
if __name__ == "__main__": register();

# -----------------------------------------------------------

#import os # GET RAM INFO
## Getting all memory using os.popen()
#total_memory, used_memory, free_memory = map(
#    int, os.popen('free -t -m').readlines()[-1].split()[1:])
## Memory usage
#print("RAM memory % used:", round((used_memory/total_memory) * 100, 2))
