#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Scene;
from bpy.props import BoolProperty;

from bpy_sys import (
    q_register_class, q_unregister_class, r_remove_attr,
    lc_panel, lc_cont_x,
);

def draw_panel (lc_main, context):
    a_obj = context.active_object;
    lc_box, lc_label_row, is_open = lc_panel(
        lc_main, context, "m7a_show_asset_props", "Asset Properties", "PROPERTIES", True,
    ); 
    if (is_open):
        lc_label_row.label(text="", icon="PROPERTIES");
        def lc_template_item(lc_cont, text, icon = None, data = None, props = None):
            lc_cont = lc_cont.column(align=True);
            lc_row = lc_cont.box().row(align=True);
            if (icon != None): lc_row.label(text=text, icon=icon);
            else: lc_row.label(text=text);
            if (data != None) and (props != None):
                lc_cont_x(lc_row, 0.5).prop(data, props,  text="", toggle=True, slider=True);
            return lc_cont.box().column(align=True);
            
        if ("M7A Pizza" in a_obj.modifiers):
            asset = a_obj.modifiers["M7A Pizza"];
            
            lc_box.prop(asset, '["Input_3"]', text="Radius");
            lc_box.prop(asset, '["Input_8"]', text="Seed");
            
            lc_box.separator();
            
            lc_row_box = lc_template_item(lc_box, text="Tomatos:", data=asset, props='["Input_11"]');
            lc_row_box.active = asset["Input_11"] == 1;
            lc_row_box.prop(asset, '["Input_14"]', text="Rotate");
            lc_row_box.prop(asset, '["Input_5"]', text="Seed");
            
            lc_box.separator();
            
            lc_row_box = lc_template_item(lc_box, text="Cheese on Top:", data=asset, props='["Input_12"]');
            lc_row_box.active = asset["Input_12"] == 1;
            lc_row_box.prop(asset, '["Input_15"]', text="Rotate");
            lc_row_box.prop(asset, '["Input_13"]', text="Seed");
            
            lc_box.separator();
            
            lc_row_box = lc_template_item(lc_box, text="Basils:", data=asset, props='["Input_17"]');
            lc_row_box.active = asset["Input_17"] == 1;
            lc_row_box.prop(asset, '["Input_19"]', text="Rotate");
            lc_row_box.prop(asset, '["Input_18"]', text="Seed");

classes = [
    
];

def register():
    Scene.m7a_show_asset_props = BoolProperty(name="Asset Properties");
    
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
    
    r_remove_attr(Scene, "m7a_show_asset_props");
