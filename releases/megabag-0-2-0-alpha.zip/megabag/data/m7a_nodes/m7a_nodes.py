#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys, nodeitems_utils;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Menu;

from bpy_sys import (
    r_register_class, r_unregister_class, q_register_class, q_unregister_class, ver_more,
    get_prop,
);

from bpy.app.translations import (contexts as i18n_contexts);

bl_conf = {
    "NODE_MT_add": None,
    "NODE_MT_category_SH_NEW_OP_VECTOR": None,
    "NODE_MT_category_SH_NEW_OP_COLOR": None,
}

class NODE_MT_add (Menu):
    bl_space_type = 'NODE_EDITOR';
    bl_label = "Add";
    bl_translation_context = i18n_contexts.operator_default;
    
    def draw(self, context):
        lc_main = self.layout;
        lc_main.operator_context = 'INVOKE_REGION_WIN'

        lc_props = lc_main.operator("node.add_search", text="Search...", icon='VIEWZOOM');
        
        if context.space_data.tree_type == 'GeometryNodeTree':
            lc_main.separator();
            
            #lc_main.menu_contents("NODE_MT_geometry_node_add_all");
            #nodeitems_utils.draw_node_categories_menu(self, context);
            
            identifiers = []; 
                
            if ver_more(2,92,0):
                identifiers.append(("GEO_ATTRIBUTE", "COPY_ID", 2));
                identifiers.append(("GEO_COLOR", "COLOR", 2));
                if ver_more(3,0,0):
                    identifiers.append(("GEO_CURVE", "MOD_CURVE", 2));
                    identifiers.append(("GEO_PRIMITIVES_CURVE", "CURVE_BEZCURVE", 2));
                    if ver_more(3,4,1):
                        identifiers.append(("curve_topology", "NORMALIZE_FCURVES", 2));
                identifiers.append(("GEO_GEOMETRY", "OBJECT_DATA", 2));
                identifiers.append(("GEO_INPUT", "IMPORT", 2));
                if ver_more(3,0,0):
                    identifiers.append(("GEO_OUTPUT", "EXPORT", 1));
                    identifiers.append(("GEO_INSTANCE", "MOD_INSTANCE", 2));
                    identifiers.append(("GEO_MATERIAL", "SHADING_RENDERED", 2));
                identifiers.append(("GEO_MESH", "MESH_DATA", 2));
                if ver_more(3,0,0):
                    if ver_more(3,4,1): identifiers.append(("PRIMITIVES_MESH", "MESH_ICOSPHERE", 1));
                    else: identifiers.append(("GEO_PRIMITIVES_MESH", "MESH_CUBE", 1));
                    if ver_more(3,4,1):
                        identifiers.append(("mesh_topology", "MOD_MESHDEFORM", 2));
                identifiers.append(("GEO_POINT", "POINTCLOUD_DATA", 1));
                if ver_more(3,0,0):
                    identifiers.append(("GEO_TEXT", "SMALL_CAPS", 1));
                    identifiers.append(("GEO_TEXTURE", "TEXTURE", 1));
                identifiers.append(("GEO_UTILITIES", "SEQ_SPLITVIEW", 1));
                if ver_more(3,3,0):
                    identifiers.append(("GEO_UV", "UV", 1));
                identifiers.append(("GEO_VECTOR", "DRIVER_ROTATIONAL_DIFFERENCE", 1));
                if ver_more(3,0,0):
                    identifiers.append(("GEO_VOLUME", "OUTLINER_DATA_VOLUME", 1));
                    identifiers.append(("GEO_LAYOUT", "NODE", 1));
                    
            for identifier, icon, i341 in identifiers:
                if ver_more(3,4,1) and (i341 == 2):
                    if (icon == None): lc_main.menu("NODE_MT_geometry_node_%s" % identifier);
                    else: lc_main.menu("NODE_MT_geometry_node_%s" % identifier, icon=icon);
                else:
                    if (icon == None): lc_main.menu("NODE_MT_category_%s" % identifier);
                    else: lc_main.menu("NODE_MT_category_%s" % identifier, icon=icon);
            
            lc_main.separator();
                
            lc_main.menu("NODE_MT_category_GEO_GROUP", icon="COLOR_GREEN");
                
        else:
            lc_props.use_transform = True;

            lc_main.separator();
            
            ui_type = context.area.ui_type if ver_more(2,85,0) else context.area.spaces.active.tree_type;

            if (ui_type == "ShaderNodeTree"):
                
                if ver_more(2,83,0):
                    icons = ["IMPORT", "EXPORT", "SHADING_RENDERED", "TEXTURE", "COLOR", 
                             "DRIVER_ROTATIONAL_DIFFERENCE", "CON_CHILDOF", "FILE_SCRIPT", "NODE"];
                else:
                    icons = ["IMPORT", "EXPORT", "SMOOTH", "TEXTURE", "COLOR", 
                             "AXIS_TOP", "RETOPO", "FILE_SCRIPT", "NODE"];

                
                for i, identifier in enumerate(["INPUT",     "OUTPUT",    "SHADER", "TEXTURE", "OP_COLOR", 
                                                "OP_VECTOR", "CONVERTOR", "SCRIPT", "LAYOUT"]):
                    if (icons == None): lc_main.menu("NODE_MT_category_SH_NEW_%s" % identifier);
                    else: lc_main.menu("NODE_MT_category_SH_NEW_%s" % identifier, icon=icons[i]);
                
                lc_main.separator();
                
                lc_main.menu("NODE_MT_category_SH_NEW_GROUP", icon="COLOR_GREEN" if ver_more(2,83,0) else "NODETREE");
                
            else:
                # actual node submenus are defined by draw functions from node categories
                nodeitems_utils.draw_node_categories_menu(self, context);

def lc_draw_item (lc_cont, label, nodetype):
    lc_props = lc_cont.operator("node.add_node", text=label, text_ctxt=i18n_contexts.operator_default)
    lc_props.type = nodetype;
    lc_props.use_transform = True;

class NODE_MT_category_SH_NEW_OP_VECTOR (Menu):
    bl_label = "Vector";
    
    def draw(self, context):
        lc_main = self.layout;
        
        lc_draw_item(lc_main, "Bump",         "ShaderNodeBump");
        lc_draw_item(lc_main, "Displacement", "ShaderNodeDisplacement");
        lc_draw_item(lc_main, "Mapping",      "ShaderNodeMapping");
        
        if ver_more(2,85,0) and get_prop("node_shader_groups") and get_prop("node_noise_mapping"):
            lb_btn = lc_main.operator("node.add_m7a_node", text="Noise Mapping", icon="COLOR_GREEN");
            lb_btn.hint = "Transform the input vector by applying noise transform, rotation, and scale";
            lb_btn.node = "M7A Noise Mapping"; lb_btn.type = "ShaderNodeGroup";
        
        lc_draw_item(lc_main, "Normal",              "ShaderNodeNormal");
        lc_draw_item(lc_main, "Normal Map",          "ShaderNodeNormalMap");
        lc_draw_item(lc_main, "Vector Curve",        "ShaderNodeVectorCurve");
        lc_draw_item(lc_main, "Vector Displacement", "ShaderNodeVectorDisplacement");
        lc_draw_item(lc_main, "Vector Rotate",       "ShaderNodeVectorRotate");
        lc_draw_item(lc_main, "Vector Transform",    "ShaderNodeVectorTransform");

class NODE_MT_category_SH_NEW_OP_COLOR (Menu):
    bl_label = "Color";
    
    def draw(self, context):
        lc_main = self.layout;
        
        lc_draw_item(lc_main, "Bright Contrast",      "ShaderNodeBrightContrast");
        lc_draw_item(lc_main, "Gamma",                "ShaderNodeGamma");
        lc_draw_item(lc_main, "Hue Saturation Value", "ShaderNodeHueSaturation");
        lc_draw_item(lc_main, "Invert",               "ShaderNodeInvert");
        lc_draw_item(lc_main, "Light Falloff",        "ShaderNodeLightFalloff");
        lc_draw_item(lc_main, "MixRGB",               "ShaderNodeMixRGB");
        
        if get_prop("node_shader_groups") and get_prop("node_distance_rgb"):
            icon="COLOR_GREEN" if ver_more(2,83,0) else "NODETREE";
            lb_btn = lc_main.operator("node.add_m7a_node", text="MixRGB by Distance", icon=icon);
            lb_btn.hint = "Mixing RGB by Distance"; lb_btn.node = "M7A MixRGB by Distance";
            lb_btn.type = "ShaderNodeGroup";
        
        lc_draw_item(lc_main, "RGB Curve", "ShaderNodeRGBCurve");

def register_nodes (self, context):
    if (get_prop("node_editor")): register();
    else: unregister();

classes = [
    NODE_MT_category_SH_NEW_OP_VECTOR,
    NODE_MT_category_SH_NEW_OP_COLOR,
    NODE_MT_add,
];

def register ():
    global bl_conf;
    
    r_unregister_class(bl_conf, "NODE_MT_add");
    r_unregister_class(bl_conf, "NODE_MT_category_SH_NEW_OP_VECTOR");
    r_unregister_class(bl_conf, "NODE_MT_category_SH_NEW_OP_COLOR");
    
    q_register_class(classes);
    
def unregister ():
    global bl_conf;
    
    q_unregister_class(classes);
    
    r_register_class(bl_conf, "NODE_MT_category_SH_NEW_OP_COLOR");
    r_register_class(bl_conf, "NODE_MT_category_SH_NEW_OP_VECTOR");
    r_register_class(bl_conf, "NODE_MT_add");
