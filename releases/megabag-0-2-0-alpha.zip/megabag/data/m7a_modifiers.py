#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import sys, os;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");

from bpy.types import Panel, Menu;

from bpy_sys import (
    q_register_class, q_unregister_class, ver_less, ver_more,
    r_register_class, r_unregister_class, get_prop, lc_icon,
    bpy_preferences, addon_id, lc_cont_x,
);

if ver_less(2,80,0): import m7a_templates;

bl_conf = {
    "DATA_PT_modifiers": None,
    "DATA_PT_gpencil_modifiers": None,
}

class DATA_PT_modifiers (Panel):
    bl_space_type  = 'PROPERTIES';
    bl_region_type = 'WINDOW';
    bl_label       = "M7A Modifiers";
    bl_context     = "modifier";
    bl_options     = {'HIDE_HEADER'};

    def draw(self, context):
        lc_main = self.layout.column(align = False);
        lc_type = context.object.type;
        m7a_megabag_props = bpy_preferences("addons", addon_id).m7a_props;
        
        lc_row = lc_main.row(align = True);
        if (lc_type not in {"GPENCIL"}): lc_row.operator_menu_enum("object.modifier_add", "type");
        else: lc_row.operator_menu_enum("object.gpencil_modifier_add", "type");
        
        if (m7a_megabag_props.modifiers_options):
            lc_cont_x(lc_row, 0.8).menu("M7A_DATA_MT_MOD_options", icon="COLLAPSEMENU", text="Options");
        
        if (lc_type in {"MESH", "CURVE"}):
            if ver_more(3,0,0) and (m7a_megabag_props.modifiers_m7a_pack):
                lc_row = lc_main.row(align = True);
                lc_row.menu("M7A_DATA_MT_MOD_menu");
        
        gp_len = len(context.object.grease_pencil_modifiers) if ver_more(3,0,0) else 10;
        if (len(context.object.modifiers) < 1) and (gp_len < 1):
            lc_main.separator();
            lc_main_box = lc_main.row();
            lc_main_box.alignment = "CENTER";
            lc_main_box.label(text="Object don't have a modifiers");
        
        if ver_more(2,90,0):
            if (lc_type not in {"GPENCIL"}): lc_main.template_modifiers();
            else: lc_main.template_grease_pencil_modifiers();
        else:
            lc_main.separator();
            m7a_templates.modifiers(lc_main, context);

class M7A_DATA_MT_MOD_options (Menu):
    bl_idname      = 'M7A_DATA_MT_MOD_options';
    bl_label       = "Modifier's Options";
    bl_description = '';
        
    @staticmethod
    def draw(self, context):
        lc_main = self.layout.column(align = False);
        
        lc_pic = "FILE_TICK" if (ver_less(2,90,0)) else "CHECKMARK";
        lc_btn = lc_main.operator('object.modifiers_option', icon=lc_pic, text="Apply All");
        lc_btn.option = "MOD_APPLY_ALL"; lc_btn.hint = "Apply all modifiers visible in viewport";
        
        lc_main.separator();
        
        lc_btn = lc_main.operator('object.modifiers_option', icon='RESTRICT_VIEW_OFF', text="Viewport: All ON");
        lc_btn.option = "MOD_VIEWPORT_ON"; lc_btn.hint = "Turn-ON visible in viewport all modifiers";
        
        lc_btn = lc_main.operator('object.modifiers_option', icon='RESTRICT_VIEW_ON', text="Viewport: All OFF");
        lc_btn.option = "MOD_VIEWPORT_OFF"; lc_btn.hint = "Turn-OFF visible in viewport all modifiers";
        
        lc_btn = lc_main.operator('object.modifiers_option', icon='RESTRICT_SELECT_OFF', text="Viewport: All Toggle");
        lc_btn.option = "MOD_VIEWPORT_TOGGLE"; lc_btn.hint = "Toggle visible in viewport all modifiers";
        
        lc_main.separator();
        
        lc_btn = lc_main.operator('object.modifiers_option', icon='RESTRICT_RENDER_OFF', text="Render: All ON");
        lc_btn.option = "MOD_RENDER_ON"; lc_btn.hint = "Turn-ON visible for render all modifiers";
        
        lc_btn = lc_main.operator('object.modifiers_option', icon='RESTRICT_RENDER_ON', text="Render: All OFF");
        lc_btn.option = "MOD_RENDER_OFF"; lc_btn.hint = "Turn-OFF visible for render all modifiers";
        
        lc_btn = lc_main.operator('object.modifiers_option', icon='RESTRICT_SELECT_OFF', text="Render: All Toggle");
        lc_btn.option = "MOD_RENDER_TOGGLE"; lc_btn.hint = "Toggle visible for render all modifiers";
        
        lc_main.separator();
        
        lc_pic = 'TRASH' if (ver_more(2,90,0)) else 'X';
        
        lc_btn = lc_main.operator('object.modifiers_option', icon=lc_pic, text="Remove: Viewport OFF");
        lc_btn.option = "MOD_REMOVE_VIEW"; lc_btn.hint = "Delete all dasabled viewport modifiers";
        
        lc_btn = lc_main.operator('object.modifiers_option', icon=lc_pic, text="Remove: Render OFF");
        lc_btn.option = "MOD_REMOVE_RENDER"; lc_btn.hint = "Delete all dasabled render modifiers";
        
        lc_main.separator();
        
        lc_btn = lc_main.operator('object.modifiers_option', icon=lc_pic, text="Remove: All");
        lc_btn.option = "MOD_REMOVE_ALL"; lc_btn.hint = "Delete all modifiers";

class M7A_DATA_PT_Modifiers_Menu (Menu):
    bl_idname      = 'M7A_DATA_MT_MOD_menu';
    bl_label       = 'Add GeoNodes Modifier';
    bl_description = 'Add M7A GeoNodes Modifier';
    
    @staticmethod
    def draw(self, context):
        lc_main_row = self.layout.row(align = False);
        
        if (context.object.type == "MESH"):
            lc_col_1 = lc_main_row.column(align = True);
            lc_col_1.label(text="Generate");
            lc_col_1.separator();
            
            if (get_prop("m7a_vector_array")): 
                lc_btn = lc_col_1.operator('object.geonode_add', icon='MOD_ARRAY', text="Vector Array");
                lc_btn.hint = "Add modifier 'Vector Array' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Vector Array";
            
            if (get_prop("m7a_circle_array")): 
                lc_btn = lc_col_1.operator('object.geonode_add', text="Circle Array", icon_value=lc_icon("CIRCLE_ARRAY"));
                lc_btn.hint = "Add modifier 'Circle Array' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Circle Array";
            
            if (get_prop("m7a_flower")): 
                lc_btn = lc_col_1.operator('object.geonode_add', text="Flower", icon_value=lc_icon("FLOWER"));
                lc_btn.hint = "Add modifier 'Flower' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Flower";
            
            if (get_prop("m7a_beads")): 
                lc_btn = lc_col_1.operator('object.geonode_add', text="Beads Wireframe", icon_value=lc_icon("BEADS_WIREFRAME"));
                lc_btn.hint = "Add modifier 'Beads Wireframe' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Beads Wireframe";
            
            lc_col_2 = lc_main_row.column(align = True);
            lc_col_2.label(text="Create");
            lc_col_2.separator();
            
            if (get_prop("m7a_icing")): 
                lc_btn = lc_col_2.operator('object.geonode_add', icon='FREEZE', text="Icing");
                lc_btn.hint = "Add modifier 'Icing' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Icing";
            
            if (get_prop("m7a_frosting")): 
                lc_btn = lc_col_2.operator('object.geonode_add', text="Frosting", icon_value=lc_icon("FROSTING"));
                lc_btn.hint = "Add modifier 'Frosting' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Frosting";
            
            if (get_prop("m7a_sprinkles")): 
                lc_btn = lc_col_2.operator('object.geonode_add', text="Sprinkles", icon_value=lc_icon("SPRINKLES"));
                lc_btn.hint = "Add modifier 'Sprinkles' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Sprinkles";
            
            if (get_prop("m7a_cherry_on")): 
                lc_btn = lc_col_2.operator('object.geonode_add', text="Cherry on Top", icon_value=lc_icon("CHERRY"));
                lc_btn.hint = "Add modifier 'Cherry on Top' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Cherry on Top";
            
            #lc_btn = lc_col_2.operator('object.geonode_add', icon_value=lc_icon["ELECTRIC"], text="Electricity Lightning (!)");
            #lc_btn.option = "ADD_M7A_MODIFIER"; lc_btn.data = "";
            #lc_btn_description(lc_btn, "Add modifier 'Electricity Lightning' based on geometry nodes");

            lc_col_3 = lc_main_row.column(align = True);
            lc_col_3.label(text="Deform");
            lc_col_3.separator();
            
            if (get_prop("m7a_m_noise")): 
                lc_btn = lc_col_3.operator('object.geonode_add', icon='MOD_NOISE', text="Noise");
                lc_btn.hint = "Add modifier 'Noise' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Mesh Noise";
            
        elif (context.object.type == "CURVE"):
            lc_col_1 = lc_main_row.column(align = True);
            lc_col_1.label(text="Generate");
            lc_col_1.separator();
            
            if (get_prop("m7a_elec_arc")): 
                lc_btn = lc_col_1.operator('object.geonode_add', text="Electricity Arc", icon_value=lc_icon("ELECTRIC"));
                lc_btn.hint = "Add modifier 'Electricity Arc' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Electricity Arc";
            
            #lc_btn = lc_col_1.operator('object.geonode_add', icon_value=lc_icon["LIGHTNING"], text="Lightning (!)");
            #lc_btn.option = "ADD_M7A_MODIFIER"; lc_btn.data = "";
            #lc_btn_description(lc_btn, "Lightning' based on geometry nodes");
            
            lc_col_2 = lc_main_row.column(align = True);
            lc_col_2.label(text="Create");
            lc_col_2.separator();
            
            if (get_prop("m7a_chain")): 
                lc_btn = lc_col_2.operator('object.geonode_add', icon='LINKED', text="Chain");
                lc_btn.hint = "Add modifier 'Chain' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Chain";
            
            lc_col_3 = lc_main_row.column(align = True);
            lc_col_3.label(text="Deform");
            lc_col_3.separator();
            
            if (get_prop("m7a_c_noise")): 
                lc_btn = lc_col_3.operator('object.geonode_add', icon='MOD_NOISE', text="Noise");
                lc_btn.hint = "Add modifier 'Noise' based on geometry nodes";
                lc_btn.node = "M7A GeoNodes Curve Noise";

def register_nodes (self, context):
    if (get_prop("modifiers_upgrade")): register();
    else: unregister();

classes = (
    DATA_PT_modifiers, M7A_DATA_MT_MOD_options,
    M7A_DATA_PT_Modifiers_Menu,
);

def register():
    global bl_conf;
    
    r_unregister_class(bl_conf, "DATA_PT_modifiers");
    r_unregister_class(bl_conf, "DATA_PT_gpencil_modifiers");
    
    q_register_class(classes);
    
def unregister():
    global bl_conf;
    
    q_unregister_class(classes);
    
    r_register_class(bl_conf, "DATA_PT_modifiers");
    r_register_class(bl_conf, "DATA_PT_gpencil_modifiers");
