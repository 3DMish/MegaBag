#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Scene, Operator;
from bpy.props import BoolProperty;

from bpy_sys import (
    q_register_class, q_unregister_class, r_remove_attr,
    lc_panel, ver_less, lc_center_label,
);

def draw_panel (lc_main, context):
    lc_box, lc_label_row, is_open = lc_panel(
        lc_main, context, "m7a_show_custom_props", "Custom Properties", "PROPERTIES", True,
    );
    if (is_open):
        lc_label_row.operator("object.properties_add", text="", icon="ADD");
        lc_props = 0;
        
        def add_item (lc_box, prop_path, item, int_props):
            lc_row = lc_box.row(align = True);
            
            lc_prop_item = eval("bpy.context.%s" % prop_path)[item];
            lc_btn_row = lc_row.row(align = True);
            if hasattr(lc_prop_item, "to_dict") or hasattr(lc_prop_item, "to_list"):
                lc_btn = lc_btn_row.operator("wm.empty", text=item);
                lc_btn.hint = "[%s] Items" % str(len(lc_prop_item));
            else:
                if hasattr(lc_prop_item, "upper"):
                    props = lc_row.operator("wm.properties_edit_value", text=item);
                    props.data_path = prop_path; props.property_name = item;
                elif hasattr(lc_prop_item, "is_integer") or hasattr(lc_prop_item, "to_bytes"):
                    lc_row.prop(eval("bpy.context.%s" % prop_path), '["%s"]' % item);
                else:
                    if hasattr(lc_prop_item, "sort"):
                        lc_btn = lc_btn_row.operator("wm.empty", text=item);
                        lc_btn.hint = "Array [%s] Items" % str(len(lc_prop_item));
                    else:
                        lc_btn = lc_btn_row.operator("wm.empty", text=item);
                        lc_btn.hint = "Array [%s] Items" % str(len(lc_prop_item));
            lc_btn_row.active = False;
            
            props = lc_row.operator("wm.properties_edit", text="", icon='PREFERENCES');
            props.data_path = prop_path;
            if ver_less(3,0,0): props.property = item;
            else: props.property_name = item;
            
            props = lc_row.operator("wm.properties_remove", text="", icon='X');
            props.data_path = prop_path;
            if ver_less(3,0,0): props.property = item;
            else: props.property_name = item;
            
            return int_props + 1;
        
        if (bpy.context.object):
            
            items = list(context.object.keys());
            items.sort();
            
            if not (items == []):
                lc_label = lc_box.row(); lc_len = 0;
                for item in items:
                    if (item not in {"m7a_gpencil_library", "m7a_gpencil_list"}):
                        lc_props = add_item(lc_box, 'object', item, lc_props);
                        lc_len += 1;
                
                if (lc_len > 0): lc_label.label(text="Object", icon="LAYER_USED");
                
            items = list(context.object.data.keys());
            items.sort();
            
            if not (items == []):
                lc_label = lc_box.row(); lc_len = 0;
                for item in items:
                    if (item not in {"m7a_gpencil_library", "m7a_gpencil_list", "m7a_asset"}):
                        lc_props = add_item(lc_box, 'object.data', item, lc_props);
                        lc_len += 1;
                
                if (lc_len > 0): lc_label.label(text="Data", icon="LAYER_USED");
                
            if (context.object.type == 'ARMATURE') and (context.active_pose_bone):
                items = list(context.active_pose_bone.keys());
                items.sort();
                
                if not (items == []) and (context.mode in {'POSE'}):
                    lc_label = lc_box.row(); lc_len = 0;
                    for item in items:
                        if (item not in {"gpencil_library"}):
                            lc_props = add_item(lc_box, 'active_pose_bone', item, lc_props);
                            lc_len += 1;
                    
                    if (lc_len > 0): lc_label.label(text="Bone", icon="LAYER_USED");
                
        if (lc_props == 0): lc_center_label(lc_box, "No properties in object").active=False;

class OBJECT_PROPERTIES_add (Operator):
    bl_idname       = 'object.properties_add';
    bl_label        = 'Add Custom Property';
    bl_description  = 'Add custom property to the object';
    
    @staticmethod
    def draw(self, context):
        lc_main = self.layout.column(align = True);
        lc_main.operator("wm.properties_add", text="to Object").data_path = "object";
        lc_main.operator("wm.properties_add", text="to Data").data_path = "object.data";
        if (context.object.type == 'ARMATURE') and (context.selected_pose_bones) and (context.active_pose_bone):
            lc_main.operator("wm.properties_add", text="to Bone").data_path = "active_pose_bone";
        
    def invoke(self, context, event):
        context.window_manager.invoke_popup(self, width=100);
        return {'RUNNING_MODAL'}
        
    def execute(self, context): return {'FINISHED'};

classes = [
    OBJECT_PROPERTIES_add,
];

def register():
    Scene.m7a_show_custom_props = BoolProperty(name="Custom Properties");
    
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
    
    r_remove_attr(Scene, "m7a_show_custom_props");
