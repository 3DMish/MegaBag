#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy_sys import (
    q_register_class, q_unregister_class, lc_icon,
);

def draw_panel (lc_main, context):
    lc_main.label(text="Mesh:", icon="MESH_DATA");
    
    lc_main.separator_spacer();
    
    if (context.mode in {"OBJECT"}): #-------------------------------------------------
    
        lc_main.operator_menu_enum("object.origin_set", text="Set Origin", property="type");
        lc_main.operator_menu_enum("object.apply", "props", icon="NONE");
        
        lc_main.separator();

        lc_main.operator("object.duplicate_move", text="", icon_value=lc_icon("DUP_MOVE"));
        lc_main.operator("object.duplicate_move_linked", text="", icon_value=lc_icon("DUPLICATE_LINKED"));
        
        lc_btn = lc_main.row(align = True);
        lc_btn.operator("object.join", icon="FORCE_LENNARDJONES", text="");
        lc_btn.active = len(context.selected_objects) > 1;
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 4.5;
        lc_row.prop(context.active_object, "display_type", text="", icon="VIS_SEL_10");
        
        lc_main.separator();
        
        lc_main.operator("view3d.snap_selected_to_cursor", text="", icon="ORIENTATION_CURSOR").use_offset=True;
    
    elif (context.mode in {"EDIT_MESH"}): #-------------------------------------------------
    
        lc_main.operator("mesh.intersect_boolean", icon="MOD_BOOLEAN", text="");
        lc_main.operator("mesh.blend_from_shape", text="", icon="SHAPEKEY_DATA");
        lc_main.operator("mesh.subdivide", icon="MOD_SUBSURF", text="").smoothness=1;
        lc_main.operator("mesh.unsubdivide", text="", icon="MOD_DECIM").iterations = 2;
        lc_main.operator("mesh.vertices_smooth", icon="MOD_SMOOTH", text="").factor=0.5;
        
        lc_main.separator();
        
        lc_main.operator("view3d.edit_mesh_extrude_move_shrink_fatten", text="", icon_value=lc_icon("EXTRUDE_NORMALS"));
        lc_btn = lc_main.operator("view3d.edit_mesh_extrude_move_normal", text="", icon_value=lc_icon("EXTRUDE_INTERSECT"));
        lc_btn.dissolve_and_intersect = True;
        lc_main.operator("mesh.inset", text="", icon_value=lc_icon("INSET"));
        
        if (context.region.width > 840): 
            lc_main.separator();
            lc_btn = lc_main.operator("mesh.quads_convert_to_tris", text="", icon="MOD_TRIANGULATE");
            lc_btn.quad_method="BEAUTY"; lc_btn.ngon_method="BEAUTY";
            lc_main.operator("mesh.tris_convert_to_quads", text="", icon_value=lc_icon("TO_QUADS"));
            
        if (context.region.width > 750): 
            lc_main.separator();
            lc_main.operator_menu_enum("mesh.merge", "type", text="Merge", icon="AUTOMERGE_ON");
            if (context.region.width > 860): lc_main.operator("mesh.merge", text="", icon="CENTER_ONLY").type="CENTER";
            lc_main.operator("mesh.remove_doubles", text="", icon="CON_DISTLIMIT");
            if (context.region.width > 800): lc_main.operator("mesh.edge_split", text="", icon="MOD_EDGESPLIT").type = 'EDGE';
        
        if (context.region.width > 820): 
            lc_main.separator();
            lc_main.menu("VIEW3D_MT_hook", text="", icon="HOOK");
        
        lc_main.separator();
        
        lc_main.operator("mesh.knife_tool", text="", icon_value=lc_icon("KNIFE"));
        
        lc_main.separator();
        
        lc_main.operator("mesh.edge_face_add", text="", icon="FACE_MAPS");
        if (context.region.width > 680): lc_main.operator("mesh.fill_grid", text="", icon_value=lc_icon("FILL_GRID"));
        if (context.region.width > 650): lc_main.operator("mesh.fill", text="", icon_value=lc_icon("FILL"));
        lc_main.operator("mesh.bridge_edge_loops", text="", icon_value=lc_icon("BRIDGE"));
        
        lc_main.separator();
        
        lc_btn = lc_main.operator("transform.change", text="", icon_value=lc_icon("X0"));
        lc_btn.option = "SNAP_POINT_CENTER_X"; lc_btn.hint = "Snap selected points to zero .x";
    
    elif (context.mode in {"SCULPT"}): #-------------------------------------------------
    
        if (context.region.width > 800): 
            lc_row = lc_main.row(align = True);
            lc_row.template_ID_preview(context.tool_settings.sculpt, "brush", rows=3, cols=8, hide_buttons=True);
            lc_row.ui_units_x = 6.5;
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        if (context.region.width < 800): lc_row.ui_units_x = 5;
        lc_row.prop(context.tool_settings.unified_paint_settings, "size", slider=True);
        lc_main.prop(context.tool_settings.sculpt.brush, "use_pressure_size", text="");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        if (context.region.width < 800): lc_row.ui_units_x = 5;
        lc_row.prop(context.tool_settings.unified_paint_settings, "strength");
        lc_main.prop(context.tool_settings.sculpt.brush, "use_pressure_strength", text="");
        
        lc_main.separator();
        
        if (context.tool_settings.sculpt.brush.direction != "DEFAULT"):
            lc_main.prop(context.tool_settings.sculpt.brush, "direction", expand=True, text="");

    elif (context.mode in {"PAINT_VERTEX"}): #-------------------------------------------------
    
        vertex_paint = context.tool_settings.vertex_paint;
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 6;
        lc_row.operator("paint.vertex_color_set", text="", icon_value=lc_icon("COLOR_FILL"));
        lc_row.prop(vertex_paint.brush, "color", text="");
        lc_row.operator("paint.brush_colors_flip", text="", icon="FILE_REFRESH");
        lc_row.prop(vertex_paint.brush, "secondary_color", text="");
        
        lc_main.separator();
        
        lc_main.operator("paint.vertex_color_smooth", text="", icon="MOD_FLUIDSIM");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 4.5;
        lc_row.prop(vertex_paint.brush, "blend", text="");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        if (context.region.width < 800): lc_row.ui_units_x = 5;
        lc_row.prop(context.tool_settings.unified_paint_settings, "size", slider=True);
        lc_main.prop(vertex_paint.brush, "use_pressure_size", text="", slider=True);
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        if (context.region.width < 800): lc_row.ui_units_x = 5;
        lc_row.prop(vertex_paint.brush, "strength");
        lc_main.prop(vertex_paint.brush, "use_pressure_strength", text="");
    
    elif (context.mode in {"PAINT_WEIGHT"}): #-------------------------------------------------
    
        brush = context.tool_settings.weight_paint.brush;
        unified_paint_settings = context.tool_settings.unified_paint_settings;
        
        lc_main.prop(brush, "blend", text="");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True); lc_row.ui_units_x = 6.2;
        if not (unified_paint_settings.use_unified_weight): lc_row.prop(brush, "weight", text="Weight");
        else: lc_row.prop(unified_paint_settings, "weight", text="Weight");
        lc_row.prop(unified_paint_settings, "use_unified_weight", text="", icon="BRUSHES_ALL");
        
        lc_main.separator();
        
        lc_main.operator("object.vertex_group_smooth", text="", icon="MOD_FLUIDSIM");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True); lc_row.ui_units_x = 7;
        lc_row.prop(unified_paint_settings, "size", text="Radius");
        lc_row.prop(brush, "use_pressure_size", text="");
        lc_row.prop(unified_paint_settings, "use_unified_size", text="", icon="BRUSHES_ALL");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True); lc_row.ui_units_x = 7.2;
        if not (unified_paint_settings.use_unified_strength): lc_row.prop(brush, "strength");
        else: lc_row.prop(unified_paint_settings, "strength");
        lc_row.prop(brush, "use_pressure_strength", text="");
        lc_row.prop(unified_paint_settings, "use_unified_strength", text="", icon="BRUSHES_ALL");
        
    elif (context.mode in {"PAINT_TEXTURE"}): #-------------------------------------------------
        pass
        
classes = [
    
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
