#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Operator;

from bpy_sys import (
    q_register_class, q_unregister_class, lc_icon,
);

def draw_panel (lc_main, context):
    lc_main.label(text="Armature:", icon="ARMATURE_DATA" if (context.mode in {"POSE"}) else "OUTLINER_DATA_ARMATURE");
    
    lc_main.separator_spacer();
    
    if (context.mode in {"OBJECT"}): #-------------------------------------------------
    
        lc_main.operator_menu_enum("object.origin_set", text="Set Origin", property="type");
        lc_main.operator_menu_enum("object.apply", "props", icon="NONE");
        
        lc_main.separator();

        lc_main.operator("object.duplicate_move", text="", icon_value=lc_icon("DUP_MOVE"));
        lc_main.operator("object.duplicate_move_linked", text="", icon_value=lc_icon("DUPLICATE_LINKED"));
        
        lc_btn = lc_main.row(align = True);
        lc_btn.operator("object.join", icon="FORCE_LENNARDJONES", text="");
        lc_btn.active = len(context.selected_objects) > 1;
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 4.5;
        lc_row.prop(context.active_object, "display_type", text="", icon="VIS_SEL_10");
        
        lc_main.separator();
        
        lc_main.operator("view3d.snap_selected_to_cursor", text="", icon="ORIENTATION_CURSOR").use_offset=True;
    
    elif (context.mode in {"EDIT_ARMATURE"}): #------------------------------------------------   
    
        lc_main.operator("armature.bone_primitive_add", icon="BONE_DATA", text="ADD");
        
        lc_main.separator();
        
        lc_main.operator("armature.subdivide", icon="IPO_QUAD", text="");
        lc_main.operator("armature.switch_direction", icon="UV_SYNC_SELECT", text="");
        lc_main.operator("armature.extrude_move", icon="PARTICLES", text="");
        
        lc_main.separator();
        
        lc_main.operator("armature.symmetrize", icon="MOD_MIRROR", text="");
        lc_main.menu("VIEW3D_MT_edit_armature_names");
            
    elif (context.mode in {"POSE"}): #-------------------------------------------------
        
        lc_main.operator("pose.select_all", text="", icon='SELECT_EXTEND').action='SELECT';
        lc_main.operator("pose.select_all", text="", icon='SELECT_INTERSECT').action='INVERT';
        lc_main.operator("pose.select_all", text="", icon='SELECT_SET').action='DESELECT';
        
        lc_main.separator();
        
        lc_main.menu("VIEW3D_MT_pose_ik", text="IK");
        
        lc_main.separator();
        
        lc_main.operator("pose.copy",  text="", icon="COPYDOWN");
        lc_main.operator("pose.paste", text="", icon="PASTEDOWN").flipped=False;
        lc_main.operator("pose.paste", text="", icon="PASTEFLIPDOWN").flipped=True;
        
        lc_main.separator();
        
        lc_main.operator("pose.transforms_clear", text="Clear Transform");
        lc_main.operator("pose.flip", text="", icon="MOD_MIRROR");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 4.5;
        lc_row.prop(context.active_object, "display_type", text="", icon="VIS_SEL_10");
        
        lc_main.separator();
        
        lc_main.operator("view3d.snap_selected_to_cursor", text="", icon="ORIENTATION_CURSOR").use_offset=True;

class ARMATURE_POSE_flip (Operator):
    bl_idname       = 'pose.flip';
    bl_label        = 'Flip Pose';
    bl_description  = 'Flip Selected Bones';
    
    def execute(self, context):
        bpy.ops.pose.copy();
        bpy.ops.pose.paste(flipped=True);
        return {'FINISHED'};

classes = [
    ARMATURE_POSE_flip,
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
