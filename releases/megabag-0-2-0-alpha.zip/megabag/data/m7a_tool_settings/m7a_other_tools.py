#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Panel;

from bpy_sys import (
    q_register_class, q_unregister_class, lc_icon, lc_cont_x,
);

def draw_panel (lc_main, context):
    a_obj = context.active_object;
    
    if (a_obj.type == "EMPTY"): # -------------------------------------
    
        lc_main.label(text="Empty:", icon="EMPTY_AXIS");
        
        lc_main.separator_spacer();
        
        lc_main.prop(a_obj, "empty_display_type", text="");
        
        lc_main.separator();
        
        lc_main.prop(a_obj, "empty_display_size", text="");
        
    elif (a_obj.type == "CAMERA"): # -------------------------------------
    
        lc_main.label(text="Camera:", icon="CAMERA_DATA");
        
        lc_main.separator_spacer();
        
        lc_main.prop(a_obj.data, "type", text="");
        if (a_obj.data.type != "ORTHO"):
            lc_main.prop(a_obj.data, "lens", text="");
        lc_main.popover(panel="M7A_CAMERA_PROPS_panel", text="");
        
        lc_main.separator();
        
        lc_main.prop(a_obj.data.dof, "use_dof", text="", icon="IMAGE_ZDEPTH");
        if (a_obj.data.dof.use_dof):
            lc_cont_x(lc_main, 0.8).prop(a_obj.data.dof, "focus_distance", text="Distance");
            lc_cont_x(lc_main, 0.8).prop(a_obj.data.dof, "aperture_fstop", text="F-Stop");
            lc_main.prop(a_obj.data, "show_limits", text="", icon="OUTLINER_DATA_EMPTY");
        
    elif (a_obj.type == "LIGHT"): # -------------------------------------
    
        lc_main.label(text="Light:", icon="LIGHT_DATA");
        
        lc_main.separator_spacer();
        
        lc_main.prop(a_obj, "color", text="");
        
        lc_main.separator();
        
        lc_main.prop(bpy.data.lights[a_obj.name], "energy", text="Energy");
        lc_main.prop(bpy.data.lights[a_obj.name], "shadow_soft_size", text="Radius");
        
    elif (a_obj.type == "LIGHT_PROBE"): # -------------------------------------
    
        lc_main.label(text="Light Probe:", icon="OUTLINER_DATA_LIGHTPROBE");
        
        lc_main.separator_spacer();
        
        lc_main.prop(a_obj, "influence_type", text="");
        
        lc_main.separator();
        
        lc_main.prop(a_obj, "influence_distance", text="Radius");
        lc_main.prop(a_obj, "falloff", text="Falloff");
        
    elif (a_obj.type == "SPEAKER"): # -------------------------------------
    
        lc_main.label(text="Speaker:", icon="OUTLINER_DATA_SPEAKER");
        
        lc_main.separator_spacer();
        
        lc_main.template_ID(a_obj, "sound", open="sound.open_mono");
        
        lc_main.separator();
        
        lc_main.prop(a_obj, "muted", text="", toggle=True);
        
        lc_main.separator();
        
        lc_main.prop(a_obj, "volume", text="Volume");
        lc_main.prop(a_obj, "pitch", text="Pitch");
        
    elif (a_obj.type == "SURFACE"): # -------------------------------------
    
        lc_main.label(text="Surface:", icon="SURFACE_DATA");
        
        lc_main.separator_spacer();
        
        lc_main.prop(a_obj, "resolution_u", text="Viewport");
        lc_main.prop(a_obj, "resolution_v", text="Viewport");
        
        lc_main.separator();
        
        lc_main.prop(a_obj, "render_resolution_u", text="Render");
        lc_main.prop(a_obj, "render_resolution_v", text="Render");
        
    elif (a_obj.type == "META"): # -------------------------------------
    
        lc_main.label(text="Meta:", icon="META_DATA");
        
        lc_main.separator_spacer();
        
        lc_main.prop(a_obj, "resolution", text="Viewport");
        lc_main.prop(a_obj, "render_resolution", text="Render");
        
        lc_main.separator();
        
        lc_main.prop(a_obj, "threshold", text="Threshold");
        
    elif (a_obj.type == "FONT"): # -------------------------------------
    
        lc_main.label(text="Text:", icon="FONT_DATA");
        
        lc_main.separator_spacer();
    
        if (context.mode in {"OBJECT"}): # -----------------------------------------------
        
            lc_main.operator_menu_enum("object.origin_set", text="Set Origin", property="type");
            lc_main.operator_menu_enum("object.apply", "props", icon="NONE");
            
            lc_main.separator();

            lc_main.operator("object.duplicate_move", text="", icon_value=lc_icon("DUP_MOVE"));
            lc_main.operator("object.duplicate_move_linked", text="", icon_value=lc_icon("DUPLICATE_LINKED"));
            
            lc_main.separator();
            
            lc_row = lc_main.row(align = True);
            lc_row.ui_units_x = 4.5;
            lc_row.prop(a_obj, "display_type", text="", icon="VIS_SEL_10");
            
        elif (context.mode in {"EDIT_TEXT"}): # ------------------------------------------
        
            edit_format = a_obj.data.edit_format;
        
            lc_main.popover(panel="M7A_PT_KEYBOARD_panel", text="", icon_value=lc_icon("KEYBOARD"));
            
            lc_main.separator();
            
            lc_main.prop(edit_format, "use_bold",       text="", toggle=True);
            lc_main.prop(edit_format, "use_italic",     text="", toggle=True);
            lc_main.prop(edit_format, "use_underline",  text="", toggle=True);
            lc_main.prop(edit_format, "use_small_caps", text="", toggle=True);

class M7A_CAMERA_PROPS_panel(Panel):
    bl_space_type  = 'VIEW_3D';
    bl_region_type = 'HEADER';
    bl_label       = "Camera";
    
    @staticmethod
    def draw(self, context):
        lc_main = self.layout.column();
        a_obj = context.active_object;
        
        lc_main.prop(a_obj.data, "lens_unit", text="");
        
        lc_row = lc_main.row(align = True);
        lc_row.prop(a_obj.data, "shift_x", text="Shift X");
        lc_row.prop(a_obj.data, "shift_y", text="Y");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.prop(a_obj.data, "clip_start", text="Clip Start");
        lc_row.prop(a_obj.data, "clip_end", text="End");
        
        lc_main.separator();
        lc_main.prop(a_obj.data, "show_safe_areas", text="Show Safe Areas");
        lc_cont = self.layout.column();
        lc_cont.active = a_obj.data.show_safe_areas;
        lc_cont_x(lc_cont, 1.0).prop(context.scene.safe_areas, "title", text="");
        lc_cont_x(lc_cont, 1.0).prop(context.scene.safe_areas, "action", text="");
        

classes = [
    M7A_CAMERA_PROPS_panel,
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
