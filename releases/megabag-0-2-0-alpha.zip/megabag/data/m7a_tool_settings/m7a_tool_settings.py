#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Header;

from bpy_sys import (
    q_register_class, q_unregister_class, get_prop,
    r_register_class, r_unregister_class,
);

import m7a_mesh_tool,   m7a_gpencil_tool, m7a_armature_tool;
import m7a_other_tools, m7a_curve_tool;

bl_conf = {
    "VIEW3D_HT_tool_header": None,
}

class VIEW3D_HT_tool_header (Header):
    bl_space_type  = 'VIEW_3D';
    bl_region_type = 'TOOL_HEADER';
    
    def draw(self, context):
        lc_main = self.layout.row(align = True);
        
        lc_tool = context.workspace.tools.from_space_view3d_mode(context.mode);
        
        lc_main.operator("ed.undo", icon="LOOP_BACK", text="");
        lc_main.operator("ed.redo", icon="LOOP_FORWARDS", text="");
        
        if (lc_tool.idname == 'builtin.spin'):
            lc_main.separator();
            
            lc_row = lc_main.row(align = True);
            lc_row.ui_units_x = 8;
            lc_row.prop(lc_tool.operator_properties("mesh.spin"), "steps", text="");
            lc_row.prop(lc_tool.gizmo_group_properties("MESH_GGT_spin"), "axis");
        
        lc_main.separator();
        
        a_obj = context.active_object;
        if (a_obj != None):
            if   (a_obj.type == "MESH"):     m7a_mesh_tool.draw_panel(lc_main, context);
            elif (a_obj.type == "CURVE"):    m7a_curve_tool.draw_panel(lc_main, context);
            elif (a_obj.type == "ARMATURE"): m7a_armature_tool.draw_panel(lc_main, context);
            elif (a_obj.type == "GPENCIL"):  m7a_gpencil_tool.draw_panel(lc_main, context);
            else:                            m7a_other_tools.draw_panel(lc_main, context);
        
        lc_main.separator_spacer();
        
        def lc_mirror(icon = 0):
            if (icon == 0): lc_main.label(icon='MOD_MIRROR');
            lc_row = lc_main.row(align = True);
            lc_row.ui_units_x = 0.8;
            return lc_row;
            
        if (context.mode == 'EDIT_ARMATURE'):
            lc_mirror().prop(context.object.data, "use_mirror_x", text="X", toggle=True);
            lc_main.separator();
        elif (context.mode == 'POSE'):
            lc_mirror().prop(context.object.pose, "use_mirror_x", text="X", toggle=True);
            lc_main.separator();
        elif (context.mode in {'EDIT_MESH', 'PAINT_WEIGHT', 'SCULPT', 'PAINT_VERTEX', 'PAINT_TEXTURE'}):
            lc_mirror(0).prop(context.object, "use_mesh_mirror_x", text="X", toggle=True);
            lc_mirror(1).prop(context.object, "use_mesh_mirror_y", text="Y", toggle=True);
            lc_mirror(2).prop(context.object, "use_mesh_mirror_z", text="Z", toggle=True);
            if (context.mode == 'SCULPT'):
                lc_main.popover(panel="VIEW3D_PT_sculpt_symmetry_for_topbar", text="");
            if (context.mode == 'PAINT_VERTEX'):
                lc_main.popover(panel="VIEW3D_PT_tools_vertexpaint_symmetry_for_topbar", text="");
            if (context.mode == 'PAINT_WEIGHT'):
                lc_main.popover(panel="VIEW3D_PT_tools_weightpaint_symmetry_for_topbar", text="");
            lc_main.separator();
            
        popover_kw = {"space_type": 'VIEW_3D', "region_type": 'UI', "category": "Tool"};

        if (context.mode == 'SCULPT'):         lc_main.popover_group(context=".sculpt_mode",   **popover_kw);
        elif (context.mode == 'PAINT_VERTEX'): lc_main.popover_group(context=".vertexpaint",   **popover_kw);
        elif (context.mode == 'PAINT_WEIGHT'): lc_main.popover_group(context=".weightpaint",   **popover_kw);
        elif (context.mode == 'PAINT_TEXTURE'):lc_main.popover_group(context=".imagepaint",    **popover_kw);
        elif (context.mode == 'EDIT_TEXT'):    lc_main.popover_group(context=".text_edit",     **popover_kw);
        elif (context.mode == 'EDIT_ARMATURE'):lc_main.popover_group(context=".armature_edit", **popover_kw);
        elif (context.mode == 'EDIT_METABALL'):lc_main.popover_group(context=".mball_edit",    **popover_kw);
        elif (context.mode == 'EDIT_LATTICE'): lc_main.popover_group(context=".lattice_edit",  **popover_kw);
        elif (context.mode == 'EDIT_CURVE'):   lc_main.popover_group(context=".curve_edit",    **popover_kw);
        elif (context.mode == 'EDIT_MESH'):
            lc_main.prop(context.tool_settings, "use_mesh_automerge", text="");
            lc_main.separator();
            lc_main.popover_group(context=".mesh_edit", **popover_kw);
        elif (context.mode == 'POSE'):     lc_main.popover_group(context=".posemode",     **popover_kw);
        elif (context.mode == 'PARTICLE'): lc_main.popover_group(context=".particlemode", **popover_kw);
        elif (context.mode == 'OBJECT'):   lc_main.popover_group(context=".objectmode",   **popover_kw);
        
        if (context.mode in {"EDIT_GPENCIL"}):
            lc_main.operator("gpencil.snap_cursor_to_selected", text="", icon="PIVOT_CURSOR");
        else:
            lc_main.operator("view3d.snap_cursor_to_selected", text="", icon="PIVOT_CURSOR");
        lc_main.operator("view3d.snap_cursor_to_center",   text="", icon="CURSOR");

def register_nodes (self, context):
    if get_prop("view3d_upgrade_header") and \
        get_prop("view3d_tool_header"):
            register();
    else: unregister();

classes = [
    VIEW3D_HT_tool_header,
];

def register():
    r_unregister_class(bl_conf, "VIEW3D_HT_tool_header");
    
    m7a_armature_tool.register();
    m7a_gpencil_tool.register();
    m7a_other_tools.register();
    
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
    
    m7a_armature_tool.unregister();
    m7a_gpencil_tool.unregister();
    m7a_other_tools.unregister();
    
    r_register_class(bl_conf, "VIEW3D_HT_tool_header");
