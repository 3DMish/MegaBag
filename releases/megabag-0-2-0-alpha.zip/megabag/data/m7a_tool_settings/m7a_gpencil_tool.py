#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Operator;
#from mathutils import Color;

from bpy_sys import (
    q_register_class, q_unregister_class, lc_icon, lc_cont_x,
    float_curve,
);

def draw_panel (lc_main, context):
    lc_main.label(text="G-Pendil:", icon="OUTLINER_OB_GREASEPENCIL");
    
    gpencil_paint = context.tool_settings.gpencil_paint;
    gpencil_settings = gpencil_paint.brush.gpencil_settings;
    
    lc_main.separator_spacer();
    
    if (context.mode in {"OBJECT"}): # -------------------------------------
    
        lc_main.operator_menu_enum("object.origin_set", text="Set Origin", property="type");
        lc_main.operator_menu_enum("object.apply", "props", icon="NONE");
        
        lc_main.separator();

        lc_main.operator("object.duplicate_move", text="", icon_value=lc_icon("DUP_MOVE"));
        lc_main.operator("object.duplicate_move_linked", text="", icon_value=lc_icon("DUPLICATE_LINKED"));
        
        lc_btn = lc_main.row(align = True);
        lc_btn.operator("object.join", icon="FORCE_LENNARDJONES", text="");
        lc_btn.active = len(context.selected_objects) > 1;
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 4.5;
        lc_row.prop(context.active_object, "display_type", text="", icon="VIS_SEL_10");
    
    elif (context.mode in {"EDIT_GPENCIL"}): # -------------------------------------
    
        lc_main.operator("gpencil.stroke_subdivide", icon="MOD_SUBSURF", text="").only_selected = True;
        lc_main.operator("gpencil.stroke_smooth", icon="MOD_SMOOTH", text="").only_selected = True;
        
        lc_main.separator();
        
        lc_main.menu("VIEW3D_MT_gpencil_simplify");
        
        lc_main.separator();
        
        lc_main.menu("VIEW3D_MT_mirror");
        
        lc_main.separator();
        
        lc_main.operator("gpencil.stroke_merge", icon="CENTER_ONLY", text="");
        
        lc_main.separator();
        
        lc_main.menu("GPENCIL_MT_move_to_layer");
        
        lc_main.separator();
        
        lc_main.operator("gpencil.duplicate_move", icon="DUPLICATE", text="");
        lc_main.operator("gpencil.copy", icon="COPYDOWN", text="");
        lc_main.operator("gpencil.paste", icon="PASTEDOWN", text="").type = "ACTIVE";
        lc_main.operator("gpencil.paste", icon="PASTEDOWN", text="").type = "LAYER";
        
        lc_main.separator();
        
        lc_main.operator("gpencil.stroke_flip", icon="CURVE_PATH", text="");
            
    elif (context.mode in {"PAINT_GPENCIL"}): # -------------------------------------
        
        material = gpencil_settings.material;
        tool = gpencil_paint.brush.gpencil_tool;
        
        if not gpencil_settings.use_material_pin:
            material = context.object.active_material;
        
        icon_id = 0; txt_ma = "";
        
        if material:
            material.id_data.preview_ensure();
            if material.id_data.preview:
                icon_id = material.id_data.preview.icon_id;
                txt_ma = material.name;
        
        if (tool not in {"ERASE"}):
            lc_main.separator();
            
            if (tool not in {"TINT"}):
                lc_main.prop_enum(gpencil_paint, "color_mode", 'MATERIAL',    text="", icon='MATERIAL');
                lc_main.prop_enum(gpencil_paint, "color_mode", 'VERTEXCOLOR', text="", icon='VPAINT_HLT');
        
            lc_row = lc_main.row(align = True);
            if (gpencil_paint.color_mode == 'VERTEXCOLOR') or \
              (gpencil_settings.brush_draw_mode == 'VERTEXCOLOR') or \
                (tool in {"TINT"}):
                lc_row.ui_units_x = 5
                lc_row.prop(gpencil_paint.brush, "color", text="");
                lc_row.operator("gpencil.tint_flip", text="", icon="FILE_REFRESH");
                lc_row.prop(gpencil_paint.brush, "secondary_color", text="");
                lc_row.prop(gpencil_paint.brush.gpencil_settings, "use_material_pin", text="");
                if (tool not in {"TINT"}):
                    lc_row_btn = lc_main.row(align = True);
                    lc_row_btn.ui_units_x = 1;
                    lc_row_btn.popover(panel="TOPBAR_PT_gpencil_materials", text=txt_ma);
            else:
                lc_row.ui_units_x = 6;
                lc_row.popover(panel="TOPBAR_PT_gpencil_materials", text=txt_ma, icon_value=icon_id);
                lc_row.prop(gpencil_paint.brush.gpencil_settings, "use_material_pin", text="");
            
        
        lc_main.separator();
        
        lc_main.prop(gpencil_settings, "vertex_mode", text="");
        
        if (tool in {"DRAW", "ERASE", "TINT"}):
            if (tool in {"ERASE"}):
                lc_main.separator();
                lc_main.prop(gpencil_settings, "eraser_mode", expand=True);
                
            lc_main.separator();
            
            lc_row = lc_main.row(align = True);
            lc_row.ui_units_x = 5;
            lc_row.prop(gpencil_paint.brush, "size", text="Radius")
            lc_main.prop(gpencil_settings, "use_pressure", text="", icon='STYLUS_PRESSURE');
            
            lc_main.separator();
            
            lc_row = lc_main.row(align = True);
            lc_row.ui_units_x = 5;
            lc_row.prop(gpencil_settings, "pen_strength", slider=True);
            lc_main.prop(gpencil_settings, "use_strength_pressure", text="", icon='STYLUS_PRESSURE');
            
        elif (tool in {"FILL"}):
            lc_main.separator();
            
            lc_main.prop(gpencil_settings, "fill_direction", text="", expand=True);
            
            lc_main.separator();
            
            lc_row = lc_main.row(align = True);
            lc_row.ui_units_x = 18;
            lc_row.prop(gpencil_settings, "fill_factor", slider=True);
            lc_row.prop(gpencil_settings, "dilate", slider=True);
            lc_row.prop(gpencil_paint.brush, "size", slider=True);

    elif (context.mode in {"SCULPT_GPENCIL"}): # -------------------------------------
    
        brush = context.tool_settings.gpencil_sculpt_paint.brush;
        gp_settings = brush.gpencil_settings;
        tool = brush.gpencil_sculpt_tool;
        
        lc_row = lc_main.row(align=True);
        lc_row.prop(context.tool_settings, "use_gpencil_select_mask_point", text="");
        lc_row.prop(context.tool_settings, "use_gpencil_select_mask_stroke", text="");
        lc_row.prop(context.tool_settings, "use_gpencil_select_mask_segment", text="");

        lc_main.separator();
        
        lc_main.prop(brush, "size", slider=True);
        lc_sub = lc_main.row(align=True);
        lc_sub.enabled = tool not in {'GRAB', 'CLONE'};
        lc_sub.prop(gp_settings, "use_pressure", text="");
        
        lc_main.separator();
        
        lc_main.prop(brush, "strength", slider=True);
        lc_main.prop(brush, "use_pressure_strength", text="");
        
        lc_main.separator();
        
        if tool in {'THICKNESS', 'STRENGTH', 'PINCH', 'TWIST'}:
            lc_main.separator();
            lc_main.prop(gp_settings, "direction", expand=True, text="");

    elif (context.mode in {"VERTEX_GPENCIL"}): # -------------------------------------
    
        brush = context.tool_settings.gpencil_vertex_paint.brush;
        gpencil_settings = brush.gpencil_settings;
        
        lc_row = lc_main.row(align = True);
        lc_row.operator("gpencil.set_vertex_color", text="", icon_value=lc_icon("COLOR_FILL"));
        lc_row.ui_units_x = 5
        lc_row.prop(brush, "color", text="");
        lc_row.prop(brush, "secondary_color", text="");
        
        lc_main.separator();
        
        lc_main.prop(gpencil_settings, "vertex_mode", text="");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 5;
        lc_row.prop(brush, "size", text="Radius")
        lc_main.prop(gpencil_settings, "use_pressure", text="", icon='STYLUS_PRESSURE');
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 5;
        lc_row.prop(gpencil_settings, "pen_strength", slider=True);
        lc_main.prop(gpencil_settings, "use_strength_pressure", text="", icon='STYLUS_PRESSURE');
        
        lc_main.separator();
        
    elif (context.mode in {"WEIGHT_GPENCIL"}): # -------------------------------------
    
        brush = context.tool_settings.gpencil_weight_paint.brush;
        
        lc_cont_x(lc_main, 0.9).prop(brush, "size", text="Radius");
        
        lc_main.separator();
        
        lc_cont_x(lc_main, 0.8).prop(brush, "weight", text="Weight");
        
        lc_main.separator();
        
        lc_main.operator("gpencil.vertex_group_smooth", text="", icon="MOD_FLUIDSIM");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 5;
        lc_row.prop(brush, "strength", slider=True);
        lc_main.prop(brush, "use_pressure_strength", text="", icon='STYLUS_PRESSURE');

class M7A_GPENCIL_VERTEX_color_set (Operator):
    bl_idname      = "gpencil.set_vertex_color";
    bl_label       = "Vertex Paint Set Color";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Set active color to all selected vertex";
    
    def execute(self, context):
        brush = context.tool_settings.gpencil_vertex_paint.brush;
        mode = brush.gpencil_settings.vertex_mode;
        
        lc_data = context.active_object.data;
        for layer in lc_data.layers:
            for stroke in layer.active_frame.strokes:
                if (mode in {'STROKE', 'BOTH'}):
                    for point in stroke.points:
                        if point.select:
                            point.vertex_color = (
                                float_curve(brush.color[0]),
                                float_curve(brush.color[1]),
                                float_curve(brush.color[2]),
                                1.0
                            );
                if (mode in {'FILL', 'BOTH'}):
                    stroke.vertex_color_fill = (
                        float_curve(brush.color[0]),
                        float_curve(brush.color[1]),
                        float_curve(brush.color[2]),
                        1.0
                    );
                    
        return {'FINISHED'};

classes = [
    M7A_GPENCIL_VERTEX_color_set,
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
