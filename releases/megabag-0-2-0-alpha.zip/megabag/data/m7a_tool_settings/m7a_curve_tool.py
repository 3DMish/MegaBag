#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy_sys import (
    q_register_class, q_unregister_class, lc_icon,
);

def draw_panel (lc_main, context):
    lc_main.label(text="Curve:", icon="CURVE_DATA");
    
    lc_main.separator_spacer();
    
    if (context.mode in {"OBJECT"}): #-------------------------------------------------
    
        lc_main.operator_menu_enum("object.origin_set", text="Set Origin", property="type");
        lc_main.operator_menu_enum("object.apply", "props", icon="NONE");
        
        lc_main.separator();

        lc_main.operator("object.duplicate_move", text="", icon_value=lc_icon("DUP_MOVE"));
        lc_main.operator("object.duplicate_move_linked", text="", icon_value=lc_icon("DUPLICATE_LINKED"));
        
        lc_btn = lc_main.row(align = True);
        lc_btn.operator("object.join", icon="FORCE_LENNARDJONES", text="");
        lc_btn.active = len(context.selected_objects) > 1;
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.ui_units_x = 4.5;
        lc_row.prop(context.active_object, "display_type", text="", icon="VIS_SEL_10");
    
    elif (context.mode in {"EDIT_CURVE"}): #-------------------------------------------------
    
        lc_main.operator_menu_enum("curve.spline_type_set", "type", text="Type", icon="FCURVE");
        
        lc_main.separator();
        
        lc_main.operator_menu_enum("curve.handle_type_set", "type", text="Handle Type", icon="CURVE_BEZCURVE");
        
        lc_main.separator();
        
        lc_main.operator("curve.subdivide", icon="PARTICLE_POINT", text="");
        lc_main.operator("curve.switch_direction", icon="CURVE_PATH", text="");
        lc_main.operator("curve.make_segment", icon="IPO_LINEAR", text="");
        lc_main.operator("curve.smooth", icon="MOD_SMOOTH", text="");
        
        lc_main.separator();
        
        lc_main.operator("curve.select_linked", icon="GP_SELECT_POINTS", text="");
        
        lc_main.separator();
        
        lc_main.menu("VIEW3D_MT_hook", text="", icon="HOOK");

classes = [
    
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
