#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys, subprocess, shutil;

from bpy.types import PropertyGroup, AddonPreferences, Operator, WindowManager;
from bpy.props import (
    BoolProperty, EnumProperty, PointerProperty, StringProperty,
    FloatProperty,
);

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../m7a_nodes/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../m7a_quick_pack/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../m7a_tool_settings/");

from bpy_sys import (
    q_register_class, q_unregister_class, addon_id, lc_width, lc_return, ver_less,
    bpy_preferences, data_path, lc_icon, r_remove_attr, ver_more, get_prop,
    new_asset_path, remove_asset_path, asset_libraries, lc_split_row, lc_cont_x,
    is_exist_asset_pack,
);

import m7a_nodes, m7a_quick_pack, m7a_view3d_header, m7a_tool_settings, m7a_text_editor;
import m7a_modifiers, m7a_dope_sheet;

def m7a_tabs_items (self, context):
    result = lc_return([("", "Panel", "")], [], max=300);
    return result + [
        (
            "3d_view", "3D View",
            "Show '3D View' properties", "VIEW3D",   0,
        ), (
            "modifiers", "Modifiers",
            "Show 'Modifiers' properties", "MODIFIER", 1,
        ), (
            "node_tree",
            lc_return("Nodes", "Node Tree", 350, 550),
            "Show 'Node Tree' properties", "NODETREE", 2,
        ), (
            "assets", 
            lc_return("Assets", "Assets Library", 350, 550),
            "Show 'Assets Library' properties", "ASSET_MANAGER", 3,
        ), (
            "other",
            lc_return("Other", "Other Stuff",  350, 550),
            "Show 'Other Stuff' properties", "PACKAGE", 4,
        ),
    ];
    
def m7a_update_3d_view (self, context):
    m7a_view3d_header.register_nodes(self, context);
    m7a_tool_settings.register_nodes(self, context);

def m7a_update_assets_paths (self, context):
    if (get_prop("assets_libraries")): 
        if (get_prop("assets_foods")): 
            if not ("M7A Foods" in asset_libraries):
                new_asset_path("M7A Foods", data_path + "/data/m7a_assets_library/food");
        else: 
            if ("M7A Foods" in asset_libraries): remove_asset_path("M7A Foods");
            
        if (get_prop("assets_materials")): 
            if not ("M7A Materials" in asset_libraries):
                new_asset_path("M7A Materials", data_path + "/data/m7a_assets_library/materials");
        else: 
            if ("M7A Materials" in asset_libraries): remove_asset_path("M7A Materials");
    else: 
        if ("M7A Materials" in asset_libraries): remove_asset_path("M7A Materials");
        if ("M7A Foods" in asset_libraries): remove_asset_path("M7A Foods");

class M7A_MEGABAG_Properties (PropertyGroup):
    properties_tabs : EnumProperty(items=m7a_tabs_items);
    
    view3d_upgrade_header : BoolProperty(default=True, update=m7a_update_3d_view);
    view3d_compact_menu   : BoolProperty(default=True);
    view3d_tool_header    : BoolProperty(default=True, update=m7a_tool_settings.register_nodes);
    
    view3d_quick_pack   : BoolProperty(default=True, update=m7a_quick_pack.register_nodes);
    view3d_mesh_library : BoolProperty(default=True);
    view3d_gp_library   : BoolProperty(default=True);
    view3d_custom_props : BoolProperty(default=True);
    
    modifiers_upgrade  : BoolProperty(default=True, update=m7a_modifiers.register_nodes);
    modifiers_options  : BoolProperty(default=True);
    
    modifiers_m7a_pack : BoolProperty(default=True);
    
    m7a_vector_array : BoolProperty(default=True);
    m7a_circle_array : BoolProperty(default=True);
    m7a_flower       : BoolProperty(default=True);
    m7a_beads        : BoolProperty(default=True);
    m7a_icing        : BoolProperty(default=True);
    m7a_frosting     : BoolProperty(default=True);
    m7a_sprinkles    : BoolProperty(default=True);
    m7a_cherry_on    : BoolProperty(default=True);
    m7a_m_noise      : BoolProperty(default=True);
    
    m7a_elec_arc     : BoolProperty(default=True);
    m7a_chain        : BoolProperty(default=True);
    m7a_c_noise      : BoolProperty(default=True);
    
    text_editor_upgrade : BoolProperty(default=True, update=m7a_text_editor.register_nodes);
    text_editor_file    : BoolProperty(default=True);
    text_editor_icons   : BoolProperty(default=True);
    text_editor_info    : BoolProperty(default=True);
    
    assets_libraries : BoolProperty(default=True, update=m7a_update_assets_paths);
    assets_materials : BoolProperty(default=True, update=m7a_update_assets_paths);
    assets_foods     : BoolProperty(default=True, update=m7a_update_assets_paths);
    
    if ver_more(3,3,0): assets_gnu : BoolProperty(default=True);
    assets_cc0 : BoolProperty(default=True);
    assets_cca : BoolProperty(default=True);
    
    node_editor        : BoolProperty(default=True, update=m7a_nodes.register_nodes);
    node_shader_groups : BoolProperty(default=True);
    
    node_replace : EnumProperty(
        name="How add Group Nodes",
        description="How to add new group nodes, always create new, or if exist use it",
        items=[
            ("use_exist", "If exist use it", "Use exist, if not exist create new"), 
            ("always_new", "Always new", "Always add as new"),
        ],
    );
    
    geonode_replace : EnumProperty(
        name="How add GeoNode Modifier",
        description="How to add new m7a modifier, always create new geonodes, or if exist use it",
        items=[
            ("use_exist", "If exist use it", "Use exist, if not exist create new"), 
            ("always_new", "Always new", "Always add as new"),
        ],
    );
    
    node_distance_rgb  : BoolProperty(default=True);
    node_noise_mapping : BoolProperty(default=True);
    
    dope_sheet_upgrade : BoolProperty(default=True, update=m7a_dope_sheet.register_nodes);
    dope_compact_menu  : BoolProperty(default=True);
    dope_play_pause    : BoolProperty(default=True);
    dope_layer_props   : BoolProperty(default=False);

class M7A_MEGABAG_Preferences (AddonPreferences):
    bl_idname = addon_id;
    
    m7a_props : PointerProperty(type=M7A_MEGABAG_Properties);
    
    def draw(self, context):
        def lc_template_item(lc_cont, text, icon = None, data = None, props = None):
            lc_cont = lc_cont.column(align=True);
            lc_row = lc_cont.box().row(align=True);
            if (icon != None): lc_row.label(text=text, icon=icon);
            else: lc_row.label(text=text);
            if (data != None) and (props != None):
                lc_row.prop(data, props,  text="");
            return lc_cont.box().column(align=True);
            
        def lc_icons(lc_cont, icons):
            for icon in icons:
                try: lc_cont.label(text="", icon_value=int(icon));
                except: lc_cont.label(text="", icon=icon);
            
        lc_main = self.layout.column(align=False);
        
        lc_box = lc_main.box().row(align = True);
        is_mishkey_exist = "MishKey" in bpy.context.window_manager.keyconfigs.keys();
        btn_name = "ReInstall MishKey" if (is_mishkey_exist) else "Install MishKey";
        lc_btn = lc_box.operator("m7a.install_mishkey", text=btn_name, icon="IMPORT")
        lc_btn.option = "REINSTALL_MISHKEY" if (is_mishkey_exist) else "INSTALL_MISHKEY";
        
        if (is_mishkey_exist):
            lc_box.operator("m7a.install_mishkey", text="", icon="TRASH").option = "UNINSTALL_MISHKEY";
            
        lc_box.separator();
        lc_box.operator("m7a.install_mishkey", text="Set Props", icon="TOOL_SETTINGS").option = "SET_MISHKEY_PROPS";
        
        lc_main.separator();
        
        lc_box = lc_main.column(align=True);
        lc_row = lc_box.box().row(align=True);
        if (lc_width() > 350): lc_row.prop(self.m7a_props, "properties_tabs",  expand=True);
        else: lc_row.prop(self.m7a_props, "properties_tabs",  text="Panel");
        lc_box_main = lc_box.box().column(align=True);
        
        m7a_properties_tabs = self.m7a_props.properties_tabs;
        
        if (m7a_properties_tabs == "3d_view"):
            lc_box = lc_template_item(lc_box_main, text="Upgrade Header:", icon="TOPBAR", data=self.m7a_props, props="view3d_upgrade_header");
            lc_box.active = self.m7a_props.view3d_upgrade_header;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "view3d_compact_menu",  text="Compact Menu");
            lc_box_row.prop(self.m7a_props, "view3d_tool_header",   text="Tool Settings");
            
            lc_box_main.separator();
            
            lc_box = lc_template_item(lc_box_main, text="Quick Pack:", icon="MENU_PANEL", data=self.m7a_props, props="view3d_quick_pack");
            lc_box.active = self.m7a_props.view3d_quick_pack;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "view3d_mesh_library",  text="Mesh Library");
            lc_box_row.prop(self.m7a_props, "view3d_gp_library",    text="Grease Pencil Library");
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "view3d_custom_props",  text="Custom Properties");
        
        elif (m7a_properties_tabs == "modifiers"):
            lc_box = lc_template_item(lc_box_main, text="Upgrade Panel:", icon="MENU_PANEL", data=self.m7a_props, props="modifiers_upgrade");
            lc_box.active = self.m7a_props.modifiers_upgrade;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "modifiers_options",   text="Modifiers Options");
            
            lc_box.separator();
            
            lc_box_box = lc_template_item(lc_box, text="M7A GeoNodes Modifiers:", data=self.m7a_props, props="modifiers_m7a_pack");
            lc_box_box.active = self.m7a_props.modifiers_m7a_pack;
            
            lc_box_row = lc_box_box.row(align=True);
            lc_box_row.label(text="How to add new GeoNode Group:");
            lc_box_row.prop(self.m7a_props, "geonode_replace",   text="");
            
            lc_box_box.separator();
            
            lc_box_box.box().label(text="MESH", icon="OUTLINER_OB_MESH");
            lc_box_row = lc_box_box.row(align=False);
            
            lc_box_col = lc_box_row.column(align=False);
            lc_icons(lc_box_col, ['BLANK1','MOD_ARRAY',lc_icon("CIRCLE_ARRAY"),lc_icon("FLOWER"),lc_icon("BEADS_WIREFRAME")]);
            lc_box_col = lc_box_row.column(align=False);
            lc_box_col.label(text="Generate");
            lc_box_col.prop(self.m7a_props, "m7a_vector_array", text="Vector Array");
            lc_box_col.prop(self.m7a_props, "m7a_circle_array", text="Circle Array");
            lc_box_col.prop(self.m7a_props, "m7a_flower",       text="Flower");
            lc_box_col.prop(self.m7a_props, "m7a_beads",        text="Beads Wireframe");
            
            lc_box_col = lc_box_row.column(align=False);
            lc_icons(lc_box_col, ['BLANK1','FREEZE',lc_icon("FROSTING"),lc_icon("SPRINKLES"),lc_icon("CHERRY")]);
            lc_box_col = lc_box_row.column(align=False);
            lc_box_col.label(text="Create");
            lc_box_col.prop(self.m7a_props, "m7a_icing",        text="Icing");
            lc_box_col.prop(self.m7a_props, "m7a_frosting",     text="Frosting");
            lc_box_col.prop(self.m7a_props, "m7a_sprinkles",    text="Sprinkles");
            lc_box_col.prop(self.m7a_props, "m7a_cherry_on",    text="Cherry on Top");
            
            lc_box_col = lc_box_row.column(align=False);
            lc_icons(lc_box_col, ['BLANK1','MOD_NOISE']);
            lc_box_col = lc_box_row.column(align=False);
            lc_box_col.label(text="Deform");
            lc_box_col.prop(self.m7a_props, "m7a_m_noise",      text="Noise");
            
            # -----------------------------------------------------------------
            
            lc_box_box.separator();
            
            lc_box_box.box().label(text="CURVE", icon="OUTLINER_OB_CURVE");
            lc_box_row = lc_box_box.row(align=False);
            
            lc_box_col = lc_box_row.column(align=False);
            lc_icons(lc_box_col, ['BLANK1',lc_icon("ELECTRIC")]);
            lc_box_col = lc_box_row.column(align=False);
            lc_box_col.label(text="Generate");
            lc_box_col.prop(self.m7a_props, "m7a_elec_arc", text="Electricity Arc");
            
            lc_box_col = lc_box_row.column(align=False);
            lc_icons(lc_box_col, ['BLANK1','LINKED']);
            lc_box_col = lc_box_row.column(align=False);
            lc_box_col.label(text="Create");
            lc_box_col.prop(self.m7a_props, "m7a_chain", text="Chain");
            
            lc_box_col = lc_box_row.column(align=False);
            lc_icons(lc_box_col, ['BLANK1','MOD_NOISE']);
            lc_box_col = lc_box_row.column(align=False);
            lc_box_col.label(text="Deform");
            lc_box_col.prop(self.m7a_props, "m7a_c_noise", text="Noise");
            
        elif (m7a_properties_tabs == "node_tree"):
            lc_box = lc_template_item(lc_box_main, text="Node Editor:", icon="NODETREE", data=self.m7a_props, props="node_editor");
            lc_box.active = self.m7a_props.node_editor;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.label(text="How to add new Node Group:");
            lc_box_row.prop(self.m7a_props, "node_replace",   text="");
            
            lc_box.separator();
            
            lc_box = lc_template_item(lc_box, text="Shader Groups:", icon="NODE_MATERIAL", data=self.m7a_props, props="node_shader_groups");
            lc_box.active = self.m7a_props.node_shader_groups;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "node_distance_rgb",  text="MixRGB by Distance");
            lc_box_row.prop(self.m7a_props, "node_noise_mapping", text="Noise Mapping");
            
        elif (m7a_properties_tabs == "assets"):
            lc_box = lc_template_item(lc_box_main, text="M7A Assets Libraries:", data=self.m7a_props);
            
            lc_box_row = lc_box.row(align=True);
            
            lc_btn = lc_box_row.operator(
                "preferences.asset_m7a_add",  text="Install 'Materials' Assets", 
                icon="MATERIAL", depress=is_exist_asset_pack("M7A Materials"),
            );
            lc_btn.asset = "M7A Materials"; lc_btn.path = "/m7a_assets_library/materials";
            
            lc_box_row.separator();
            
            lc_btn = lc_box_row.operator(
                "preferences.asset_m7a_add",  text="Install 'Food' Assets", 
                icon_value=lc_icon("CHERRY"), depress=is_exist_asset_pack("M7A Food"),
            );
            lc_btn.asset = "M7A Food"; lc_btn.path = "/m7a_assets_library/food";
            
            lc_box.separator(); # ------------------------------------
            
            lc_box_lic = lc_template_item(lc_box, text="(C) Show with Linence:", icon="COPY_ID");
            
            lc_box_row = lc_split_row(lc_box_lic, 450);
            if ver_more(3,3,0):
                lc_box_row.prop(self.m7a_props, "assets_gnu", text="GNU (GPL) Geo-Generators");
            
            lc_box_row = lc_box_row.row(align=True);
            lc_cont_x(lc_box_row, 0.8).prop(self.m7a_props, "assets_cc0", text="CC Zero Models");
            lc_cont_x(lc_box_row, 0.9).prop(self.m7a_props, "assets_cca", text="CC Attribution Models");
            
        elif (m7a_properties_tabs == "other"):
            lc_box_group = lc_template_item(lc_box_main, text="Dope Sheet:", icon="ACTION");
            
            lc_box = lc_template_item(lc_box_group, text="Upgrade Header:", icon="TOPBAR", data=self.m7a_props, props="dope_sheet_upgrade");
            lc_box.active = self.m7a_props.dope_sheet_upgrade;
            lc_box_row = lc_split_row(lc_box, 300);
            lc_box_row.prop(self.m7a_props, "dope_compact_menu",  text="Compact Menu");
            lc_box_row.prop(self.m7a_props, "dope_play_pause",    text="Show (Play/Pause)");
            lc_box_row = lc_split_row(lc_box, 300);
            lc_box_row.prop(self.m7a_props, "dope_layer_props",   text="Show (Layer Props)");
            
            lc_box_main.separator();
            
            lc_box_group = lc_template_item(lc_box_main, text="Text Editor:", icon="TEXT");
            
            lc_box = lc_template_item(lc_box_group, text="Upgrade Panel:", icon="MENU_PANEL", data=self.m7a_props, props="text_editor_upgrade");
            lc_box.active = self.m7a_props.text_editor_upgrade;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "text_editor_info",  text="Info");
            lc_box_row.prop(self.m7a_props, "text_editor_file",  text="File");
            if (lc_width() > 450):
                lc_box_row.prop(self.m7a_props, "text_editor_icons", text="Icon Viewer");
            else:
                lc_box_row = lc_box.row(align=True);
                lc_box_row.active = self.m7a_props.text_editor_upgrade;
                lc_box_row.prop(self.m7a_props, "text_editor_icons", text="Icon Viewer");
            
        # ---------------------------------------------------------------------

class M7A_BTN_INSTALL_MishKey (bpy.types.Operator):
    bl_idname		= 'm7a.install_mishkey';
    bl_label		= 'Install MishKey';
    bl_description  = '';

    option: StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        if (properties.option == "SET_MISHKEY_PROPS"):
            return "Set 3DMish's properties in blender, like ''Navigation'', add corrections in ''Interface'' ...";
        elif (properties.option == "INSTALL_MISHKEY"):   return "Install Keymap: MishKey";
        elif (properties.option == "REINSTALL_MISHKEY"): return "ReInstall Keymap: MishKey";
        elif (properties.option == "UNINSTALL_MISHKEY"): return "Remove Keymap: MishKey";
        else: pass;
        
    def execute(self, context):
        
        if (self.option == "SET_MISHKEY_PROPS"):
            bpy_preferences().inputs.walk_navigation.use_gravity = True;
            bpy_preferences().inputs.invert_mouse_zoom = True;
            bpy_preferences().inputs.invert_zoom_wheel = False;
            bpy_preferences().inputs.view_rotate_method = 'TURNTABLE';
            
        elif (self.option in {"INSTALL_MISHKEY", "REINSTALL_MISHKEY"}):
            path = bpy.utils.user_resource('SCRIPTS', path=os.path.join("presets", "keyconfig"), create=True);
            path = os.path.join(path, "MishKey.py");
            
            if (self.option == "REINSTALL_MISHKEY"): os.remove(path);
                
            shutil.copy(os.path.join(data_path, "p3_0_0", "m7a_mishkey.py"), path);
            bpy.utils.keyconfig_set(path);
        
        elif (self.option in {"UNINSTALL_MISHKEY"}):
            path = bpy.utils.user_resource('SCRIPTS', path=os.path.join("presets", "keyconfig"), create=True);
            path = os.path.join(path, "MishKey.py"); os.remove(path);
            context.window_manager.keyconfigs.remove(context.window_manager.keyconfigs['MishKey']);
            
        return {'FINISHED'};
        
class M7A_GPENCIL_list (PropertyGroup):
    name: StringProperty();

class M7A_OBJECT_Apply (Operator):
    bl_idname      = 'object.apply';
    bl_label       = "Apply";
    bl_description = 'Apply Transforms';
    
    props: EnumProperty(
        items = [
            ("", "        Apply", ""),
            
            ("loc",          "Location",                 "Apply Location"),
            ("rot",          "Rotation",                 "Apply Rotation"),
            ("scale",        "Scale",                    "Apply Scale"),
            ("all",          "All Transforms",           "Apply All Transforms"),
            ("r&s",          "Rotation & Scale",         "Apply Rotation & Scale"),
            
            ("", "        Apply to Deltas", ""),
            
            ("loc_deltas",   "Location to Deltas",       "Apply Location to Deltas"),
            ("rot_deltas",   "Rotation to Deltas",       "Apply Rotation to Deltas"),
            ("scale_deltas", "Scale to Deltas",          "Apply Scale to Deltas"),
            ("all_deltas",   "All Transforms to Deltas", "Apply All Transforms to Deltas"),
            
            ("", "        Visual Apply", ""),
            
            ("visual",       "Visual Transform",         "Apply Visual Transform"),
            ("visual_gtm",   "Visual Geometry to Mesh",  "Apply Visual Geometry to Mesh"),
            ("instance",     "Make Instance Real",       "Make Instance Real"),
        ]
    );
    
    def execute(self, context):
        if (self.props in ["loc", "rot", "scale", "all", "r&s"]):
            bpy.ops.object.transform_apply(
                location = True if (self.props in ["loc", "all"]) else False,
                rotation = True if (self.props in ["rot", "all", "r&s"]) else False,
                scale    = True if (self.props in ["scale", "all", "r&s"]) else False,
            );
        elif (self.props in ["loc_deltas", "rot_deltas", "scale_deltas", "all_deltas"]):
            bpy.ops.object.transforms_to_deltas(
                mode = "LOC"   if (self.props in ["loc_deltas"]) else 
                       "ROT"   if (self.props in ["rot_deltas"]) else 
                       "SCALE" if (self.props in ["scale_deltas"]) else "ALL"
            );
        elif (self.props in ["visual"]):     bpy.ops.object.visual_transform_apply();
        elif (self.props in ["visual_gtm"]): bpy.ops.object.convert(target='MESH');
        elif (self.props in ["instance"]):   bpy.ops.object.duplicates_make_real();
            
        return {'FINISHED'};

class WM_empty (Operator):
    bl_idname       = 'wm.empty';
    bl_label        = 'Empty Button';
    
    hint : StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        if not (properties.hint == ""): return properties.hint;
        else: pass;
    
    def execute(self, context): return {'FINISHED'};

class M7A_KEYBOARD_button (Operator):
    bl_idname       = 'keyboard.button';
    bl_label        = 'Empty Button';
    
    key : StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        pass;
    
    def execute(self, context):
        status = False if (subprocess.check_output('xset q | grep LED', shell=True)[65] == 50) else True;
        if (self.key == "{CAPS}"): os.system("xdotool key Caps_Lock");
        if (self.key == "{NUMLOCK}"): os.system("xdotool key Num_Lock");
        else:
            if (context.space_data.type == "VIEW_3D"):
                element = context.active_object;
                if hasattr(element, "type") and (context.mode == "EDIT_TEXT"):
                    if (element.type == "FONT"):
                        if (self.key.find("{") < 0):
                            add_text = self.key.upper() if (status) else self.key.lower();
                            bpy.ops.font.text_insert(text=add_text);
                        else:
                            if   (self.key == "{LEFT}"):      bpy.ops.font.move(type='PREVIOUS_CHARACTER');
                            elif (self.key == "{RIGHT}"):     bpy.ops.font.move(type='NEXT_CHARACTER');
                            elif (self.key == "{UP}"):        bpy.ops.font.move(type='PREVIOUS_LINE');
                            elif (self.key == "{DOWN}"):      bpy.ops.font.move(type='NEXT_LINE');
                            elif (self.key == "{DEL}"):       bpy.ops.font.delete(type='NEXT_OR_SELECTION');
                            elif (self.key == "{BACKSPACE}"): bpy.ops.font.delete(type='PREVIOUS_OR_SELECTION');
                            elif (self.key == "{ENTER}"):     bpy.ops.font.line_break();
                            elif (self.key == "{HOME}"):      bpy.ops.font.move(type='LINE_BEGIN');
                            elif (self.key == "{END}"):       bpy.ops.font.move(type='LINE_END');
                            elif (self.key == "{PGUP}"):      bpy.ops.font.move(type='PREVIOUS_PAGE');
                            elif (self.key == "{PGDN}"):      bpy.ops.font.move(type='NEXT_PAGE');
                            
            elif (context.space_data.type == "TEXT_EDITOR"):
                if (self.key.find("{") < 0):
                    add_text = self.key.upper() if (status) else self.key.lower();
                    bpy.ops.text.insert(text=add_text);
                else:
                    if   (self.key == "{LEFT}"):      bpy.ops.text.move(type='PREVIOUS_CHARACTER');
                    elif (self.key == "{RIGHT}"):     bpy.ops.text.move(type='NEXT_CHARACTER');
                    elif (self.key == "{UP}"):        bpy.ops.text.move(type='PREVIOUS_LINE');
                    elif (self.key == "{DOWN}"):      bpy.ops.text.move(type='NEXT_LINE');
                    elif (self.key == "{DEL}"):       bpy.ops.text.delete(type='NEXT_OR_SELECTION');
                    elif (self.key == "{BACKSPACE}"): bpy.ops.text.delete(type='PREVIOUS_OR_SELECTION');
                    elif (self.key == "{ENTER}"):     bpy.ops.text.line_break();
                    elif (self.key == "{HOME}"):      bpy.ops.text.move(type='LINE_BEGIN');
                    elif (self.key == "{END}"):       bpy.ops.text.move(type='LINE_END');
                    elif (self.key == "{PGUP}"):      bpy.ops.text.move(type='PREVIOUS_PAGE');
                    elif (self.key == "{PGDN}"):      bpy.ops.text.move(type='NEXT_PAGE');
            
        return {'FINISHED'};

class M7A_Icon_Select (Operator):
    bl_idname      = "m7a.icon_select";
    bl_label       = "Icon";
    bl_description = "Select the Icon";
    bl_options     = {'INTERNAL'}

    icon: StringProperty();
    option: StringProperty();

    @classmethod
    def description(cls, context, properties):
        if (properties.option == "CLEAR"): return "Clear history";

    def execute(self, context):
        if (self.option == "CLEAR"):
            m7a_text_editor.bl_conf["HISTORY"] = [];
        else:
            context.window_manager.clipboard = self.icon;
            m7a_text_editor.bl_conf["SELECTED"] = self.icon;
            if (self.icon not in m7a_text_editor.bl_conf["HISTORY"]):
                m7a_text_editor.bl_conf["HISTORY"].append(self.icon);
            self.report({'INFO'}, self.icon);

        return {'FINISHED'}
        
class TRANSFORM_change (Operator):
    bl_idname      = "transform.change";
    bl_label       = "Change Transform";
    bl_description = "Change Transform";
    bl_options     = {'REGISTER', 'UNDO'};

    hint: StringProperty();
    option: StringProperty();

    @classmethod
    def description(cls, context, properties):
        if not (properties.hint == ""): return properties.hint;
        else: pass;

    def execute(self, context):
        a_obj = context.active_object;
        
        if (self.option == "SNAP_POINT_CENTER_X"):
            bpy.ops.object.mode_set(mode='OBJECT', toggle=False);
            for vert in a_obj.data.vertices:
                if (vert.select == True):
                    vert.co.x = 0.0;
            bpy.ops.object.mode_set(mode='EDIT', toggle=False);
        
        elif (self.option == "CLEAR_LOCATION_X"):
            if not (context.mode in {'POSE'}): a_obj.location[0] = 0.0;
            else: context.active_pose_bone.location[0] = 0.0;
        elif (self.option == "CLEAR_LOCATION_Y"):
            if not (context.mode in {'POSE'}): a_obj.location[1] = 0.0;
            else: context.active_pose_bone.location[1] = 0.0;
        elif (self.option == "CLEAR_LOCATION_Z"):
            if not (context.mode in {'POSE'}): a_obj.location[2] = 0.0;
            else: context.active_pose_bone.location[2] = 0.0;
        
        elif (self.option == "CLEAR_ROTATION_EULER_X"):
            if not (context.mode in {'POSE'}): a_obj.rotation_euler[0] = 0.0;
            else: context.active_pose_bone.rotation_euler[0] = 0.0;
        elif (self.option == "CLEAR_ROTATION_EULER_Y"):
            if not (context.mode in {'POSE'}): a_obj.rotation_euler[1] = 0.0;
            else: context.active_pose_bone.rotation_euler[1] = 0.0;
        elif (self.option == "CLEAR_ROTATION_EULER_Z"):
            if not (context.mode in {'POSE'}): a_obj.rotation_euler[2] = 0.0;
            else: context.active_pose_bone.rotation_euler[2] = 0.0;
        
        elif (self.option == "CLEAR_ROTATION_QUATERNION_W"):
            if not (context.mode in {'POSE'}): a_obj.rotation_quaternion[0] = 1.0;
            else: context.active_pose_bone.rotation_quaternion[0] = 1.0;
        elif (self.option == "CLEAR_ROTATION_QUATERNION_X"):
            if not (context.mode in {'POSE'}): a_obj.rotation_quaternion[1] = 0.0;
            else: context.active_pose_bone.rotation_quaternion[1] = 0.0;
        elif (self.option == "CLEAR_ROTATION_QUATERNION_Y"):
            if not (context.mode in {'POSE'}): a_obj.rotation_quaternion[2] = 0.0;
            else: context.active_pose_bone.rotation_quaternion[2] = 0.0;
        elif (self.option == "CLEAR_ROTATION_QUATERNION_Z"):
            if not (context.mode in {'POSE'}): a_obj.rotation_quaternion[3] = 0.0;
            else: context.active_pose_bone.rotation_quaternion[3] = 0.0;
        
        elif (self.option == "CLEAR_ROTATION_AXIS_ANGLE_W"):
            if not (context.mode in {'POSE'}): a_obj.rotation_axis_angle[0] = 0.0;
            else: context.active_pose_bone.rotation_axis_angle[0] = 0.0;
        elif (self.option == "CLEAR_ROTATION_AXIS_ANGLE_X"):
            if not (context.mode in {'POSE'}): a_obj.rotation_axis_angle[1] = 0.0;
            else: context.active_pose_bone.rotation_axis_angle[1] = 0.0;
        elif (self.option == "CLEAR_ROTATION_AXIS_ANGLE_Y"):
            if not (context.mode in {'POSE'}): a_obj.rotation_axis_angle[2] = 0.0;
            else: context.active_pose_bone.rotation_axis_angle[2] = 0.0;
        elif (self.option == "CLEAR_ROTATION_AXIS_ANGLE_Z"):
            if not (context.mode in {'POSE'}): a_obj.rotation_axis_angle[3] = 0.0;
            else: context.active_pose_bone.rotation_axis_angle[3] = 0.0;
        
        elif (self.option == "CLEAR_SCALE_X"):
            if not (context.mode in {'POSE'}): a_obj.scale[0] = 1.0;
            else: context.active_pose_bone.scale[0] = 1.0;
        elif (self.option == "CLEAR_SCALE_Y"):
            if not (context.mode in {'POSE'}): a_obj.scale[1] = 1.0;
            else: context.active_pose_bone.scale[1] = 1.0;
        elif (self.option == "CLEAR_SCALE_Z"):
            if not (context.mode in {'POSE'}): a_obj.scale[2] = 1.0;
            else: context.active_pose_bone.scale[2] = 1.0;
            
        return {'FINISHED'}

class OBJECT_GEONODE_add (Operator):
    bl_idname       = 'object.geonode_add';
    bl_label        = 'Add GeoNode Modifier';
    
    node : StringProperty();
    hint : StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        if not (properties.hint == ""): return properties.hint;
        else: pass;
    
    def execute(self, context):
        name = self.node; a_obj = context.active_object; exist = False;
        a_obj_modifiers = a_obj.modifiers if (a_obj.type != "GPENCIL") else a_obj.grease_pencil_modifiers;
        mod_name = name.replace("GeoNodes ", "");
        
        if (get_prop("geonode_replace") == "use_exist") and (mod_name in bpy.data.node_groups):
            m7a_geonode = bpy.data.node_groups[mod_name];
            exist = True;
        
        if (exist == False):
            ver = 'p3_3_0' if ver_more(3,3,0) else 'p3_0_0';
            bpy.ops.wm.append(directory=data_path+"/"+ver+"/m7a_data.blend/NodeTree", filename=name);
            m7a_geonode = bpy.data.node_groups[name];
            m7a_geonode.name = mod_name;
            bpy.context.active_object.select_set(True);
                
        m7a_modifier = a_obj_modifiers.new(name=mod_name, type='NODES');
        bpy.ops.object.modifier_set_active(modifier=m7a_modifier.name);
        m7a_modifier.node_group = m7a_geonode;
        return {'FINISHED'};
        
class NODE_M7A_add (Operator):
    bl_idname       = 'node.add_m7a_node';
    bl_label        = 'Add M7A Node';
    
    type : StringProperty();
    node : StringProperty();
    hint : StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        if not (properties.hint == ""): return properties.hint;
        else: pass;
    
    def execute(self, context):
        name = self.node; a_obj = context.active_object; exist = False;
        group_name = name.replace("M7A ", "");
        
        if (get_prop("node_replace") == "use_exist") and (group_name in bpy.data.node_groups):
            exist = True;
        
        if (exist == False):
            ver = 'p3_3_0' if ver_more(3,3,0) else 'p3_0_0';
            bpy.ops.wm.append(directory=data_path+"/"+ver+"/m7a_data.blend/NodeTree", filename=name);
            if (group_name in bpy.data.node_groups): bpy.data.node_groups[group_name].name = group_name+".001";
            bpy.data.node_groups[name].name = group_name;
            
        if (self.type == "ShaderNodeGroup"):
            bpy.ops.node.add_node(
                type="ShaderNodeGroup", use_transform=True, 
                settings=[{"name":"node_tree", "value":"bpy.data.node_groups['"+group_name+"']"}]
            ); bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT');
        
        return {'FINISHED'};
        
class OBJECT_MODIFIERS_option (Operator):
    bl_idname       = 'object.modifiers_option';
    bl_label        = 'Modifiers Options';
    
    option : StringProperty();
    hint : StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        if not (properties.hint == ""): return properties.hint;
        else: pass;
    
    def execute(self, context):
        a_obj = context.active_object;
        a_obj_modifiers = a_obj.modifiers if (a_obj.type != "GPENCIL") else a_obj.grease_pencil_modifiers;
        
        def opt_modifiers(list_modifiers, view = "view", value = False):
            for modifier in list_modifiers:
                if   (view == "view"):       modifier.show_viewport = value;
                elif (view == "render"):     modifier.show_render   = value;
                if   (view == "view_tgl"):   modifier.show_viewport = False if (modifier.show_viewport) else True;
                elif (view == "render_tgl"): modifier.show_render   = False if (modifier.show_render)   else True;
                elif (view == "apply"):      bpy.ops.object.modifier_apply(modifier=modifier.name);
        
        if   (self.option == "MOD_APPLY_ALL"):       opt_modifiers(a_obj_modifiers, "apply");
        
        elif (self.option == "MOD_VIEWPORT_ON"):     opt_modifiers(a_obj_modifiers, "view", True);
        elif (self.option == "MOD_VIEWPORT_OFF"):    opt_modifiers(a_obj_modifiers, "view", False);
        elif (self.option == "MOD_VIEWPORT_TOGGLE"): opt_modifiers(a_obj_modifiers, "view_tgl");
        
        elif (self.option == "MOD_RENDER_ON"):       opt_modifiers(a_obj_modifiers, "render", True);
        elif (self.option == "MOD_RENDER_OFF"):      opt_modifiers(a_obj_modifiers, "render", False);
        elif (self.option == "MOD_RENDER_TOGGLE"):   opt_modifiers(a_obj_modifiers, "render_tgl");
                    
        elif (self.option == "MOD_REMOVE_VIEW"):
            list_modifiers = [];
            for modifier in a_obj_modifiers:
                if (modifier.show_viewport == False): list_modifiers.append(modifier.name);
            for modifier in list_modifiers: a_obj_modifiers.remove(a_obj_modifiers[modifier]);
            del list_modifiers;
            
        elif (self.option == "MOD_REMOVE_RENDER"):
            list_modifiers = [];
            for modifier in a_obj_modifiers:
                if (modifier.show_render == False): list_modifiers.append(modifier.name);
            for modifier in list_modifiers: a_obj_modifiers.remove(a_obj_modifiers[modifier]);
            del list_modifiers;
            
        elif (self.option == "MOD_REMOVE_ALL"):
            for i in range(0, len(a_obj_modifiers)):
                a_obj_modifiers.remove(a_obj_modifiers[len(a_obj_modifiers)-1]);
                
        return {'FINISHED'};

class M7A_ASSET_PATH_add (Operator):
    bl_idname       = 'preferences.asset_m7a_add';
    bl_label        = 'Add M7A Assets';
    
    asset : StringProperty();
    path : StringProperty();
    hint : StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        if not (properties.hint == ""): return properties.hint;
        else: pass;
    
    def execute(self, context):
        if not (self.asset in asset_libraries):
            new_asset_path(self.asset, data_path + self.path);
        return {'FINISHED'};

class GPENCIL_PROP_SIZE_set (Operator):
    bl_idname       = 'gpencil.set_proportional_size';
    bl_label        = 'Set Proportional Size';
    
    value : FloatProperty();
    
    def execute(self, context):
        context.scene.tool_settings.proportional_size += self.value;
        return {'FINISHED'};
    
classes = [
    M7A_MEGABAG_Properties, M7A_BTN_INSTALL_MishKey,    M7A_MEGABAG_Preferences, 
    M7A_GPENCIL_list,       M7A_OBJECT_Apply, WM_empty, M7A_KEYBOARD_button,
    M7A_Icon_Select,        OBJECT_GEONODE_add,         OBJECT_MODIFIERS_option,
    NODE_M7A_add,           TRANSFORM_change,           M7A_ASSET_PATH_add,
    GPENCIL_PROP_SIZE_set,
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
