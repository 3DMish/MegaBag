#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import sys, os;

from bpy.types import Header, Menu, Panel, Scene, Operator;
from bpy.props import IntProperty;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");

from bpy_sys import (
    q_register_class, q_unregister_class, r_register_class, r_unregister_class,
    ver_more, lc_icon, lc_set_width, get_prop, lc_cont_x, r_remove_attr,
);

if ver_more(3,0,0):
    from bl_ui.space_time import TIME_MT_editor_menus, TIME_HT_editor_buttons;
    from bl_ui.space_dopesheet import (
        DOPESHEET_MT_editor_menus, DOPESHEET_HT_editor_buttons, dopesheet_filter,
    );

bl_conf = {
    "DOPESHEET_HT_header": None,
}

class DOPESHEET_HT_header(Header):
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'HEADER'
    
    def draw(self, context):        
        lc_space_data = context.space_data;
        lc_tool_settings = context.tool_settings;
        a_obj = context.active_object;
        
        lc_main = self.layout.row(align = True);
        
        lc_main.template_header();
        lc_main.separator();
        
        if (lc_space_data.mode == 'TIMELINE'):            
            lc_row = lc_main.row(align = False);
            TIME_MT_editor_menus.draw_collapsible(context, lc_row);
            TIME_HT_editor_buttons.draw_header(context, lc_row);
        else:
            lc_row = lc_main.row(align = True);
            lc_row.prop(lc_space_data, "ui_mode", text="");
                
            lc_row.separator();
                
            if (lc_space_data.mode == 'GPENCIL'):
                if get_prop("dope_compact_menu"): lc_main.menu("M7A_DOPE_SHEET_MT_Menu");
                else: DOPESHEET_MT_editor_menus.draw_collapsible(context, lc_main);
                
                lc_main.separator_spacer();
                
                selected = lc_space_data.dopesheet.show_only_selected;
                lc_enable = selected and a_obj is not None and a_obj.type == 'GPENCIL';
                
                lc_row = lc_main.row(align=True);
                if get_prop("dope_layer_props"):
                    lc_row.enabled = lc_enable;
                    lc_row.operator("gpencil.layer_add", icon='ADD', text="");
                    lc_row.operator("gpencil.layer_remove", icon='REMOVE', text="");
                    lc_row.menu("GPENCIL_MT_layer_context_menu", icon='DOWNARROW_HLT', text="");
                
                    lc_row.separator();

                    lc_row = lc_main.row(align=True);
                    lc_row.enabled = lc_enable;
                    lc_row.operator("gpencil.layer_move", icon='TRIA_UP', text="").type = 'UP';
                    lc_row.operator("gpencil.layer_move", icon='TRIA_DOWN', text="").type = 'DOWN';
                
                    lc_row.separator();
                
                    lc_row = lc_main.row(align=True);
                    lc_row.enabled = lc_enable;
                    lc_row.operator("gpencil.layer_isolate", icon='RESTRICT_VIEW_ON', text="").affect_visibility = True;
                    lc_row.operator("gpencil.layer_isolate", icon='LOCKED', text="").affect_visibility = False;

                    lc_row.separator();
                    
                lc_row.operator("action.keyframe_insert", text="", icon='KEYFRAME_HLT');
                lc_row.operator("gpencil.frame_duplicate", text="", icon='DUPLICATE');
                lc_row.operator("action.duplicate_move", text="", icon_value=lc_icon("DUP_MOVE"));
                lc_row.operator("action.delete", text="", icon='TRASH');
                
                lc_row.separator();
                
                lc_row.operator("action.keyframe_type", text="", icon='KEYTYPE_KEYFRAME_VEC');
                
                if (get_prop("dope_play_pause") == True):
                    lc_main.separator();
                    
                    DRAW_PLAY_PAUSE_Panel(context, lc_main, lc_tool_settings);
                    lc_main.popover(panel="M7A_DOPE_TIME_panel", text="");
                    
                    lc_main.separator_spacer();
                    
                    lc_row_btn = lc_main.row(align = True);
                    if context.scene.show_subframe: lc_row_btn.prop(context.scene, "frame_float", text="");
                    else: lc_row_btn.prop(context.scene, "frame_current", text="");
                    lc_set_width(lc_row_btn, 3);
                
                lc_main.separator();
                
                lc_main.prop(lc_space_data.dopesheet, "show_only_selected", text="");
                lc_main.prop(lc_space_data.dopesheet, "show_hidden", text="");
                
                lc_main.separator();
                
                lc_main.popover(panel="DOPESHEET_PT_filters", text="", icon='FILTER');
                
                lc_main.separator();
                
                lc_row_btn = lc_main.row(align = True);
                lc_row_btn.active = lc_tool_settings.use_proportional_action;
                lc_row_btn.prop(lc_tool_settings, "use_proportional_action", text="", icon_only=True);
                lc_row_btn.prop(lc_tool_settings, "proportional_edit_falloff", text="", icon_only=True);
                
            else:
                if get_prop("dope_compact_menu"): lc_main.menu("M7A_DOPE_SHEET_MT_Menu");
                else: DOPESHEET_MT_editor_menus.draw_collapsible(context, lc_main);
                
                lc_main.separator();
                
                if (lc_space_data.mode in {'DOPESHEET', 'ACTION', 'SHAPEKEY'}): 
                    lc_main.separator_spacer();
                    
                    #lc_main.menu("DOPESHEET_MT_key_transform", text="", icon='CON_TRANSLIKE');
                    
                    lc_main.operator("action.keyframe_insert", text="", icon='KEYFRAME_HLT');
                    lc_main.operator("action.copy",  text="", icon="COPYDOWN");
                    lc_main.operator("action.paste", text="", icon="PASTEDOWN").flipped=False;
                    lc_main.operator("action.paste", text="", icon="PASTEFLIPDOWN").flipped=True;
                    lc_main.operator("marker.camera_bind", text="", icon='CAMERA_DATA');
                    lc_main.operator("action.duplicate_move", text="", icon_value=lc_icon("DUP_MOVE"));
                    lc_main.operator("action.delete", text="", icon='TRASH');
                    lc_main.popover(panel="M7A_KEYFRAMES_panel", text="");
                    
                    if (get_prop("dope_play_pause") == True):
                        lc_main.separator();
                        
                        DRAW_PLAY_PAUSE_Panel(context, lc_main, lc_tool_settings);
                        lc_main.popover(panel="M7A_DOPE_TIME_panel", text="");
                
                    if (lc_space_data.mode in {'ACTION', 'SHAPEKEY'}):
                        if get_prop("dope_layer_props"):
                            lc_main.separator();
                            lc_main.operator("action.layer_prev", text="", icon='TRIA_DOWN');
                            lc_main.operator("action.layer_next", text="", icon='TRIA_UP');

                            lc_main.separator();
                            lc_main.operator("action.push_down", text="Push Down", icon='NLA_PUSHDOWN');
                            lc_main.operator("action.stash", text="Stash", icon='FREEZE');
                    
                    if (lc_space_data.mode in {'DOPESHEET', 'ACTION', 'SHAPEKEY'}):
                        if (lc_space_data.mode in {'ACTION'}):
                            lc_main.separator();
                            lc_main.template_ID(lc_space_data, "action", new="action.new", unlink="action.unlink");
                    
                    lc_main.separator_spacer();
                    
                    if (lc_space_data.mode in {'DOPESHEET', 'ACTION'}):
                        dopesheet_filter(lc_main, context);
                    elif lc_space_data.mode == 'GPENCIL':
                        lc_main.prop(lc_space_data.dopesheet, "show_only_selected", text="")
                        lc_main.prop(lc_space_data.dopesheet, "show_hidden", text="")
                        
                    lc_main.separator();
                
                    lc_main.popover(panel="DOPESHEET_PT_filters", text="", icon='FILTER');
                    
                    lc_main.separator();
                    
                    lc_main.prop(lc_tool_settings, "use_proportional_action", text="", icon_only=True);
                    lc_sub = lc_main.row(align=True);
                    lc_sub.active = lc_tool_settings.use_proportional_action;
                    lc_sub.prop(lc_tool_settings, "proportional_edit_falloff", text="", icon_only=True);
                    
                else:
                    lc_main.separator();
                    DOPESHEET_HT_editor_buttons.draw_header(context, lc_main);
                    
def DRAW_PLAY_PAUSE_Panel(context, lc_main, lc_tool_settings):
    lc_main.prop(lc_tool_settings, "use_keyframe_insert_auto", text="", toggle=True);
    lc_main.separator();
    lc_main.operator("screen.frame_jump", text="", icon='REW').end = False;
    lc_main.operator("screen.keyframe_jump", text="", icon='PREV_KEYFRAME').next = False;
    if not (context.screen.is_animation_playing):
        lc_main.operator("screen.animation_play", text="", icon='PLAY_REVERSE').reverse = True;
        lc_main.operator("screen.animation_play", text="", icon='PLAY');
    else:
        lc_main.scale_x = 2;
        lc_main.operator("screen.animation_play", text="", icon='PAUSE');
        lc_main.scale_x = 1;
    lc_main.operator("screen.keyframe_jump", text="", icon='NEXT_KEYFRAME').next = True
    lc_main.operator("screen.frame_jump", text="", icon='FF').end = True
    
class M7A_DOPE_SHEET_MT_Menu(Menu):
    bl_idname      = 'M7A_DOPE_SHEET_MT_Menu';
    bl_label       = 'Menu';
    bl_description = 'Dope Sheet Menu';
    
    @staticmethod
    def draw(self, context):
        lc_space_data = context.space_data;
        lc_main = self.layout.column();

        lc_main.menu("DOPESHEET_MT_view")
        lc_main.menu("DOPESHEET_MT_select")
        if (lc_space_data.show_markers): lc_main.menu("DOPESHEET_MT_marker")

        if (lc_space_data.mode == 'DOPESHEET') or \
            (lc_space_data.mode == 'ACTION' and lc_space_data.action is not None):
            lc_main.menu("DOPESHEET_MT_channel")
        elif lc_space_data.mode == 'GPENCIL':
            lc_main.menu("DOPESHEET_MT_gpencil_channel")

        if (lc_space_data.mode == 'GPENCIL'): lc_main.menu("DOPESHEET_MT_gpencil_key");
        else: lc_main.menu("DOPESHEET_MT_key");

class M7A_DOPE_TIME_panel(Panel):
    bl_space_type  = 'DOPESHEET_EDITOR'
    bl_region_type = 'HEADER'
    bl_label       = "Timeline";
    
    @staticmethod
    def draw(self, context):
        lc_main = self.layout.column();
        
        scene = context.scene;
        
        lc_row = lc_main.row(align=True);
        lc_row.operator("screen.frame_jump", text="", icon='REW').end = False;
        lc_row.operator("screen.keyframe_jump", text="", icon='PREV_KEYFRAME').next = False;
        
        if not context.screen.is_animation_playing:
            lc_row.operator("screen.animation_play", text="", icon='PLAY_REVERSE').reverse = True;
            
            if scene.show_subframe:
                lc_row.scale_x = 1.15;
                lc_row.prop(scene, "frame_float", text="");
            else:
                lc_row.scale_x = 0.95;
                lc_row.prop(scene, "frame_current", text="");
        else:
            lc_row.scale_x = 2;
            lc_row.operator("screen.animation_play", text="", icon='PAUSE');
            lc_row.scale_x = 1;
        
        if not context.screen.is_animation_playing:
            lc_row.operator("screen.animation_play", text="", icon='PLAY')
        else:
            lc_row.scale_x = 2;
            lc_row.operator("screen.animation_play", text="", icon='PAUSE');
            lc_row.scale_x = 1;
        
        lc_row.operator("screen.keyframe_jump", text="", icon='NEXT_KEYFRAME').next = True;
        lc_row.operator("screen.frame_jump", text="", icon='FF').end = True;

        lc_row = lc_main.row(align=True);
        lc_row.prop(scene, "use_preview_range", text="", toggle=True);
        sub = lc_row.row(align=True);
        sub.scale_x = 0.8;
        if not scene.use_preview_range:
            lc_cont_x(sub, 0.82).prop(scene, "frame_start", text="Start");
            sub.prop(scene, "frame_end", text="End");
        else:
            lc_cont_x(sub, 0.82).prop(scene, "frame_preview_start", text="Start");
            sub.prop(scene, "frame_preview_end", text="End");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align=True);
        lc_row.operator("screen.keyframe_jump_back", text="", icon='LOOP_BACK');
        lc_row.prop(context.scene, "m7a_jump_frame", text="Jump Through");
        lc_cont_x(lc_row, 0.65).operator("screen.keyframe_jump_through", text="Jump", icon='DECORATE_OVERRIDE');

class M7A_KEYFRAMES_panel (Panel):
    bl_space_type  = 'DOPESHEET_EDITOR'
    bl_region_type = 'HEADER'
    bl_label       = "Keyframes";
    
    @staticmethod
    def draw(self, context):
        lc_space_data = context.space_data;
        lc_main = self.layout.column(align=True);
        
        lc_main.operator("action.keyframe_type", text="Set Keyframe Type", icon='KEYTYPE_KEYFRAME_VEC');
        
        if (lc_space_data.mode != 'GPENCIL'):
            lc_main.separator();
            lc_main.prop(lc_space_data, "auto_snap", text="");
            
        lc_main.separator();
        
        lc_row = lc_main.row(align=True);
        lc_row.operator("transform.transform", text="Move").mode='TIME_TRANSLATE';
        lc_row.operator("transform.transform", text="Extend").mode='TIME_EXTEND';
        lc_row = lc_main.row(align=True);
        lc_row.operator("transform.transform", text="Slide").mode='TIME_SLIDE';
        lc_row.operator("transform.transform", text="Scale").mode='TIME_SCALE';

class M7A_JUMP_KEYFRAME_through (Operator):
    bl_idname      = "screen.keyframe_jump_through";
    bl_label       = "Jump Through";
    bl_description = "Jump";
    bl_options     = {'REGISTER', 'UNDO'};

    def execute(self, context):
        context.scene.frame_current = context.scene.frame_current + context.scene.m7a_jump_frame;
        return {'FINISHED'}

class M7A_JUMP_KEYFRAME_back (Operator):
    bl_idname      = "screen.keyframe_jump_back";
    bl_label       = "Jump Back";
    bl_description = "Jump";
    bl_options     = {'REGISTER', 'UNDO'};

    def execute(self, context):
        context.scene.frame_current = context.scene.frame_current - context.scene.m7a_jump_frame;
        return {'FINISHED'}
        
def register_nodes (self, context):
    if (get_prop("dope_sheet_upgrade")): register();
    else: unregister();

classes = (
    DOPESHEET_HT_header, M7A_DOPE_SHEET_MT_Menu,    M7A_DOPE_TIME_panel,
    M7A_KEYFRAMES_panel, M7A_JUMP_KEYFRAME_through, M7A_JUMP_KEYFRAME_back,
);

def register():
    global bl_conf;
    
    Scene.m7a_jump_frame = IntProperty(default=15);
    
    r_unregister_class(bl_conf, "DOPESHEET_HT_header");
    q_register_class(classes);
    
def unregister():
    global bl_conf;
    
    q_unregister_class(classes);
    r_register_class(bl_conf, "DOPESHEET_HT_header");
    
    r_remove_attr(Scene, "m7a_jump_frame");
