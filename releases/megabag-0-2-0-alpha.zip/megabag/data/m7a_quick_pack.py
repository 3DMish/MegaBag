#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/m7a_quick_pack/");

from bpy_sys import (
    q_register_class, q_unregister_class, r_remove_attr,
    ver_more, get_prop, lc_center_label, lc_set_width,
);

from bpy.types import Panel, Scene;
from bpy.props import EnumProperty;

if ver_more(2,80,0):
    import m7a_gpencil_panel, m7a_gpencil_library, m7a_asset_properties;
    
import m7a_armature_panel,    m7a_camera_panel, m7a_empty_panel;
import m7a_mesh_panel,        m7a_mesh_library, m7a_curve_panel;
import m7a_custom_properties, m7a_text_panel,   m7a_other_panels;

class M7A_VIEW3D_PT_QUICK_Pack(Panel):
    bl_space_type  = 'VIEW_3D';
    bl_region_type = 'UI' if ver_more(2,80,0) else "TOOLS";
    bl_category    = "Quick Pack";
    bl_label       = "Quick Pack";
    
    def draw(self, context):
        a_obj = context.active_object;
        
        lc_main = self.layout.column(align = True);
        
        lc_main.row(align=True).prop(context.scene, "m7a_megabag_panel", expand=True);
        lc_main.separator();
        
        if (context.scene.m7a_megabag_panel == "props"):
            if (a_obj != None):
                    
                # --------------------------------------------------------
                
                if   (a_obj.type == "MESH"):     m7a_mesh_panel.draw_panel(lc_main, context);
                elif (a_obj.type == "CURVE"):    m7a_curve_panel.draw_panel(lc_main, context);
                elif (a_obj.type == "ARMATURE"): m7a_armature_panel.draw_panel(lc_main, context);
                elif (a_obj.type == "GPENCIL"):  m7a_gpencil_panel.draw_panel(lc_main, context);
                elif (a_obj.type == "FONT"):     m7a_text_panel.draw_panel(lc_main, context);
                elif (a_obj.type == "CAMERA"):   m7a_camera_panel.draw_panel(lc_main, context);
                elif (a_obj.type == "EMPTY"):    m7a_empty_panel.draw_panel(lc_main, context);
                    
                else: m7a_other_panels.draw_panel(lc_main, context);
                    
                # --------------------------------------------------------
                    
                if ("m7a_asset" in a_obj.data):
                    lc_main.separator();
                    m7a_asset_properties.draw_panel(lc_main, context);
                
                # --------------------------------------------------------
                    
                if (get_prop("view3d_custom_props")):
                    lc_main.separator();
                    m7a_custom_properties.draw_panel(lc_main, context);
            else:
                lc_main.separator();
                lc_center_label(lc_main, "No selected objects").active=False;
                
        else:
            if (context.active_object):
                path = context.active_object;
                if (context.mode == "POSE") and (context.active_pose_bone):
                    path = context.active_pose_bone;
                
                m7a_obj_transform(
                    lc_main, "Location:", "transform.translate", 
                    "OBJECT_ORIGIN" if ver_more(3,0,0) else "MAN_TRANS", 
                    "location", "lock_location", path,
                );
                
                lc_main.separator();
                
                lc_rot = m7a_obj_transform(
                    lc_main, "Rotation:", "transform.rotate", 
                    "ORIENTATION_GIMBAL" if ver_more(3,0,0) else "MAN_ROT", 
                    "rotation_euler", "lock_rotation", path,
                );
                
                if ver_more(3,0,0): lc_rot.use_property_split = True;
                lc_main_row = lc_rot.row(align = True);
                
                lc_row_col = lc_main_row.column(align = True);
                lc_set_width(lc_row_col, 0.7, 0.1);
                lc_row_col.label(text=""); 
                lc_main_row.prop(path, "rotation_mode", text="");
                if (context.mode == "POSE"): 
                    lc_main_row.operator("pose.quaternions_flip", text="", icon="GRAPH", emboss=False);  
                    lc_main.use_property_split = False;
                else:
                    lc_main_row.label(text="", icon="BLANK1"); 
                    if ver_more(3,0,0): lc_main.use_property_split = False;
                
                lc_main.separator();
                
                m7a_obj_transform(
                    lc_main, "Scale:", "transform.resize", 
                    "TRANSFORM_ORIGINS" if ver_more(3,0,0) else "MAN_SCALE", 
                    "scale", "lock_scale", path,
                );
                
                if not (context.mode == "POSE"):
                    lc_main.separator();
                    
                    m7a_obj_transform(
                        lc_main, "Dimensions:", "", 
                        "CUBE" if ver_more(3,0,0) else "BBOX", "dimensions", ""
                    );

def m7a_obj_transform(lc_main, label, action_id, icon, path_id, lock_id, path = ""):
    #lc_main = lc_main.box().column(align = True);
    lc_row = lc_main.row(align = True);
    lc_row.label(text=label, icon=icon);
    if not (action_id == ""):
        lc_row.operator(
            action_id, text="", 
            icon="RESTRICT_SELECT_ON" if (ver_more(3,0,0)) else "RESTRICT_SELECT_OFF", 
            emboss=False
        );
    
    if (path == ""): path = bpy.context.active_object;
    
    def item(id, w = False, id_w = "lock_rotation_w"):
        lc_main_row = lc_main.row(align = True); 
        
        if (ver_more(3,0,0)): 
            lc_row_col = lc_main_row.column(align = True);
            lc_set_width(lc_row_col, 0.7, 0.1);
            if (w == True): lc_row_col.label(text="W:");
            lc_row_col.label(text="X:"); lc_row_col.label(text="Y:"); lc_row_col.label(text="Z:");
        
        if not (lock_id == ""): 
            lc_row_col = lc_main_row.column(align = True);
            lc_set_width(lc_row_col, 1, 1);
            if (w == True):
                lc_btn = lc_row_col.operator("transform.change", text="", icon="PANEL_CLOSE")
                lc_btn.option = "CLEAR_"+str(id).upper()+"_W";
                lc_btn.hint = "Clear " + str(id) + " [w]";
            lc_btn = lc_row_col.operator("transform.change", text="", icon="PANEL_CLOSE");
            lc_btn.option = "CLEAR_"+str(id).upper()+"_X";
            lc_btn.hint = "Clear " + str(id) + " [x]";
            lc_btn = lc_row_col.operator("transform.change", text="", icon="PANEL_CLOSE");
            lc_btn.option = "CLEAR_"+str(id).upper()+"_Y";
            lc_btn.hint = "Clear " + str(id) + " [y]";
            lc_btn = lc_row_col.operator("transform.change", text="", icon="PANEL_CLOSE");
            lc_btn.option = "CLEAR_"+str(id).upper()+"_Z";
            lc_btn.hint = "Clear " + str(id) + " [z]";
               
        if (lock_id == ""): 
            lc_row = lc_main_row.column(align = True);
            lc_row.prop(path, id, text="");
        else:
            if (ver_more(3,0,0)):
                lc_row = lc_main_row.row(align = True);
                lc_row.use_property_split = True;
                lc_row.prop(path, id, text="");
            else:
                lc_row = lc_main_row.column(align = True);
                lc_row.prop(path, id, text="");
                
        if not (lock_id == ""): 
            if (ver_more(3,0,0)):
                lc_row.use_property_decorate = False;
                lc_roc = lc_row.column(align = True);
            else: lc_roc = lc_main_row.column(align = True);
            if (ver_more(3,0,0)):
                if (w == True): lc_roc.prop(path, id_w, text="", emboss=False, icon='DECORATE_UNLOCKED');
                lc_roc.prop(path, lock_id, text="", emboss=False, icon='DECORATE_UNLOCKED');
            else:
                if (w == True): lc_roc.prop(path, id_w, text="", icon="UNLOCKED");
                lc_roc.prop(path, lock_id, text="", icon='UNLOCKED');
    
    
    if (path_id == "rotation_euler"):
        if (path.rotation_mode == 'QUATERNION'):
            item("rotation_quaternion", True);
        elif (path.rotation_mode == 'AXIS_ANGLE'):
            item("rotation_axis_angle", True);
        else: item(path_id);
    else: item(path_id)
    
    return lc_main;

def register_nodes (self, context):
    if (get_prop("view3d_quick_pack")): register();
    else: unregister();
    
classes = [
    M7A_VIEW3D_PT_QUICK_Pack,
];

def register ():
    Scene.m7a_megabag_panel = EnumProperty(
        items=[
            ("transform", "Transform", "Transform"), 
            ("props", "Properties", "Properties")
        ],
    );
    
    m7a_mesh_library.register();
    m7a_mesh_panel.register();
    m7a_armature_panel.register();

    if ver_more(2,80,0):
        m7a_gpencil_panel.register();
        m7a_gpencil_library.register();
        m7a_asset_properties.register();
    
    q_register_class(classes);
    
def unregister ():
    q_unregister_class(classes);
    
    m7a_mesh_library.unregister();
    m7a_mesh_panel.unregister();
    m7a_armature_panel.unregister();
    
    if ver_more(2,80,0):
        m7a_gpencil_panel.unregister();
        m7a_gpencil_library.unregister();
        m7a_asset_properties.unregister();
    
    r_remove_attr(Scene, "m7a_megabag_panel");
