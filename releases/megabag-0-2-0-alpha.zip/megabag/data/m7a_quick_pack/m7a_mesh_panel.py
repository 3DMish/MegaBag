#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Operator;

from bpy_sys import (
    bpy_preferences, lc_switcher, lc_add_btn, ver_more, get_prop, lc_width,
    q_register_class, q_unregister_class, lc_cont_x, lc_icon, ver_less,
);

import m7a_mesh_library;

def draw_panel(lc_main, context):
    
    a_obj = context.active_object;
    
    if (context.mode in {"OBJECT"}): # -----------------------------------------------
        lc_swtch_row = lc_switcher(lc_main, context, "Mesh", icon="MESH_DATA");
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT", 'EDIT', False);
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.operator("object.shade_smooth", icon='SHADING_RENDERED' if ver_more(2,90,0) else "SOLID");
        if ver_more(3,3,0):
            lc_row.operator("object.shade_smooth", icon='SHADING_RENDERED', text="").use_auto_smooth = True;
        lc_row = lc_row.row(align = True);
        lc_row.operator("object.shade_flat", icon='SHADING_WIRE' if ver_more(2,90,0) else "WIRE", text="" if ver_more(3,3,0) else "Flat");
        if ver_more(2,90,0) and ver_less(3,3,0): lc_row.scale_x = 0.5;
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.prop(a_obj.data, 'use_auto_smooth', text='', icon="CHECKBOX_HLT" if a_obj.data.use_auto_smooth else "CHECKBOX_DEHLT");
        lc_row_com = lc_row.row(align = True);
        lc_row_com.active = a_obj.data.use_auto_smooth;
        lc_row_com.prop(a_obj.data, 'auto_smooth_angle', text='Auto Smooth');
        
        lc_main.separator();
        
        lc_main.operator("object.data_transfer", icon='MOD_DATA_TRANSFER');
    
    elif (context.mode in {"EDIT_MESH"}): # -----------------------------------------------
        lc_swtch_row = lc_switcher(lc_main, context, "Mesh", icon="MESH_DATA", convert=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "VPAINT_HLT",      'VERTEX_PAINT', False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "SCULPTMODE_HLT",  'SCULPT',       False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',       False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "WPAINT_HLT",      'WEIGHT_PAINT', False);
        
        if (get_prop("view3d_mesh_library")): 
            lc_main.separator();
            m7a_mesh_library.draw_panel(lc_main, context);
            
        lc_main.separator();
            
        lc_row = lc_main.row(align = True);
        lc_row.operator(
            "transform.translate", text="Move" if (lc_width() > 140) else " ", 
            icon="OBJECT_ORIGIN" if (ver_more(3,0,0)) else "MAN_TRANS"
        );
        lc_row.operator(
            "transform.rotate", text="Rotate" if (lc_width() > 210) else "" if (lc_width() > 140) else " ", 
            icon="ORIENTATION_GIMBAL" if (ver_more(3,0,0)) else "MAN_ROT"
        );
        lc_row.operator(
            "transform.resize", text="Scale" if (lc_width() > 210) else "" if (lc_width() > 140) else " ", 
            icon="TRANSFORM_ORIGINS" if (ver_more(3,0,0)) else "MAN_SCALE"
        );
        
        lc_row = lc_main.row(align = True);
        lc_row.menu("VIEW3D_MT_transform", text="", icon="DRIVER_TRANSFORM");
        lc_row.separator();
        if (ver_more(3,0,0)): lc_row.prop(bpy_preferences().view, 'gizmo_size', text='Gismo Size:');
        else: lc_row.prop(bpy_preferences().view, 'manipulator_size', text='Gismo Size:');
        
        lc_row.operator("preferences.reset_gizmo_size", text="", icon="X");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.operator("mesh.symmetrize", icon="MOD_MIRROR");
        lc_row = lc_cont_x(lc_row, 0.9);
        lc_row.menu("VIEW3D_MT_edit_mesh_normals", icon="NORMALS_FACE" if ver_more(3,0,0) else "SNAP_NORMAL");
        
        lc_row = lc_main.row(align = True);
        lc_row.operator("mesh.separate", icon="NLA_PUSHDOWN", text="Separate Selected").type = 'SELECTED';
        lc_row.operator("mesh.separate", icon="MATERIAL_DATA", text="").type = 'MATERIAL';
        lc_row.operator("mesh.separate", icon="STICKY_UVS_DISABLE", text="").type = 'LOOSE';
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.operator_menu_enum("mesh.merge", "type", text="Merge", icon="AUTOMERGE_ON");
        lc_row.operator("mesh.merge", text="", icon="CENTER_ONLY" if ver_more(3,0,0) else "FULLSCREEN_EXIT").type="CENTER";
        lc_row.operator("mesh.remove_doubles", text="", icon="CON_DISTLIMIT" if ver_more(3,0,0) else "ARROW_LEFTRIGHT");
        lc_row.separator();
        if ver_more(3,0,0): lc_row.operator("mesh.edge_split", text="", icon="MOD_EDGESPLIT").type = 'EDGE';
        else: lc_row.operator("mesh.edge_split", text="", icon="MOD_EDGESPLIT");
        
        lc_main.separator();
        
        lc_main.operator("transform.shrink_fatten", icon="CON_SHRINKWRAP" if ver_more(3,0,0) else "FULLSCREEN_EXIT");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.operator("mesh.mark_sharp");
        lc_row.operator("mesh.mark_sharp", icon="X", text="").clear = True;
                            
        lc_main.separator();

        lc_row = lc_main.row(align = True);
        lc_row.menu("VIEW3D_MT_edit_mesh_delete", icon="TRASH" if ver_more(3,0,0) else "X");
        lc_row.prop(context.active_object, "display_type", text="", icon="VIS_SEL_10" if ver_more(3,0,0) else "RESTRICT_VIEW_OFF");
        
        lc_main.separator();
        
    elif (context.mode in {"SCULPT"}): # -----------------------------------------------
        lc_swtch_row = lc_switcher(lc_main, context, "Mesh", icon="MESH_DATA", convert=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "VPAINT_HLT",      'VERTEX_PAINT', False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",    'EDIT',         False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',       False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "WPAINT_HLT",      'WEIGHT_PAINT', False);
        
        lc_main.separator();
    
    elif (context.mode in {"PAINT_VERTEX"}): # -----------------------------------------------
        lc_swtch_row = lc_switcher(lc_main, context, "Mesh", icon="MESH_DATA", convert=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",    'EDIT',         False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "SCULPTMODE_HLT",  'SCULPT',       False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',       False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "WPAINT_HLT",      'WEIGHT_PAINT', False);
        
        lc_main.separator();
        
        vertex_paint = context.tool_settings.vertex_paint;
        
        lc_main.template_ID_preview(vertex_paint, "brush", new="brush.add", rows=3, cols=8, hide_buttons=True);
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.operator("paint.vertex_color_set", text="", icon_value=lc_icon("COLOR_FILL"));
        lc_row.prop(vertex_paint.brush, "color", text="");
        lc_row.prop(vertex_paint.brush, "blend", text="");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.prop(context.tool_settings.unified_paint_settings, "size", slider=True);
        lc_row.prop(vertex_paint.brush, "use_pressure_size", text="", slider=True);
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.prop(vertex_paint.brush, "strength");
        lc_row.prop(vertex_paint.brush, "use_pressure_strength", text="");
    
    elif (context.mode in {"PAINT_WEIGHT"}): # -----------------------------------------------
        lc_swtch_row = lc_switcher(lc_main, context, "Mesh", icon="MESH_DATA", convert=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",    'EDIT',         False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "SCULPTMODE_HLT",  'SCULPT',       False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',       False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "VPAINT_HLT",      'VERTEX_PAINT', False);
        
        lc_main.separator();
        
        brush = context.tool_settings.weight_paint.brush;
        unified_paint_settings = context.tool_settings.unified_paint_settings;
        weight_paint = context.tool_settings.weight_paint;
        
        lc_main.template_ID_preview(weight_paint, "brush", new="brush.add", rows=3, cols=8, hide_buttons=False);
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        if not (unified_paint_settings.use_unified_weight): lc_row.prop(brush, "weight", text="Weight");
        else: lc_row.prop(unified_paint_settings, "weight", text="Weight");
        lc_row.operator("object.vertex_group_smooth", text="", icon="MOD_FLUIDSIM");
        lc_row.prop(unified_paint_settings, "use_unified_weight", text="", icon="BRUSHES_ALL");
        
        lc_row = lc_main.row(align = True);
        lc_row.prop(unified_paint_settings, "size", text="Radius");
        lc_row.prop(brush, "use_pressure_size", text="");
        lc_row.prop(unified_paint_settings, "use_unified_size", text="", icon="BRUSHES_ALL");
        
        lc_row = lc_main.row(align = True);
        if not (unified_paint_settings.use_unified_strength): lc_row.prop(brush, "strength");
        else: lc_row.prop(unified_paint_settings, "strength");
        lc_row.prop(brush, "use_pressure_strength", text="");
        lc_row.prop(unified_paint_settings, "use_unified_strength", text="", icon="BRUSHES_ALL");
        
        lc_main.separator(); # -------------------------------------------------------------
        
        lc_row = lc_main.row(align = True);
        lc_row_btn = lc_cont_x(lc_row, 0.8);
        lc_row_btn.prop(brush, "stroke_method", text="");
        
        if (brush.stroke_method in {'SPACE', 'LINE', 'CURVE'}):
            lc_row.prop(brush, "spacing", text="Spacing");
            if (brush.stroke_method in {'SPACE'}):
                lc_row.prop(brush, "use_pressure_spacing", text="");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.prop(brush, "use_smooth_stroke", text="", icon="MOD_SMOOTH");
        lc_row.prop(brush, "smooth_stroke_radius", text="Radius");
        lc_main.prop(brush, "smooth_stroke_factor", text="Stroke Factor");
        
        # bpy.data.brushes["Draw"].use_pressure_spacing
        
    elif (context.mode in {"PAINT_TEXTURE"}): # -----------------------------------------------
        lc_swtch_row = lc_switcher(lc_main, context, "Mesh", icon="MESH_DATA", convert=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",    'EDIT',         False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "SCULPTMODE_HLT",  'SCULPT',       False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',       False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "VPAINT_HLT",      'VERTEX_PAINT', False);
        
        lc_main.separator();

class PREFERENCES_OT_reset_gizmo_size (Operator):
    bl_idname      = "preferences.reset_gizmo_size";
    bl_label       = "Reset Gizmo Size";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Reset Gizmo Size";
    
    def execute(self, context):
        if ver_more(3,0,0): bpy_preferences().view.gizmo_size = 75;
        else: bpy_preferences().view.manipulator_size = 75;
        return {'FINISHED'};

classes = [
    PREFERENCES_OT_reset_gizmo_size
];

def register():
    q_register_class(classes);

def unregister():
    q_unregister_class(classes);
