#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy_sys import (
    q_register_class, q_unregister_class, lc_switcher, lc_cont_x,
);

def draw_panel (lc_main, context):
    if (context.mode in {"OBJECT"}): # -----------------------------------------------
        lc_switcher(lc_main, context, "Camera", icon="CAMERA_DATA", convert=False);
        a_obj = context.active_object;
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.prop(a_obj.data, "type", text="");
        if (a_obj.data.type != "ORTHO"):
            lc_row.prop(a_obj.data, "lens", text="");
            
        lc_main.prop(a_obj.data, "lens_unit", text="");
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.prop(a_obj.data, "shift_x", text="Shift X");
        lc_cont_x(lc_row, 0.9).prop(a_obj.data, "shift_y", text="Y");
        
        lc_main.separator();
        
        lc_main.prop(a_obj.data, "clip_start", text="Clip Start");
        lc_main.prop(a_obj.data, "clip_end", text="End");
        
        lc_main.separator();
        
        lc_main.prop(a_obj.data.dof, "use_dof", text="Depth of Field");
        if (a_obj.data.dof.use_dof):
            lc_cont_x(lc_main, 0.8).prop(a_obj.data.dof, "focus_distance", text="Distance");
            lc_cont_x(lc_main, 0.8).prop(a_obj.data.dof, "aperture_fstop", text="F-Stop");
            lc_main.prop(a_obj.data, "show_limits", text="Show Limits", icon="OUTLINER_DATA_EMPTY");
        
        lc_main.separator();
        lc_main.prop(a_obj.data, "show_safe_areas", text="Show Safe Areas");
        if (a_obj.data.show_safe_areas):
            lc_cont_x(lc_main, 1.0).prop(context.scene.safe_areas, "title", text="");
            lc_cont_x(lc_main, 1.0).prop(context.scene.safe_areas, "action", text="");

classes = [
    
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
