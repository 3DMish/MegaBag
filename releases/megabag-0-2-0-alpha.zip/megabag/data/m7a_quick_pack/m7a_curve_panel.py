#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy_sys import (
    q_register_class, q_unregister_class,
    lc_switcher, lc_add_btn, lc_cont_x,
);

def draw_panel (lc_main, context):
    a_obj = context.active_object;
    
    if (context.mode in {"OBJECT", "EDIT_CURVE"}): # ------------------------------------
    
        if (context.mode in {"OBJECT"}): # ------------------------------------
            lc_swtch_row = lc_switcher(lc_main, context, "Curve", icon="CURVE_DATA");
            lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT", 'EDIT', False);
        elif (context.mode in {"EDIT_CURVE"}): # ------------------------------
            lc_swtch_row = lc_switcher(lc_main, context, "Curve", icon="CURVE_DATA", convert=False, asset=False);
            lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT', False);
        
        lc_main.separator();
        
        lc_main.prop(a_obj.data, "fill_mode", text="");
        
        lc_main.separator();
        
        lc_box = lc_main.box().column(); # ----------------------------------------------     
        lc_cont_x(lc_box, 1).prop(a_obj.data, "bevel_mode", expand=True);
        
        lc_box.separator();

        lc_col = lc_box.column();
        lc_row = lc_box.row(align = True);
        if (a_obj.data.bevel_mode == 'OBJECT'):
            lc_row.prop(a_obj.data, "bevel_object", text="");
        else:
            lc_col.prop(a_obj.data, "bevel_depth", text="Depth");
            lc_row.prop(a_obj.data, "bevel_resolution", text="Resolution");
        lc_row.prop(
            a_obj.data, "use_fill_caps", text="", 
            icon="LAYER_ACTIVE" if (a_obj.data.use_fill_caps) else "LAYER_USED", 
            toggle=True,
        );
        if (a_obj.data.bevel_mode == 'PROFILE'):
            lc_col.template_curveprofile(a_obj.data, "bevel_profile");
        
        if (context.mode in {"EDIT_CURVE"}): # -----------------------------------------------
            
            lc_main.separator();
            
            lc_row = lc_main.row(align = True);
            lc_cont_x(lc_row, 0.8).operator_menu_enum("curve.spline_type_set", "type", text="Type", icon="FCURVE");
            lc_row.operator_menu_enum("curve.handle_type_set", "type", text="Handle Type", icon="CURVE_BEZCURVE");
            
            lc_main.separator();
            
            lc_row = lc_main.row(align = True);
            lc_row.operator("curve.subdivide", icon="PARTICLE_POINT");
            lc_cont_x(lc_row, 0.9).operator("curve.smooth", icon="MOD_SMOOTH");
            
            lc_main.operator("curve.switch_direction", icon="CURVE_PATH");
            lc_main.operator("curve.make_segment", icon="IPO_LINEAR");
            
            lc_main.separator();
            
            lc_row = lc_main.row(align = True);
            lc_row.operator("curve.select_linked", icon="GP_SELECT_POINTS");        
            lc_row.menu("VIEW3D_MT_hook", text="", icon="HOOK");

classes = [
    
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
