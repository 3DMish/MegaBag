#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from m7a_meshes import m7a_meshes;

from m7a_scripts import (
    m7a_script_add_seam, m7a_script_add_jeans_seam,
);

from bpy_sys import (
    r_remove_attr, data_path, ver_more, ver_less,
    lc_cont_x, lc_split_row, lc_prew,
    q_register_class, q_unregister_class,
);

from bpy.types import Scene, Operator;
from bpy.props import EnumProperty;

bl_conf = {
    "subcategory": [],
    "tmp_items": [],
}

def draw_panel (lc_main, context):
    global bl_conf;
    
    if (context.scene.m7a_mesh_library_category in {'simple', 'scripts', 'other'}): lc_row = lc_main;
    else: lc_row = lc_split_row(lc_main, 150);
    
    lc_row.prop(context.scene, "m7a_mesh_library_category", text="");
    if (context.scene.m7a_mesh_library_subcategory not in {"", "none"}):
        lc_cont_x(lc_row, 0.8).prop(context.scene, "m7a_mesh_library_subcategory", text="");
        
    if (context.scene.m7a_mesh_library_category not in {'simple', 'scripts', 'other'}):
        lc_row = lc_split_row(lc_main, 150);
        lc_cont_x(lc_row, 0.8).prop(context.scene, "m7a_mesh_library_gender", text="");
        if (context.scene.m7a_mesh_library_parts not in {"", "none"}):
            lc_row.prop(context.scene, "m7a_mesh_library_parts", text="");
        
    lc_main.template_icon_view(context.scene, "m7a_mesh_library_viewer", show_labels = True);
    
    lc_row = lc_main.row(align = True);
    def btn_add_mesh_or_script(lc_layout, icon):
        if (context.scene.m7a_mesh_library_category in {'scripts'}) or \
           (context.scene.m7a_mesh_library_subcategory in {'script'}):
                lc_layout.operator("mesh.run_script", icon=icon);
        else: lc_layout.operator("mesh.library_add", icon=icon);
        
    if ver_more(2,80,0): btn_add_mesh_or_script(lc_row, "BACK");
    lc_row.operator("m7a.mesh_library_info", text="", icon="QUESTION");
    if ver_less(2,80,0): btn_add_mesh_or_script(lc_row, "FORWARD");

class M7A_MESH_LIBRARY_RUN_Button (Operator):
    bl_idname      = "mesh.run_script";
    bl_label       = "Run Script";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Run script in active object";
    
    def execute(self, context):
        name = context.scene.m7a_mesh_library_viewer;
        if   (name == "M7A-7913-SCRIPT-8755933"): m7a_script_add_seam();
        elif (name == "M7A-7913-SCRIPT-8755934"): m7a_script_add_jeans_seam();
        return {'FINISHED'};
    
class M7A_MESH_LIBRARY_ADD_Button (Operator):
    bl_idname      = "mesh.library_add";
    bl_label       = "Add Mesh in Object";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Add mesh to active object";
    
    def execute(self, context):
        a_obj = context.active_object;
        name = context.scene.m7a_mesh_library_viewer;
        if (name != ""):
            bpy.ops.mesh.select_all(action='DESELECT');
                
            bpy.ops.object.mode_set(mode='OBJECT', toggle=False);
            bpy.ops.wm.append(directory=data_path+"/m7a_mesh_data.blend/Object", filename=name);
                
            l_obj = bpy.data.objects[name];
            if ver_more(2,80,0):
                l_obj.hide_viewport = False;
                l_obj.location = context.scene.cursor.location;
            else:
                l_obj.hide = False;
                l_obj.location = context.scene.cursor_location;
                
            bpy.ops.object.select_all(action='DESELECT');
                
            if ver_more(2,80,0):
                a_obj.select_set(True); l_obj.select_set(True);
                bpy.context.view_layer.objects.active = a_obj;
            else:
                a_obj.select = True; l_obj.select = True;
                bpy.context.scene.objects.active = a_obj;
                
            bpy.ops.object.join();
                
            bpy.ops.object.mode_set(mode='EDIT', toggle=False);
            
        return {'FINISHED'};

class M7A_MESH_LIBRARY_Info (Operator):
    bl_idname       = 'm7a.mesh_library_info';
    bl_label        = 'Info';
    bl_description  = 'Info about items in Mesh Library';
    
    @staticmethod
    def draw(self, context):
        lc_main = self.layout.column(align = True);
        lc_main.label(text="Commercial Info:", icon="QUESTION");
        lc_main.separator(); lc_icon = "DOT" if ver_more(2,80,0) else "LAYER_ACTIVE";
        lc_main.label(text=" All   meshes  in   this   ''Quick Pack''  modeled", icon=lc_icon);
        lc_main.label(text="  by   3DMish   (Mish7913),     under   CC0   Licence");
        lc_main.label(text="  [Public Domain], it's absolutly free for commercial");
        lc_main.label(text="  and non-commercial use, fill free to use it...");
    
    def invoke(self, context, event):
        context.window_manager.invoke_popup(self, width=265);
        return {'RUNNING_MODAL'}
        
    def execute(self, context): return {'FINISHED'};
    
class m7a_enum_category ():
    def __init__(self, category, label):
        self.result = [("", label, "")];
        self.category = category;
        self.items = 0;
    
    def add_item (self, item):
        if (item == (None)): self.result.append(item);
        elif (self.category in m7a_meshes):
            if (item[0] in m7a_meshes[self.category]):
                if (m7a_meshes[self.category][item[0]] != []):
                    self.result.append(item); self.items += 1;
        
    def get_all (self):
        if (self.items < 1): return [];
        else: return self.result;

def m7a_mesh_library_subcategories (self, context):
    global bl_conf; bl_conf["subcategory"] = [];
    
    if (hasattr(context.scene, "m7a_mesh_library_category")):
        category = context.scene.m7a_mesh_library_category;
            
        if (category in ['a_birds']):
            enum_category = m7a_enum_category(category, "Poultry");
            enum_category.add_item(("chicken", "Chicken", "Mesh list of chicken's parts"));
            enum_category.add_item(("turkey",  "Turkey",  "Mesh list of turkey's parts"));
            enum_category.add_item((None));
            enum_category.add_item(("duck",    "Duck",    "Mesh list of duck's parts"));
            enum_category.add_item(("goose",   "Goose",   "Mesh list of goose's parts"));
            enum_category.add_item(("swan",    "Swan",    "Mesh list of swan's parts"));
            enum_category.add_item((None));
            enum_category.add_item(("pigeon",  "Pigeon",  "Mesh list of pigeon's parts"));
            enum_category.add_item(("ostrich", "Ostrich", "Mesh list of ostrich's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Passerine");
            enum_category.add_item(("sparrow",  "Sparrow",  "Mesh list of sparrow's parts"));
            enum_category.add_item(("tit",      "Tit",      "Mesh list of great_tit's parts"));
            enum_category.add_item(("cardinal", "Cardinal", "Mesh list of cardinal's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Parrots‎");
            enum_category.add_item(("budgerigar",  "Budgerigar",  "Mesh list of budgerigar's parts"));
            enum_category.add_item(("blue_macaw",  "Blue Macaw",  "Mesh list of macaw's parts"));
            enum_category.add_item(("red_macaw",   "Red Macaw",   "Mesh list of macaw's parts"));
            enum_category.add_item(("cockatoo",    "Cockatoo",    "Mesh list of cockatoo's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Waterbird");
            enum_category.add_item(("stork",    "Stork",    "Mesh list of stork's parts"));
            enum_category.add_item(("ardea",    "Ardea",    "Mesh list of ardea's parts"));
            enum_category.add_item(("flamingo", "Flamingo", "Mesh list of flamingo's parts"));
            enum_category.add_item((None));
            enum_category.add_item(("penguin",  "Penguin",  "Mesh list of penguin's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Raptors");
            enum_category.add_item(("eagle", "Eagle", "Mesh list of eagle's parts"));
            enum_category.add_item(("hawk",  "Hawk",  "Mesh list of hawk's parts"));
            enum_category.add_item(("kite",  "Kite",  "Mesh list of kite's parts"));
            enum_category.add_item(("owl",   "Owl",   "Mesh list of owl's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Others");
            enum_category.add_item(("woodpecker",  "Woodpecker",         "Mesh list of woodpecker's parts"));
            enum_category.add_item(("toucan",      "Keel-billed Toucan", "Mesh list of toucan's parts"));
            enum_category.add_item((None));
            enum_category.add_item(("hummingbird", "Hummingbird",        "Mesh list of hummingbird's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
        elif (category in ['a_cattles']):
            enum_category = m7a_enum_category(category, "Farm Cattles");
            enum_category.add_item(("cow",   "Cow",   "Mesh list of cow's parts"));
            enum_category.add_item(("goat",  "Goat",  "Mesh list of goat's parts"));
            enum_category.add_item(("horse", "Horse", "Mesh list of horse's parts"));
            enum_category.add_item(("pony",  "Pony",  "Mesh list of pony's parts"));
            enum_category.add_item(("sheep", "Sheep", "Mesh list of sheep's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Wild Cattles");
            enum_category.add_item(("deer",     "Deer",     "Mesh list of pony's parts"));
            enum_category.add_item(("antelope", "Antelope", "Mesh list of antelope's parts"));
            enum_category.add_item((None));
            enum_category.add_item(("elephant", "Elephant", "Mesh list of elephant's parts"));
            enum_category.add_item(("camel",    "Camel",    "Mesh list of camel's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
        elif (category in ['a_beasts']):
            enum_category = m7a_enum_category(category, "Cats");
            enum_category.add_item(("cat",     "Cat",     "Mesh list of cat's parts"));
            enum_category.add_item((None));
            enum_category.add_item(("cheetah", "Cheetah", "Mesh list of cheetah's parts"));
            enum_category.add_item(("leopard", "Leopard", "Mesh list of leopard's parts"));
            enum_category.add_item(("lion",    "Lion",    "Mesh list of lion's parts"));
            enum_category.add_item(("tigger",  "Tigger",  "Mesh list of tigger's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Dogs");
            enum_category.add_item(("dog",    "Dog",    "Mesh list of dog's parts"));
            enum_category.add_item((None));
            enum_category.add_item(("coyote", "Coyote", "Mesh list of coyote's parts"));
            enum_category.add_item(("fox",    "Fox",    "Mesh list of fox's parts"));
            enum_category.add_item(("wolf",   "Wolf",   "Mesh list of wolf's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Beras");
            enum_category.add_item(("brown_bear",   "Brown Bear",   "Mesh list of bear's parts"));
            enum_category.add_item(("grizzly_bear", "Grizzly Bear", "Mesh list of bear's parts"));
            enum_category.add_item(("polar_bear",   "Polar Bear",   "Mesh list of bear's parts"));
            enum_category.add_item(("panda",        "Panda",        "Mesh list of panda's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
        elif (category in ['a_rodent']):
            enum_category = m7a_enum_category(category, "Rodents");
            enum_category.add_item(("mouse", "Mouse", "Mesh list of mouse's parts"));
            enum_category.add_item(("rat",   "Rat",   "Mesh list of rat's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            
        elif (category in ['a_reptiles']):
            enum_category = m7a_enum_category(category, "Snakes");
            enum_category.add_item(("cobra", "Cobra", "Mesh list of cobra's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
        elif (category in ['a_arthropod']):
            enum_category = m7a_enum_category(category, "Insects");
            enum_category.add_item(("ant",       "Ant",       "Mesh list of ant's parts"));
            enum_category.add_item(("butterfly", "Butterfly", "Mesh list of butterfly's parts"));
            enum_category.add_item(("bee",       "Bee",       "Mesh list of bee's parts"));
            enum_category.add_item(("fly",       "Fly",       "Mesh list of fly's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Bugs (Beetle)");
            enum_category.add_item(("bug_ladybug",  "Ladybug",         "Mesh list of ladybug's parts"));
            enum_category.add_item(("bug_colorado", "Colorado Beetle", "Mesh list of colorado beetle's parts"));
            enum_category.add_item(("bug_hercules", "Hercules Beetle", "Mesh list of hercules beetle's parts"));
            enum_category.add_item(("bug_dung",     "Dung Beetle",     "Mesh list of dung beetle's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Spiders");
            enum_category.add_item(("tarantula", "Tarantula", "Mesh list of tarantula's parts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
        elif (category in ['clothes']):
            enum_category = m7a_enum_category(category, "Clothes");
            enum_category.add_item(("mesh",   "Meshes",  "Mesh list of clothes's parts"));
            enum_category.add_item(("script", "Scripts", "Script list of clothes effect"));
            bl_conf["subcategory"] += enum_category.get_all();
            
        elif (category in ['simple']):
            enum_category = m7a_enum_category(category, "Simple Meshes");
            enum_category.add_item(("geometric",  "Geometric",  "Mesh list of geometric figures objects"));
            bl_conf["subcategory"] += enum_category.get_all();
            
        elif (category in ['scripts']):
            enum_category = m7a_enum_category(category, "Scripts");
            enum_category.add_item(("all",  "All",  "All Scripts"));
            bl_conf["subcategory"] += enum_category.get_all();
            
        elif (category in ['other']):
            enum_category = m7a_enum_category(category, "Furnitures");
            enum_category.add_item(("handle",  "Handle",  "Mesh list of handles"));
            enum_category.add_item(("keyhole", "Keyhole", "Mesh list of keyholes"));
            bl_conf["subcategory"] += enum_category.get_all();
            
            enum_category = m7a_enum_category(category, "Technology");
            enum_category.add_item(("wheel",  "Wheel",  "Mesh list of wheels"));
            bl_conf["subcategory"] += enum_category.get_all();
            
    if (bl_conf["subcategory"] == []): bl_conf["subcategory"] = [("none",  "none",  "none", 0, 0)];
        
def m7a_mesh_library_get_subcategories (self, context):
    global bl_conf;
    if (bl_conf["subcategory"] != []): return bl_conf["subcategory"];
    else: return [("none",  "none",  "none", 0, 0)];

def m7a_mesh_library_get_parts (self, context):
    global bl_conf; result = [];
    
    category = context.scene.m7a_mesh_library_category;
    subcategory = context.scene.m7a_mesh_library_subcategory;
    type = context.scene.m7a_mesh_library_gender;
    
    if (category in m7a_meshes.keys()):
        if (category in {'humans'}):
            if (type in m7a_meshes[category].keys()):
                for key in m7a_meshes[category][type].keys():
                    if (m7a_meshes[category][type][key] != []):
                        label = (key[0:1].upper()+key[1:]).replace("Base_forms", "Base Forms");
                        id = m7a_meshes[category][type][key][0][1];
                        result.append( (key, label, 'Mesh list of '+key, 0, id) );
                        if ver_more(2,80,0) and (key == "base_forms"): result.append( (None) );
                        
        elif (category in {'clothes'}):
            if (subcategory in m7a_meshes[category].keys()):
                for key in m7a_meshes[category][subcategory].keys():
                    if (m7a_meshes[category][subcategory][key] != []):
                        label = (key[0:1].upper()+key[1:]).replace("Base_forms", "Base Forms");
                        id = m7a_meshes[category][subcategory][key][0][1];
                        result.append( (key, label, 'Mesh list of '+key, 0, id) );
                        if ver_more(2,80,0) and (key == "base_forms"): result.append( (None) );
                        
        else:
            if (subcategory in m7a_meshes[category].keys()):
                if (type in m7a_meshes[category][subcategory].keys()):
                    for key in m7a_meshes[category][subcategory][type].keys():
                        if (m7a_meshes[category][subcategory][type][key] != []):
                            label = (key[0:1].upper()+key[1:]).replace("Base_forms", "Base Forms");
                            id = m7a_meshes[category][subcategory][type][key][0][1];
                            result.append( (key, label, 'Mesh list of '+key, 0, id) );
                            if ver_more(2,80,0) and (key == "base_forms"): result.append( (None) );
    
    if (result == []): result = [("none",  "none",  "none", 0, 0)];
    
    return result;
    
def m7a_mesh_library_get_items (self, context):
    global bl_conf; result = [];
    
    category = context.scene.m7a_mesh_library_category;
    subcategory = context.scene.m7a_mesh_library_subcategory;
    gender = context.scene.m7a_mesh_library_gender;
    parts = context.scene.m7a_mesh_library_parts;
    
    def add_item(view_list, items):
        items = list(items); # items.sort();
        for item in items:
            if not (item[0] == "id"):
                image = data_path + "/m7a_img/" + item[1];
                if (image in lc_prew): thumb = lc_prew[image];
                else: thumb = lc_prew.load(image, image, 'IMAGE');
                view_list.append( (item[1], item[2], item[3], thumb.icon_id, item[0]));
        
    if (category in m7a_meshes.keys()):
        if (category in {'humans'}):
            if (gender in m7a_meshes[category].keys()):
                if (parts in m7a_meshes[category][gender].keys()):
                    if (m7a_meshes[category][gender][parts] != []):
                        add_item(result, m7a_meshes[category][gender][parts]);
        elif (category in {'clothes'}):
            if (subcategory in m7a_meshes[category].keys()):
                if (parts in m7a_meshes[category][subcategory].keys()):
                    if (m7a_meshes[category][subcategory][parts] != []):
                        add_item(result, m7a_meshes[category][subcategory][parts]);
        elif (category in {'simple', 'scripts', 'other'}):
            if (subcategory in m7a_meshes[category].keys()):
                if (m7a_meshes[category][subcategory] != []):
                    add_item(result, m7a_meshes[category][subcategory]);
        else:
            if (subcategory in m7a_meshes[category].keys()):
                if (gender in m7a_meshes[category][subcategory].keys()):
                    if (parts in m7a_meshes[category][subcategory][gender].keys()):
                        if (m7a_meshes[category][subcategory][gender][parts] != []):
                            add_item(result, m7a_meshes[category][subcategory][gender][parts]);
    
    return result;
    
def m7a_mesh_library_category_changed (self, context):
    m7a_mesh_library_subcategories(self, context);
    m7a_mesh_library_subcategory_update(self, context);
    m7a_mesh_library_parts_update(self, context);
    m7a_mesh_library_viewer_update(self, context);

def m7a_mesh_library_viewer_update (self, context):
    global bl_conf;
    if (context.scene.m7a_mesh_library_viewer == ''):
        if (len(m7a_mesh_library_get_items(self, context)) > 0):
            context.scene.m7a_mesh_library_viewer = m7a_mesh_library_get_items(self, context)[0][0];

def m7a_mesh_library_parts_update (self, context):
    item_name = m7a_mesh_library_get_parts(self, context)[0][0];
    if (item_name == ""): item_name = m7a_mesh_library_get_parts(self, context)[1][0];
    context.scene.m7a_mesh_library_parts = item_name;
    
def m7a_mesh_library_subcategory_update (self, context):
    item_name = m7a_mesh_library_get_subcategories(self, context)[0][0];
    if (item_name == ""): item_name = m7a_mesh_library_get_subcategories(self, context)[1][0];
    context.scene.m7a_mesh_library_subcategory = item_name;

classes = [
    M7A_MESH_LIBRARY_ADD_Button, M7A_MESH_LIBRARY_Info, M7A_MESH_LIBRARY_RUN_Button,
];

def register():
    q_register_class(classes);
    
    Scene.m7a_mesh_library_category = EnumProperty(
        name="Category",
        items=[
            ("", "Humans", ""),
            ("humans",   "Humans",            "Mesh list of human's body parts"),
            
            ("", "Animals", ""),
            ("a_birds",     "Birds",          "Mesh list of animals: bird's body parts"),
            ("a_cattles",   "Cattles",        "Mesh list of animals: cattle's body parts"),
            ("a_beasts",    "Beasts",         "Mesh list of animals: beast's body parts"),
            ("a_rodent",    "Rodents",        "Mesh list of animals: rodent's body parts"),
            ("a_reptiles",  "Reptiles",       "Mesh list of animals: reptiles body parts"),
            ("a_arthropod", "Arthropod",      "Mesh list of animals: arthropod's body parts"),
            
            ("", "Other", ""),
            ("simple",     "Simple Meshes",   "Mesh list of simple figures"),
            ("clothes",    "Clothes",         "Mesh list of clothe's parts"),
            ("scripts",    "Python Scripts",  "Scripts list"),
            ("other",      "Other Stuff",     "Mesh list of other stuff"),
        ], 
        default="humans",
        update=m7a_mesh_library_category_changed,
    );
    
    Scene.m7a_mesh_library_subcategory = EnumProperty(
        name="SubCategory", items=m7a_mesh_library_get_subcategories,
        update=m7a_mesh_library_parts_update,
    );
    
    Scene.m7a_mesh_library_gender = EnumProperty(
        items=[("male", "Male", "Male"), ("female", "Female", "Female")],
        default="male", name="",
        update=m7a_mesh_library_viewer_update, 
    );
    
    Scene.m7a_mesh_library_parts = EnumProperty(
        items=m7a_mesh_library_get_parts, name="",
        update=m7a_mesh_library_viewer_update, 
    );
    
    Scene.m7a_mesh_library_viewer = EnumProperty(
        items=m7a_mesh_library_get_items, name="",
    );
    
def unregister():
    q_unregister_class(classes);
    
    r_remove_attr(Scene, "m7a_mesh_library_category");
    r_remove_attr(Scene, "m7a_mesh_library_subcategory");
    r_remove_attr(Scene, "m7a_mesh_library_gender");
    r_remove_attr(Scene, "m7a_mesh_library_parts");
    r_remove_attr(Scene, "m7a_mesh_library_viewer");
