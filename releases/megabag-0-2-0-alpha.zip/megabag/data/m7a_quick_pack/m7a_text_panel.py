#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy_sys import (
    q_register_class, q_unregister_class, lc_cont_x,
    lc_switcher, lc_add_btn, lc_width,
);

def draw_panel (lc_main, context):
    if (context.mode in {"OBJECT"}): # -----------------------------------------------
        lc_swtch_row = lc_switcher(lc_main, context, "Mesh", icon="MESH_DATA");
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT", 'EDIT', False);
    elif (context.mode in {"EDIT_TEXT"}): # -----------------------------------------------
        lc_swtch_row = lc_switcher(lc_main, context, "Mesh", icon="MESH_DATA", asset=False, convert=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT', False);
        
    text = context.active_object.data;
    
    lc_main.separator();
    
    lc_row = lc_main.row(align=True);
    lc_row.prop(text, "size", text="Size");
    lc_cont_x(lc_row, 0.825).prop(text, "fill_mode", text="");
    
    lc_main.separator();
    
    lc_row = lc_main.row(align=True);
    if (lc_row): 
        lc_col = lc_cont_x(lc_row, 0.6, False); # -----------------------
        
        lc_col.label(text="Regular");
        lc_col.label(text="Bold");
        lc_col.label(text="Italic");
        lc_col.label(text="Bold & Italic" if (lc_width() > 270) else "B & I");
        
        lc_col = lc_row.column(align=True); # -----------------------
        lc_col.template_ID(text, "font", open="font.open", unlink="font.unlink");
        lc_col.template_ID(text, "font_bold", open="font.open", unlink="font.unlink");
        lc_col.template_ID(text, "font_italic", open="font.open", unlink="font.unlink");
        lc_col.template_ID(text, "font_bold_italic", open="font.open", unlink="font.unlink");
    
    if (context.mode in {"EDIT_TEXT"}): # -----------------------------------------------
        
        lc_main.separator();
        
        edit_format = context.active_object.data.edit_format;
        
        lc_row = lc_main.row(align=True);
        lc_row.prop(edit_format, "use_bold",       toggle=True);
        lc_row.prop(edit_format, "use_italic",     toggle=True);
        lc_row = lc_main.row(align=True);
        lc_row.prop(edit_format, "use_underline",  toggle=True);
        lc_row.prop(edit_format, "use_small_caps", toggle=True);
    
    lc_main.separator();
    
    lc_main.prop(text, "shear", text="Shear");
    lc_main.prop(text, "extrude", text="Extrude");
    lc_main.prop(text, "offset", text="Offset");
    
    lc_main.separator();
    
    if not (text.bevel_mode == 'OBJECT'):
        lc_row = lc_main.row(align=True);
        lc_row.prop(text, "bevel_depth", text="Depth")
        lc_cont_x(lc_row, 0.825).prop(text, "bevel_resolution", text="");
    
    lc_main.separator();
    
    lc_main.prop(text, "space_character", text="Character Spacing");
    lc_main.prop(text, "space_word",      text="Word Spacing");
    lc_main.prop(text, "space_line",      text="Line Spacing");
    
    lc_main.separator();
    
    lc_row = lc_main.row(align=True);
    lc_cont_x(lc_row, 0.825).prop(text, "align_x", text="");
    lc_row.prop(text, "align_y", text="");
    
    lc_main.separator();
    
    lc_row = lc_main.row(align=True);
    lc_row.prop(text, "offset_x", text="Offset X");
    lc_cont_x(lc_row, 0.825).prop(text, "offset_y", text="Y");
    
classes = [
    
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
