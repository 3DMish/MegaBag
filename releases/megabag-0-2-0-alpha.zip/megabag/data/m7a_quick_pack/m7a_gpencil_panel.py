#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Operator, Scene;
from bpy.props import FloatVectorProperty;

import m7a_gpencil_library;

from bpy_sys import (
    q_register_class, q_unregister_class, lc_icon, r_remove_attr,
    lc_switcher, lc_add_btn, get_prop, lc_width, lc_cont_x,
);

def draw_panel (lc_main, context):
    
    def header ():
        lc_row = lc_main.row(align = True);
        lc_row.operator("ed.undo", icon="LOOP_BACK", text="Undo");
        lc_row.operator("ed.redo", icon="LOOP_FORWARDS", text="Redo");
        
        if (context.scene.camera):
            lc_main.separator();
            lc_main.operator(
                "camera.flip_x", text="X Flip Active Camera", 
                icon = "SCREEN_BACK",
                depress = context.scene.camera.scale.x < 0,
            );
        
        lc_main.separator();
        
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.prop(
            bpy.data.grease_pencils[context.active_object.data.name], "stroke_depth_order", 
            icon='NODE_COMPOSITING', text=''
        );
        
        return lc_btn_row;
    
    def lc_onion_skinning ():
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.prop(context.space_data.overlay, "use_gpencil_onion_skin", icon='MATFLUID'); 
        #lc_btn_row.prop(context.space_data.overlay, "gpencil_fade_layer"); 
        gpl = bpy.data.grease_pencils[context.active_object.data.name].layers[context.active_gpencil_layer.info]
        lc_btn_row.prop(gpl, "use_onion_skinning", text="Layer Onion Skinning" if (context.region.width > 300) else "Layer Oni-S",
            icon='ONIONSKIN_ON' if gpl.use_onion_skinning else 'ONIONSKIN_OFF',
            emboss=True,
        );
    
    if (context.mode in {"OBJECT"}):
        lc_swtch_row = lc_switcher(lc_main, context, "GPencil", icon="OUTLINER_OB_GREASEPENCIL");
        lc_btn = lc_add_btn(lc_swtch_row, "object.mode_set", icon="GREASEPENCIL");
        lc_btn.mode='PAINT_GPENCIL'; lc_btn.toggle=False;
        
        lc_main.separator(); header();
        
        lc_onion_skinning();
    
    elif (context.mode in {"PAINT_GPENCIL"}):
        lc_swtch_row = lc_switcher(lc_main, context, "GPencil", icon="GREASEPENCIL", convert=False, asset=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "SCULPTMODE_HLT",  'SCULPT_GPENCIL', False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",    'EDIT_GPENCIL',   False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',         False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "VPAINT_HLT",      'VERTEX_GPENCIL', False);
        
        lc_main.separator(); header();
        
        lc_onion_skinning();
        
        lc_main.separator();
        
        brush_settings = context.scene.tool_settings.gpencil_paint.brush.gpencil_settings;
        
        lc_main.prop(context.scene.tool_settings, "use_gpencil_draw_onback", icon='MOD_OPACITY');
        lc_main.prop(brush_settings, "active_smooth_factor", icon='MOD_SMOOTH');
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.prop(brush_settings, "use_settings_stabilizer", icon='MOD_SMOOTH', text='');
        lc_btn_row.prop(bpy.data.brushes['Pencil'], "smooth_stroke_radius");
        lc_main.prop(brush_settings, "simplify_factor", icon='GP_ONLY_SELECTED');
        
    elif (context.mode in {"EDIT_GPENCIL"}):
        lc_swtch_row = lc_switcher(lc_main, context, "GPencil", icon="EDITMODE_HLT", convert=False, asset=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "SCULPTMODE_HLT",  'SCULPT_GPENCIL', False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "GREASEPENCIL",    'PAINT_GPENCIL',  False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',         False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "VPAINT_HLT",      'VERTEX_GPENCIL', False);
        
        lc_main.separator(); lc_btn_row = header();
        
        lc_btn_row.operator('gpencil.snap_cursor_to_selected', icon='PIVOT_CURSOR', text='');
        
        lc_onion_skinning();
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        
        lc_row.operator(
            "transform.translate", text="Move" if (lc_width() > 140) else " ", icon="OBJECT_ORIGIN"
        );
        lc_row.operator(
            "transform.rotate", text="Rotate" if (lc_width() > 210) else "" if (lc_width() > 140) else " ", 
            icon="ORIENTATION_GIMBAL"
        );
        lc_row.operator(
            "transform.resize", text="Scale" if (lc_width() > 210) else "" if (lc_width() > 140) else " ", 
            icon="TRANSFORM_ORIGINS"
        );
        
        lc_main.separator();
        
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.operator('gpencil.stroke_arrange', icon='FULLSCREEN_ENTER', text='Top').direction = "TOP";
        lc_btn_row.operator('gpencil.stroke_arrange', text='Up').direction = "UP";
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.operator('gpencil.stroke_arrange', icon='FULLSCREEN_EXIT', text='Bottom').direction = "BOTTOM";
        lc_btn_row.operator('gpencil.stroke_arrange', text='Down').direction = "DOWN";
        
        if hasattr(context.tool_settings.gpencil_vertex_paint.brush, "gpencil_settings"):
            lc_main.separator();
            lc_btn_row = lc_main.row(align = True);
            gpencil_settings = context.tool_settings.gpencil_vertex_paint.brush.gpencil_settings;
            lc_btn_row.operator("gpencil.set_vertex_color_edit", text="", icon_value=lc_icon("COLOR_FILL"));
            lc_cont_x(lc_btn_row, 0.8).prop(context.scene, "m7a_rgb_picker", text='');
            lc_btn_row.prop(gpencil_settings, "vertex_mode", text="");
        
        lc_main.separator();
        
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.operator("gpencil.duplicate_move", text="", icon_value=lc_icon("DUP_MOVE"));
        lc_btn_row.operator("gpencil.copy", text="Copy", icon='COPYDOWN');
        lc_btn_row.operator("gpencil.paste", text="Paste", icon='PASTEDOWN').type = 'ACTIVE';
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.operator_menu_enum("gpencil.stroke_separate", "mode", text="Separate");
        lc_btn_row.operator("gpencil.paste", text="Paste by Layer").type = 'LAYER';
        lc_main.separator();
        
        lc_main.menu("VIEW3D_MT_edit_gpencil_delete", icon="TRASH");
        
        lc_main.separator();
        
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.operator("gpencil.select_all", text='', icon='SELECT_SET').action='SELECT';
        lc_btn_row.operator("gpencil.select_linked");
        lc_btn_row.operator("gpencil.select_all", text='', icon='SELECT_INTERSECT').action='INVERT';
        lc_btn_row.operator("gpencil.select_all", text='', icon='X').action='DESELECT';
        
        lc_main.separator();
        
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.prop(context.scene.tool_settings, "use_proportional_edit", text='')
        lc_btn_row.prop(context.scene.tool_settings, "use_proportional_connected", icon='BLANK1');
            
#        is_active = True if (context.scene.tool_settings.proportional_edit_falloff == 'SMOOTH') else False;
#        lc_btn_row.operator('m7a.edit_falloff', icon='SMOOTHCURVE', depress=is_active, text='').type = 'SMOOTH';
#            
#        is_active = True if (context.scene.tool_settings.proportional_edit_falloff == 'SHARP') else False;
#        lc_btn_row.operator('m7a.edit_falloff', icon='SHARPCURVE', depress=is_active, text='').type = 'SHARP';
        
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.operator("gpencil.set_proportional_size", text = "", icon = "TRACKING_BACKWARDS_SINGLE").value = -0.01;
        lc_btn_row.prop(context.scene.tool_settings, "proportional_size", text='');
        lc_row_btn = lc_btn_row.row(align = True);
        lc_row_btn.operator("gpencil.set_proportional_size", text = "", icon = "TRACKING_FORWARDS_SINGLE").value = 0.01;
        lc_btn_row.prop_with_popover(context.scene.tool_settings, "proportional_edit_falloff", text="", icon_only=True, panel="VIEW3D_PT_proportional_edit");
    
    elif (context.mode in {"SCULPT_GPENCIL"}):
        lc_swtch_row = lc_switcher(lc_main, context, "GPencil", icon="SCULPTMODE_HLT", convert=False, asset=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",    'EDIT_GPENCIL',   False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "GREASEPENCIL",    'PAINT_GPENCIL',  False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',         False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "VPAINT_HLT",      'VERTEX_GPENCIL', False);
        
        lc_main.separator(); header();
        
        lc_onion_skinning();
        
        lc_main.separator();
        
        lc_btn_row = lc_main.row(align = True);
        lc_btn_row.operator("gpencil.select_all", text='', icon='SELECT_SET').action='SELECT';
        lc_btn_row.operator("gpencil.select_linked");
        lc_btn_row.operator("gpencil.select_all", text='', icon='SELECT_INTERSECT').action='INVERT';
        lc_btn_row.operator("gpencil.select_all", text='', icon='X').action='DESELECT';
        
        lc_main.separator();
        
        lc_btn_row = lc_main.row(align = True);
        brush = context.tool_settings.gpencil_sculpt_paint.brush;
        tool = brush.gpencil_sculpt_tool;
        is_active = True if (tool == 'SMOOTH') else False;
        lc_btn_row.operator("wm.tool_set_by_id", text='Smooth', depress=is_active, icon='GPBRUSH_SMOOTH').name="builtin_brush.Smooth";
        is_active = True if (tool == 'GRAB') else False;
        lc_btn_row.operator("wm.tool_set_by_id", text='Grab', depress=is_active, icon='GPBRUSH_GRAB').name="builtin_brush.Grab";
    
    elif (context.mode in {"VERTEX_GPENCIL"}):
        lc_swtch_row = lc_switcher(lc_main, context, "GPencil", icon="VPAINT_HLT", convert=False, asset=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "SCULPTMODE_HLT",  'SCULPT_GPENCIL', False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "GREASEPENCIL",    'PAINT_GPENCIL',  False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',         False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",    'EDIT_GPENCIL',   False);
        
        lc_main.separator(); header();
    
    elif (context.mode in {"WEIGHT_GPENCIL"}):
        lc_swtch_row = lc_switcher(lc_main, context, "GPencil", icon="WPAINT_HLT", convert=False, asset=False, delete=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "SCULPTMODE_HLT",  'SCULPT_GPENCIL', False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "GREASEPENCIL",    'PAINT_GPENCIL',  False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT',         False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",    'EDIT_GPENCIL',   False);
        
        lc_main.separator(); header();
        
    if (get_prop("view3d_gp_library")):
        lc_main.separator();
        m7a_gpencil_library.draw_panel(lc_main, context);

class CAMERA_OT_flip_x (Operator):
    bl_idname      = "camera.flip_x";
    bl_label       = "Flip Camera X";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Flip camera by X";
    
    def execute(self, context):
        context.scene.camera.scale.x = -context.scene.camera.scale.x;
        return {'FINISHED'};

class M7A_GPENCIL_VERTEX_color_edit_set (Operator):
    bl_idname      = "gpencil.set_vertex_color_edit";
    bl_label       = "Vertex Paint Set Color";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Set active color to all selected vertex";
    
    def execute(self, context):
        brush = context.tool_settings.gpencil_vertex_paint.brush;
        mode = brush.gpencil_settings.vertex_mode;
        
        lc_data = context.active_object.data;
        for layer in lc_data.layers:
            for stroke in layer.active_frame.strokes:
                if (mode in {'STROKE', 'BOTH'}):
                    for point in stroke.points:
                        if point.select:
                            point.vertex_color = (
                                context.scene.m7a_rgb_picker[0],
                                context.scene.m7a_rgb_picker[1],
                                context.scene.m7a_rgb_picker[2],
                                context.scene.m7a_rgb_picker[3],
                            );
                if (mode in {'FILL', 'BOTH'}):
                    stroke.vertex_color_fill = (
                        context.scene.m7a_rgb_picker[0],
                        context.scene.m7a_rgb_picker[1],
                        context.scene.m7a_rgb_picker[2],
                        context.scene.m7a_rgb_picker[3],
                    );
                    
        return {'FINISHED'};

classes = [
    CAMERA_OT_flip_x, M7A_GPENCIL_VERTEX_color_edit_set, 
];

def register():
    Scene.m7a_rgb_picker = FloatVectorProperty(
            name="Color", subtype='COLOR',
            default=(1, 1, 1, 1),
            size=4, min=0, max=1,
            description="Quick Pack Color Picker");
    
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
    
    r_remove_attr(Scene, "m7a_rgb_picker");
    
