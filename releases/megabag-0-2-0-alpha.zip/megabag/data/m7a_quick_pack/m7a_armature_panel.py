#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy.types import Scene, Operator;
from bpy.props import BoolProperty;

from bpy_sys import (
    q_register_class, q_unregister_class, r_remove_attr,
    lc_switcher, lc_add_btn, get_prop, lc_width, ver_more,
);

if ver_more(2,80,0):
    import m7a_gpencil_library;

def draw_panel (lc_main, context):
    if (context.mode in {'OBJECT'}):
        lc_swtch_row = lc_switcher(lc_main, context, "Armature", icon="OUTLINER_OB_ARMATURE", convert=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",  'EDIT', False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "ARMATURE_DATA", 'POSE', False);
        
        lc_main.separator();
        
    elif (context.mode in {'POSE'}):
        lc_swtch_row = lc_switcher(lc_main, context, "Armature", icon="ARMATURE_DATA", convert=False, asset=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "EDITMODE_HLT",    'EDIT',   False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT', False);
        
        lc_main.separator();
        
        lc_main.operator("pose.transforms_clear", text="Clear Transform", icon="PANEL_CLOSE");
        
        lc_main.separator();
        
        lc_main_row = lc_main.row(align = True);
        lc_main_row.menu("VIEW3D_MT_snap");
        lc_main_row.operator("view3d.snap_cursor_to_selected", text="", icon="PIVOT_CURSOR");
        lc_main_row.operator("view3d.snap_cursor_to_center",   text="", icon="CURSOR");
        
        lc_main.separator();
        
        lc_main.operator("anim.keyframe_insert_menu", icon="KEY_HLT");
        
        lc_main_row = lc_main.row(align = True);
        lc_main_row.operator("pose.copy", text="Copy Pose", icon="COPYDOWN");
        
        lc_btn = lc_main_row.row(align = True);
        lc_btn.operator("pose.paste", text="Paste", icon="PASTEDOWN").flipped = False;
        lc_btn.scale_x = 0.6;
        lc_main_row.operator("pose.paste", text="", icon="PASTEFLIPDOWN").flipped = True;
        
        lc_main.separator();
        
        lc_main_row = lc_main.row(align = True);
        
        lc_btn_row = lc_main_row.row(align = True);
        lc_btn_row.prop(context.scene, "armature_keep_pose", text="", icon="ARMATURE_DATA");
        lc_btn_row.scale_y = 2;
#        
        lc_main_col = lc_main_row.column(align = True);
        lc_main_col.operator("pose.mute_animation_selected_bone", text="Mute Anim Bones", icon="ZOOM_SELECTED");
        lc_main_col.operator("pose.isolate_animation_selected_bone", text="Isolate Anim Bones", icon="ZOOM_SELECTED");
        
        lc_btn_row = lc_main_row.row(align = True);
        lc_btn = lc_btn_row.operator("pose.unmute_animation_all_bones", text="", icon="ZOOM_PREVIOUS");
        lc_btn_row.scale_y = 2;
        
        if ver_more(2,80,0):
            lc_main.separator();
            
            if (get_prop("view3d_gp_library")): 
                m7a_gpencil_library.draw_pose_panel(lc_main, context);
        
    elif (context.mode in {'EDIT_ARMATURE'}):
        lc_swtch_row = lc_switcher(lc_main, context, "Armature", icon="EDITMODE_HLT", convert=False, asset=False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "ARMATURE_DATA",   'POSE',   False);
        lc_add_btn(lc_swtch_row, "object.mode_set", "", "OBJECT_DATAMODE", 'OBJECT', False);
        
        lc_main.separator();
        
        lc_row = lc_main.row(align = True);
        lc_row.operator(
            "transform.translate", text="Move" if (lc_width() > 140) else " ", 
            icon="OBJECT_ORIGIN" if ver_more(3,0,0) else "MAN_TRANS"
        );
        lc_row.operator(
            "transform.rotate", text="Rotate" if (lc_width() > 210) else "" if (lc_width() > 140) else " ", 
            icon="ORIENTATION_GIMBAL" if ver_more(3,0,0) else "MAN_ROT"
        );
        lc_row.operator(
            "transform.resize", text="Scale" if (lc_width() > 210) else "" if (lc_width() > 140) else " ", 
            icon="TRANSFORM_ORIGINS" if ver_more(3,0,0) else "MAN_SCALE"
        );
        
        lc_main.separator();
        
        lc_main.operator("armature.subdivide", icon="IPO_QUAD");
        lc_main.operator("armature.switch_direction", icon="UV_SYNC_SELECT");
        lc_main.operator("armature.extrude_move", icon="PARTICLES");
        
        lc_main.separator();
        
        lc_main.prop(context.active_bone, "roll", text="Bone Roll");
        lc_main.prop(context.active_bone, "length", text="Bone Length");
        lc_main.prop(context.active_bone, "envelope_distance", text="Bone Envelope");
        
        lc_main.separator();
        
        lc_main.operator("armature.symmetrize", icon="MOD_MIRROR");
        
class POSE_OT_mute_animation_selected_bone (Operator):
    bl_idname      = "pose.mute_animation_selected_bone";
    bl_label       = "Mute Animation";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Mute animation at selected bone";
    
    def execute(self, context):
        anim_name = context.object.animation_data.action.name;
        a_obj = context.active_object;
        
        for bone in list(a_obj.data.bones):
            if (bpy.data.objects[a_obj.name].pose.bones[bone.name] in context.selected_pose_bones_from_active_object):
                if (bone.name in list(bpy.data.actions[anim_name].groups.keys())):
                    bpy.data.actions[anim_name].groups[bone.name].mute = True;
        
                    if (context.scene.armature_keep_pose == False):
                        auto_key = context.tool_settings.use_keyframe_insert_auto;
                        
                        bpy.data.objects[a_obj.name].pose.bones[bone.name].location = (0, 0, 0);
                        bpy.data.objects[a_obj.name].pose.bones[bone.name].rotation_quaternion = (1, 0, 0, 0);
                        bpy.data.objects[a_obj.name].pose.bones[bone.name].scale = (1, 1, 1);
                        
                        context.tool_settings.use_keyframe_insert_auto = auto_key;
        
        bpy.data.scenes["Scene"].frame_current = bpy.data.scenes["Scene"].frame_current;
        return {'FINISHED'};
        
class POSE_OT_isolate_animation_selected_bone (Operator):
    bl_idname      = "pose.isolate_animation_selected_bone";
    bl_label       = "Isolate Animation";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Isolate animation at selected bone";
    
    def execute(self, context):
        anim_name = context.object.animation_data.action.name;
        a_obj = context.active_object;
        
        for bone in list(a_obj.data.bones):
            if not (bpy.data.objects[a_obj.name].pose.bones[bone.name] in context.selected_pose_bones_from_active_object):
                if (bone.name in list(bpy.data.actions[anim_name].groups.keys())):
                    bpy.data.actions[anim_name].groups[bone.name].mute = True;
        
                    if (context.scene.armature_keep_pose == False):
                        auto_key = context.tool_settings.use_keyframe_insert_auto;
                        
                        bpy.data.objects[a_obj.name].pose.bones[bone.name].location = (0, 0, 0);
                        bpy.data.objects[a_obj.name].pose.bones[bone.name].rotation_quaternion = (1, 0, 0, 0);
                        bpy.data.objects[a_obj.name].pose.bones[bone.name].scale = (1, 1, 1);
                        
                        context.tool_settings.use_keyframe_insert_auto = auto_key;
            else: bpy.data.actions[anim_name].groups[bone.name].mute = False;
        
        bpy.data.scenes["Scene"].frame_current = bpy.data.scenes["Scene"].frame_current;
        return {'FINISHED'};
        
class POSE_OT_unmute_animation_all_bones (Operator):
    bl_idname      = "pose.unmute_animation_all_bones";
    bl_label       = "Unmute Animation";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Unmute animation at all bone";
    
    def execute(self, context):
        anim_name = context.object.animation_data.action.name;
            
        for bone in list(context.active_object.data.bones):
            if (bone.name in list(bpy.data.actions[anim_name].groups.keys())):
                bpy.data.actions[anim_name].groups[bone.name].mute = False;
            
        bpy.data.scenes["Scene"].frame_current = bpy.data.scenes["Scene"].frame_current;
        return {'FINISHED'};

classes = [
    POSE_OT_mute_animation_selected_bone, 
    POSE_OT_isolate_animation_selected_bone,
    POSE_OT_unmute_animation_all_bones,
];

def register():    
    q_register_class(classes);
    
    Scene.armature_keep_pose = BoolProperty(name="Keep Pose");
    
def unregister():
    q_unregister_class(classes);
    
    r_remove_attr(Scene, "armature_keep_pose");
