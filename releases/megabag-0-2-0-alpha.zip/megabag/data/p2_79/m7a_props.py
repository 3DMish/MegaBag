#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys, shutil;

from bpy.types import PropertyGroup, AddonPreferences, Operator;
from bpy.props import BoolProperty,  EnumProperty,  PointerProperty, StringProperty;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../m7a_nodes/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../m7a_quick_pack/");

from bpy_sys import (
    q_register_class, q_unregister_class, addon_id, lc_return,
    bpy_preferences,  data_path, lc_width, get_prop,
);

import m7a_nodes, m7a_quick_pack;

def m7a_tabs_items (self, context):
    result = lc_return([("", "Panel", "")], [], max=300);
    return result + [
        (
            "3d_view", "3D View",
            "Show '3D View' properties", "VIEW3D",   0,
        ), (
            "modifiers", "Modifiers",
            "Show 'Modifiers' properties", "MODIFIER", 1,
        ), (
            "node_tree",
            lc_return("Nodes", "Node Tree", 350, 600),
            "Show 'Node Tree' properties", "NODETREE", 2,
        ), (
#            "assets", 
#            lc_return("Assets", "Assets Library", 350, 600),
#            "Show 'Assets Library' properties", "ASSET_MANAGER", 3,
#        ), (
            "other",
            lc_return("Other", "Other Stuff",  350, 600),
            "Show 'Other Stuff' properties", "PACKAGE", 4,
        ),
    ];
    
class M7A_MEGABAG_Properties(PropertyGroup):
    properties_tabs = EnumProperty(items=m7a_tabs_items);
    
    view3d_upgrade_header = BoolProperty(default=True);
    view3d_compact_menu = BoolProperty(default=True);
    view3d_tool_header  = BoolProperty(default=True);
    
    view3d_quick_pack   = BoolProperty(default=True, update=m7a_quick_pack.register_nodes);
    view3d_mesh_library = BoolProperty(default=True);
    view3d_gp_library   = BoolProperty(default=True);
    
    modifiers_upgrade  = BoolProperty(default=True);
    modifiers_options  = BoolProperty(default=True);
    
    text_editor_upgrade = BoolProperty(default=True);
    text_editor_file    = BoolProperty(default=True);
    text_editor_icons   = BoolProperty(default=True);
    text_editor_info    = BoolProperty(default=True);
    
    assets_libraries = BoolProperty(default=True);
    assets_materials = BoolProperty(default=True);
    assets_foods     = BoolProperty(default=True);
    
    node_editor        = BoolProperty(default=True, update=m7a_nodes.register_nodes);
    node_shader_groups = BoolProperty(default=True);
    
    node_replace = EnumProperty(
        name="How add Group Nodes",
        description="How to add new group nodes, always create new, or if exist use it",
        items=[
            ("use_exist", "If exist use it", "Use exist, if not exist create new"), 
            ("always_new", "Always new", "Always add as new"),
        ],
    );
    
    node_distance_rgb  = BoolProperty(default=True);
    
    dope_sheet_upgrade = BoolProperty(default=True);
    dope_compact_menu  = BoolProperty(default=True);
    dope_play_pause    = BoolProperty(default=True);

class M7A_MEGABAG_Preferences (AddonPreferences):
    bl_idname = addon_id;
    
    m7a_props = PointerProperty(type=M7A_MEGABAG_Properties);
    
    def draw(self, context):
        def lc_template_item(lc_cont, text, icon = None, data = None, props = None):
            lc_cont = lc_cont.column(align=True);
            lc_row = lc_cont.box().row(align=True);
            if (icon != None): lc_row.label(text=text, icon=icon);
            else: lc_row.label(text=text);
            if (data != None): lc_row.prop(data, props,  text="");
            return lc_cont.box().column(align=True);
            
        def lc_icons(lc_cont, icons):
            for icon in icons:
                try: lc_cont.label(text="", icon_value=int(icon));
                except: lc_cont.label(text="", icon=icon);
            
        lc_main = self.layout.column(align=False);
        
        lc_box = lc_main.box().row(align = True);
        is_mishkey_exist = "MishKey" in bpy.context.window_manager.keyconfigs.keys();
        btn_name = "ReInstall MishKey" if (is_mishkey_exist) else "Install MishKey";
        lc_btn = lc_box.operator("m7a.install_mishkey", text=btn_name, icon="IMPORT")
        lc_btn.option = "REINSTALL_MISHKEY" if (is_mishkey_exist) else "INSTALL_MISHKEY";
        
        if (is_mishkey_exist):
            lc_box.operator("m7a.install_mishkey", text="", icon="X").option = "UNINSTALL_MISHKEY";
            
        lc_box.separator();
        lc_box.operator("m7a.install_mishkey", text="Set Props", icon="PREFERENCES").option = "SET_MISHKEY_PROPS";
        
        lc_main.separator();
        
        lc_box = lc_main.column(align=True);
        lc_row = lc_box.box().row(align=True);
        if (lc_width() > 350): lc_row.prop(self.m7a_props, "properties_tabs",  expand=True);
        else: lc_row.prop(self.m7a_props, "properties_tabs",  text="Panel");
        lc_box_main = lc_box.box().column(align=True);
        
        m7a_properties_tabs = self.m7a_props.properties_tabs;
        
        if (m7a_properties_tabs == "3d_view"):
            lc_box = lc_template_item(lc_box_main, text="Upgrade Header:", data=self.m7a_props, props="view3d_upgrade_header");
            lc_box.active = self.m7a_props.view3d_upgrade_header;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "view3d_compact_menu",  text="Compact Menu");
        
        elif (m7a_properties_tabs == "modifiers"):
            lc_box = lc_template_item(lc_box_main, text="Upgrade Panel:", icon="MENU_PANEL", data=self.m7a_props, props="modifiers_upgrade");
            lc_box.active = self.m7a_props.modifiers_upgrade;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "modifiers_options",   text="Modifiers Options");
            
        elif (m7a_properties_tabs == "node_tree"):
            lc_box = lc_template_item(lc_box_main, text="Node Editor:", icon="NODETREE", data=self.m7a_props, props="node_editor");
            lc_box.active = self.m7a_props.node_editor;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.label(text="How to add new Node Group:");
            lc_box_row.prop(self.m7a_props, "node_replace",   text="");
            
            lc_box.separator();
            
            lc_box = lc_template_item(lc_box, text="Shader Groups:", icon="MATERIAL_DATA", data=self.m7a_props, props="node_shader_groups");
            lc_box.active = self.m7a_props.node_shader_groups;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "node_distance_rgb",  text="MixRGB by Distance");
        
        elif (m7a_properties_tabs == "other"):
            lc_box_group = lc_template_item(lc_box_main, text="Dope Sheet:", icon="ACTION");
            
            lc_box = lc_template_item(lc_box_group, text="Upgrade Header:", data=self.m7a_props, props="dope_sheet_upgrade");
            lc_box.active = self.m7a_props.dope_sheet_upgrade;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "dope_compact_menu",  text="Compact Menu");
            lc_box_row.prop(self.m7a_props, "dope_play_pause",    text="Show (Play/Pause)");
            
            lc_box_main.separator();
            
            lc_box_group = lc_template_item(lc_box_main, text="Text Editor:", icon="TEXT");
            
            lc_box = lc_template_item(lc_box_group, text="Upgrade Panel:", data=self.m7a_props, props="text_editor_upgrade");
            lc_box.active = self.m7a_props.text_editor_upgrade;
            lc_box_row = lc_box.row(align=True);
            lc_box_row.prop(self.m7a_props, "text_editor_info",  text="Info");
            lc_box_row.prop(self.m7a_props, "text_editor_file",  text="File");
            if (lc_width() > 450):
                lc_box_row.prop(self.m7a_props, "text_editor_icons", text="Icon Viewer");
            else:
                lc_box_row = lc_box.row(align=True);
                lc_box_row.active = self.m7a_props.text_editor_upgrade;
                lc_box_row.prop(self.m7a_props, "text_editor_icons", text="Icon Viewer");

class M7A_BTN_INSTALL_MishKey (bpy.types.Operator):
    bl_idname		= 'm7a.install_mishkey';
    bl_label		= 'Install MishKey';
    bl_description  = '';

    option = StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        if (properties.option == "SET_MISHKEY_PROPS"):
            return "Set 3DMish's properties in blender, like ''Navigation'', add corrections in ''Interface'' ...";
        elif (properties.option == "INSTALL_MISHKEY"):   return "Install Keymap: MishKey";
        elif (properties.option == "REINSTALL_MISHKEY"): return "ReInstall Keymap: MishKey";
        elif (properties.option == "UNINSTALL_MISHKEY"): return "Remove Keymap: MishKey";
        else: pass;
        
    def execute(self, context):
        
        if (self.option == "SET_MISHKEY_PROPS"):
            bpy_preferences().inputs.walk_navigation.use_gravity = True;
            bpy_preferences().inputs.invert_mouse_zoom = True;
            bpy_preferences().inputs.invert_zoom_wheel = False;
            bpy_preferences().inputs.view_rotate_method = 'TURNTABLE';
            
        elif (self.option in {"INSTALL_MISHKEY", "REINSTALL_MISHKEY"}):
            path = bpy.utils.user_resource('SCRIPTS', path=os.path.join("presets", "keyconfig"), create=True);
            path = os.path.join(path, "MishKey.py");
            
            if (self.option == "REINSTALL_MISHKEY"): os.remove(path);
                
            shutil.copy(os.path.join(data_path, "p2_79", "m7a_mishkey.py"), path);
            bpy.utils.keyconfig_set(path);
        
        elif (self.option in {"UNINSTALL_MISHKEY"}):
            path = bpy.utils.user_resource('SCRIPTS', path=os.path.join("presets", "keyconfig"), create=True);
            path = os.path.join(path, "MishKey.py"); os.remove(path);
            context.window_manager.keyconfigs.remove(context.window_manager.keyconfigs['MishKey']);
            
        return {'FINISHED'};

class OBJECT_MODIFIERS_option (Operator):
    bl_idname       = 'object.modifiers_option';
    bl_label        = 'Modifiers Options';
    
    option = StringProperty();
    hint = StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        if not (properties.hint == ""): return properties.hint;
        else: pass;
    
    def execute(self, context):
        a_obj = context.active_object;
        a_obj_modifiers = a_obj.modifiers if (a_obj.type != "GPENCIL") else a_obj.grease_pencil_modifiers;
        
        def opt_modifiers(list_modifiers, view = "view", value = False):
            for modifier in list_modifiers:
                if   (view == "view"):       modifier.show_viewport = value;
                elif (view == "render"):     modifier.show_render = value;
                if   (view == "view_tgl"):   modifier.show_viewport = False if (modifier.show_viewport) else True;
                elif (view == "render_tgl"): modifier.show_render   = False if (modifier.show_render) else True;
                elif (view == "apply"):      bpy.ops.object.modifier_apply(modifier=modifier.name);
        
        if   (self.option == "MOD_APPLY_ALL"):       opt_modifiers(a_obj_modifiers, "apply");
        
        elif (self.option == "MOD_VIEWPORT_ON"):     opt_modifiers(a_obj_modifiers, "view", True);
        elif (self.option == "MOD_VIEWPORT_OFF"):    opt_modifiers(a_obj_modifiers, "view", False);
        elif (self.option == "MOD_VIEWPORT_TOGGLE"): opt_modifiers(a_obj_modifiers, "view_tgl");
        
        elif (self.option == "MOD_RENDER_ON"):       opt_modifiers(a_obj_modifiers, "render", True);
        elif (self.option == "MOD_RENDER_OFF"):      opt_modifiers(a_obj_modifiers, "render", False);
        elif (self.option == "MOD_RENDER_TOGGLE"):   opt_modifiers(a_obj_modifiers, "render_tgl");
                    
        elif (self.option == "MOD_REMOVE_VIEW"):
            list_modifiers = [];
            for modifier in a_obj_modifiers:
                if (modifier.show_viewport == False): list_modifiers.append(modifier.name);
            for modifier in list_modifiers: a_obj_modifiers.remove(a_obj_modifiers[modifier]);
            del list_modifiers;
            
        elif (self.option == "MOD_REMOVE_RENDER"):
            list_modifiers = [];
            for modifier in a_obj_modifiers:
                if (modifier.show_render == False): list_modifiers.append(modifier.name);
            for modifier in list_modifiers: a_obj_modifiers.remove(a_obj_modifiers[modifier]);
            del list_modifiers;
            
        elif (self.option == "MOD_REMOVE_ALL"):
            for i in range(0, len(a_obj_modifiers)):
                a_obj_modifiers.remove(a_obj_modifiers[len(a_obj_modifiers)-1]);
                
        return {'FINISHED'};

class NODE_M7A_add (Operator):
    bl_idname       = 'node.add_m7a_node';
    bl_label        = 'Add M7A Node';
    
    type = StringProperty();
    node = StringProperty();
    hint = StringProperty();
    
    @classmethod
    def description(cls, context, properties):
        if not (properties.hint == ""): return properties.hint;
        else: pass;
    
    def execute(self, context):
        name = self.node; exist = False;
        group_name = name.replace("M7A ", "");
        
        if (get_prop("node_replace") == "use_exist") and (group_name in bpy.data.node_groups):
            exist = True;
        
        if (exist == False):
            bpy.ops.wm.append(directory=data_path+"/p2_79/m7a_data.blend/NodeTree", filename=name);
            if (group_name in bpy.data.node_groups): bpy.data.node_groups[group_name].name = group_name+".001";
            bpy.data.node_groups[name].name = group_name;
            
        if (self.type == "ShaderNodeGroup"):
            bpy.ops.node.add_node(
                type="ShaderNodeGroup", use_transform=True, 
                settings=[{"name":"node_tree", "value":"bpy.data.node_groups['"+group_name+"']"}]
            ); bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT');
        
        return {'FINISHED'};
        
classes = [
    M7A_MEGABAG_Properties, M7A_BTN_INSTALL_MishKey, M7A_MEGABAG_Preferences, 
    OBJECT_MODIFIERS_option, NODE_M7A_add,
];

def register():
    q_register_class(classes);
    
def unregister():
    q_unregister_class(classes);
