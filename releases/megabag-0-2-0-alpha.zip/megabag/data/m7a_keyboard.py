#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import os, sys, subprocess;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../");

from bpy_sys import (
    q_register_class, q_unregister_class, lc_cont_x, lc_cont_y,
);

from bpy.types import Panel;

class M7A_PT_KEYBOARD_panel (Panel):
    bl_idname       = 'M7A_PT_KEYBOARD_panel';
    bl_space_type   = 'VIEW_3D';
    bl_region_type  = 'HEADER';
    bl_label        = 'Keyboard';
    bl_description  = 'Screen keyboard';
    bl_ui_units_x   = 30;
    
    def draw(self, context):
        lc_main_row = self.layout.row(align = True); status = [];
        lc_main = lc_cont_x(lc_main_row, 1.0).column(align = False);
        
        status_map = subprocess.run('xset q | grep Caps', shell=True, stdout=subprocess.PIPE);
        for stp in status_map.stdout.decode('utf-8').split(":"):
            if   (stp.find("on") >= 0):  status.append(True);
            elif (stp.find("off") >= 0): status.append(False);
        
        lc_row = lc_main.row(align = True); lc_row.scale_y = 1.2;
        
        lc_cont_x(lc_row, 1.1).operator("keyboard.button", text="Esc").key="{ESC}";
        
        lc_btns_row = lc_cont_x(lc_row, 0.8);
        lc_btns_row.operator("keyboard.button", text="F1").key="{F1}";
        lc_btns_row.operator("keyboard.button", text="F2").key="{F2}";
        lc_btns_row.operator("keyboard.button", text="F3").key="{F3}";
        lc_btns_row.operator("keyboard.button", text="F4").key="{F4}";
        lc_btns_row.operator("keyboard.button", text="F5").key="{F5}";
        lc_btns_row.operator("keyboard.button", text="F6").key="{F6}";
        lc_btns_row.operator("keyboard.button", text="F7").key="{F7}";
        lc_btns_row.operator("keyboard.button", text="F8").key="{F8}";
        lc_btns_row.operator("keyboard.button", text="F9").key="{F9}";
        lc_btns_row.operator("keyboard.button", text="F10").key="{F10}";
        lc_btns_row.operator("keyboard.button", text="F11").key="{F11}";
        lc_btns_row.operator("keyboard.button", text="F12").key="{F12}";
        lc_btns_row.operator("keyboard.button", text="Ins").key="{INSTER}";
        
        lc_cont_x(lc_row, 1.2).operator("keyboard.button", text="Delete").key="{DEL}";
        
        lc_row = lc_main.row(align = True); lc_row.scale_y = 1.2;
        
        lc_btns_row = lc_cont_x(lc_row, 0.8);
        lc_btns_row.operator("keyboard.button", text="`").key="`";
        lc_btns_row.operator("keyboard.button", text="1").key="1";
        lc_btns_row.operator("keyboard.button", text="2").key="2";
        lc_btns_row.operator("keyboard.button", text="3").key="3";
        lc_btns_row.operator("keyboard.button", text="4").key="4";
        lc_btns_row.operator("keyboard.button", text="5").key="5";
        lc_btns_row.operator("keyboard.button", text="6").key="6";
        lc_btns_row.operator("keyboard.button", text="7").key="7";
        lc_btns_row.operator("keyboard.button", text="8").key="8";
        lc_btns_row.operator("keyboard.button", text="9").key="9";
        lc_btns_row.operator("keyboard.button", text="0").key="0";
        lc_btns_row.operator("keyboard.button", text="-").key="-";
        lc_btns_row.operator("keyboard.button", text="=").key="=";
        
        lc_cont_x(lc_row, 1.3).operator("keyboard.button", text="Backspace").key="{BACKSPACE}";
        
        lc_row = lc_main.row(align = True); lc_row.scale_y = 1.2;
        lc_cont_x(lc_row, 1.1).operator("keyboard.button", text="Tab").key="    ";
        
        lc_btns_row = lc_cont_x(lc_row, 0.9);
        lc_btns_row.operator("keyboard.button", text="Q").key="Q";
        lc_btns_row.operator("keyboard.button", text="W").key="W";
        lc_btns_row.operator("keyboard.button", text="E").key="E";
        lc_btns_row.operator("keyboard.button", text="R").key="R";
        lc_btns_row.operator("keyboard.button", text="T").key="T";
        lc_btns_row.operator("keyboard.button", text="Y").key="Y";
        lc_btns_row.operator("keyboard.button", text="U").key="U";
        lc_btns_row.operator("keyboard.button", text="I").key="I";
        lc_btns_row.operator("keyboard.button", text="O").key="O";
        lc_btns_row.operator("keyboard.button", text="P").key="P";
        lc_btns_row.operator("keyboard.button", text="[").key="[";
        lc_btns_row.operator("keyboard.button", text="]").key="]";
        lc_btns_row.operator("keyboard.button", text="\\").key="\\";
        
        lc_row = lc_main.row(align = True); lc_row.scale_y = 1.2;
        
        lc_cont_x(lc_row, 1.20).operator("keyboard.button", text="Caps Lock", depress=status[0]).key="{CAPS}";
        
        lc_btns_row = lc_cont_x(lc_row, 0.8);
        lc_btns_row.operator("keyboard.button", text="A").key="A";
        lc_btns_row.operator("keyboard.button", text="S").key="S";
        lc_btns_row.operator("keyboard.button", text="D").key="D";
        lc_btns_row.operator("keyboard.button", text="F").key="F";
        lc_btns_row.operator("keyboard.button", text="G").key="G";
        lc_btns_row.operator("keyboard.button", text="H").key="H";
        lc_btns_row.operator("keyboard.button", text="J").key="H";
        lc_btns_row.operator("keyboard.button", text="K").key="K";
        lc_btns_row.operator("keyboard.button", text="L").key="L";
        lc_btns_row.operator("keyboard.button", text=":").key=":";
        lc_btns_row.operator("keyboard.button", text="'").key="'";
        
        lc_cont_x(lc_row, 1.15).operator("keyboard.button", text="Enter").key="{ENTER}";
        
        lc_row = lc_main.row(align = True); lc_row.scale_y = 1.2;
        lc_cont_x(lc_row, 1.2).operator("keyboard.button", text="Shift").key="{SHIFT}";
        
        lc_btns_row = lc_cont_x(lc_row, 0.8);
        lc_btns_row.operator("keyboard.button", text="Z").key="Z";
        lc_btns_row.operator("keyboard.button", text="X").key="X";
        lc_btns_row.operator("keyboard.button", text="C").key="C";
        lc_btns_row.operator("keyboard.button", text="V").key="V";
        lc_btns_row.operator("keyboard.button", text="B").key="B";
        lc_btns_row.operator("keyboard.button", text="N").key="N";
        lc_btns_row.operator("keyboard.button", text="M").key="M";
        lc_btns_row.operator("keyboard.button", text=",").key=",";
        lc_btns_row.operator("keyboard.button", text=".").key=".";
        lc_btns_row.operator("keyboard.button", text="/").key="/";
        
        lc_cont_x(lc_row, 1.2).operator("keyboard.button", text="Shift").key="{SHIFT}";
        
        lc_row = lc_main.row(align = True); lc_row.scale_y = 1.2;
        lc_row.operator("keyboard.button", text="Ctrl").key="{CTRL}";
        
        lc_row.operator("keyboard.button", text="Win").key="{WIN}";
        lc_row.operator("keyboard.button", text="Alt").key="{ALT}";
        lc_cont_x(lc_row, 10).operator("keyboard.button", text="Space").key=" ";
        lc_row.operator("keyboard.button", text="Alt").key="{ALT}";
        lc_row.operator("keyboard.button", text="Ctrl").key="{CTRL}";
        
        lc_row.separator();
        
        lc_arrows = lc_cont_x(lc_row, 15).row(align = True);
        lc_arrows.scale_y = 0.5;
        
        lc_row_btn = lc_arrows.column(align = True);
        lc_row_btn.label(text=" ");
        lc_row_btn.operator("keyboard.button", text="←").key="{LEFT}";
        
        lc_row_btn = lc_arrows.column(align = True);
        lc_row_btn.operator("keyboard.button", text="↑").key="{UP}";
        lc_row_btn.operator("keyboard.button", text="↓").key="{DOWN}";
        
        lc_row_btn = lc_arrows.column(align = True);
        lc_row_btn.label(text=" ");
        lc_row_btn.operator("keyboard.button", text="→").key="{RIGHT}";
        
        lc_main_row.separator();
        
        lc_numbers = lc_cont_x(lc_main_row, 5.0).column(align = False);
        lc_numbers.scale_y = 1.2;
        
        lc_numbs = lc_numbers.row(align = True);
        lc_numbs.operator("keyboard.button", text="PgUp").key="{PGUP}";
        lc_numbs.operator("keyboard.button", text="PgDn").key="{PGDN}";
        lc_numbs.operator("keyboard.button", text="Home").key="{HOME}";
        lc_numbs = lc_numbers.row(align = True);
        lc_numbs.operator("keyboard.button", text="Num", depress=status[1]).key="{NUMLOCK}";
        lc_numbs.operator("keyboard.button", text="/").key="/";
        lc_numbs.operator("keyboard.button", text="*").key="*";
        lc_numbs = lc_numbers.row(align = True);
        lc_numbs.operator("keyboard.button", text="7").key="7";
        lc_numbs.operator("keyboard.button", text="8").key="8";
        lc_numbs.operator("keyboard.button", text="9").key="9";
        lc_numbs = lc_numbers.row(align = True);
        lc_numbs.operator("keyboard.button", text="4").key="4";
        lc_numbs.operator("keyboard.button", text="5").key="5";
        lc_numbs.operator("keyboard.button", text="6").key="6";
        lc_numbs = lc_numbers.row(align = True);
        lc_numbs.operator("keyboard.button", text="1").key="1";
        lc_numbs.operator("keyboard.button", text="2").key="2";
        lc_numbs.operator("keyboard.button", text="3").key="3";
        lc_numbs = lc_numbers.row(align = True);
        lc_cont_x(lc_numbs, 2.85).operator("keyboard.button", text="0").key="0";
        lc_cont_x(lc_numbs, 0.2).operator("keyboard.button", text=".").key=".";
        
        lc_end = lc_cont_x(lc_main_row, 0.18).column(align = False); lc_end.scale_y = 1.2;
        
        lc_end.operator("keyboard.button", text="End").key="{End}";
        lc_end.operator("keyboard.button", text="-").key="-";
        lc_cont_y(lc_end, 2.1).operator("keyboard.button", text="+").key="+";
        lc_cont_y(lc_end, 2.1).operator("keyboard.button", text="Enter").key="{ENTER}";
        
classes = [
    M7A_PT_KEYBOARD_panel,
];

def register():
    q_register_class(classes);
    
    
def unregister():
    q_unregister_class(classes);
