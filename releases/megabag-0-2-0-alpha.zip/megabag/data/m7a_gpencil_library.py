#!/usr/bin/env python -------------------------------- -*- coding: utf-8 -*-#
#                      2023 3DMish <Mish7913@gmail.com>                     #

# -----              ##### BEGIN GPL LICENSE BLOCK #####              ----- #
#                                                                           #
#  This  program  is  free  software;   you  can  redistribute  it  and/or  #
#  modify  it  under  the  terms  of   the   GNU  General  Public  License  #
#  as  published  by  the  Free  Software  Foundation;  either  version  2  #
#  of the License, or (at your option) any later version.                   #
#                                                                           #
#  This program  is  distributed  in the hope  that  it  will  be  useful,  #
#  but  WITHOUT  ANY  WARRANTY;  without  even  the  implied  warranty  of  #
#  MERCHANTABILITY  or  FITNESS   FOR  A  PARTICULAR  PURPOSE.    See  the  #
#  GNU General Public License for more details.                             #
#                                                                           #
#  You  should  have  received  a  copy  of the GNU General Public License  #
#  along with this program; if not, write to the Free Software Foundation,  #
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.       #
#                                                                           #
# -----               ##### END GPL LICENSE BLOCK #####               ----- #

import bpy, os, sys;

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/");
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/p2_80/");

from bpy.types import Scene, Operator, UIList;
from bpy.props import BoolProperty, CollectionProperty, IntProperty, StringProperty;
from bpy.app.handlers import persistent;

import m7a_props;

from bpy_sys import (
    q_register_class, q_unregister_class, r_remove_attr, 
    lc_panel, lc_center_label,
);

def draw_panel (lc_main, context):
    lc_box, lc_label_row, is_open = lc_panel(
        lc_main, context, "gpencil_show_library", "Grease Pencil Library", "ASSET_MANAGER", True,
        c_label="GPencil Library",
    );
    if (is_open):
        if ('m7a_gpencil_library' in context.active_object.data):
            lc_label_row.operator("gpencil.library_copy_id", text="", icon="COPY_ID");
            if ("active_bone" in context.active_object.data['m7a_gpencil_library']):
                obj_name = context.active_object.data['m7a_gpencil_library']["active_bone"];
                if (obj_name in bpy.data.objects):
                    lc_label_row.separator();
                    lc_label_row.operator("gpencil.library_go_to_bone", text="", icon="ARMATURE_DATA");
            lc_label_row.separator();
            lc_label_row.operator("gpencil.library_remove", text="", icon="TRASH");
            
#            glib = context.active_object.data["m7a_gpencil_library"];
#            obj = bpy.data.objects['Cube'];
            
            lc_box.template_list(
                "M7A_GPENCIL_UL_list", "list", context.scene, "gpencil_list_library", 
                context.scene, "gpencil_item_library", rows=3,
            );
            lc_row = lc_box.row(align = True);
            lc_row.operator("gpencil.library_load_item", text="Load Item", icon="SEQ_SPLITVIEW");
            if (context.mode in {"PAINT_GPENCIL", "EDIT_GPENCIL", "SCULPT_GPENCIL"}):
                lc_row.operator("gpencil.library_add_item",    text="", icon="ADD");
                lc_row.operator("gpencil.library_remove_item", text="", icon="REMOVE");
        else:
            lc_label_row.operator("gpencil.library_new", text="", icon="ADD");
            lc_center_label(lc_box, "No gpencil library in object").active=False;

def draw_pose_panel (lc_main, context):
    is_lib_exist = False;
    if (context.active_pose_bone):
        if ("gpencil_library" in context.active_pose_bone):
            if (context.active_pose_bone["gpencil_library"][0] in bpy.data.objects):
                is_lib_exist = True;
    
    lc_box, lc_label_row, is_open = lc_panel(
        lc_main, context, "gpencil_show_library", "Grease Pencil Library", "ASSET_MANAGER", True,
        empty=False if (is_lib_exist) else True,
        c_label="GPencil Library",
    );
    
    if not ("gpencil_library" in context.active_pose_bone):
        lc_label_row.operator("gpencil.library_link", text="", icon="LINKED").disconnect=False;
        
    if (is_open):
        if ("gpencil_library" in context.active_pose_bone):
            lc_label_row.operator("gpencil.edit_element", text="", icon="GREASEPENCIL");
            lc_label_row.separator();
            lc_label_row.operator("gpencil.library_link", text="", icon="UNLINKED").disconnect=True;
    
        lc_box.template_list(
            "M7A_GPENCIL_UL_list", "list", context.scene, "gpencil_list_library", 
            context.scene, "gpencil_item_library", rows=3,
        );
        lc_box.operator("gpencil.library_load_item", text="Load Item", icon="SEQ_SPLITVIEW");
    
    # ---------------------------------------------------------------
    
#    if (is_lib_exist == True):
#        lc_box, lc_label_row, is_open = lc_panel(
#        lc_main, context, "gpencil_show_poses", "Grease Pose Library", "ASSET_MANAGER", True,
#        c_label="GPose Library",
#    );
    
    if (is_open):
        pass

class M7A_GPENCIL_UL_list (UIList):
    def draw_item (self, _context, layout, _data, item, icon, _active_data, _active_propname, _index):
        layout.label(text=item.name, icon="OUTLINER_OB_GREASEPENCIL");

class M7A_GPENCIL_LIBRARY_new (Operator):
    bl_idname      = "gpencil.library_new";
    bl_label       = "Create GPencil Library";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Create new grease pencil library";
    
    def execute(self, context):
        context.active_object.data['m7a_gpencil_library'] = {'active': 0,'list':{}};
        context.active_object.data.id_properties_ensure();
        return {'FINISHED'};

class M7A_GPENCIL_LIBRARY_remove (Operator):
    bl_idname      = "gpencil.library_remove";
    bl_label       = "Remove GPencil Library";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Remove grease pencil library";
    
    def execute(self, context):
        if (context.active_object.type == "GPENCIL"):
            bpy.ops.wm.properties_remove(data_path="object.data", property_name="m7a_gpencil_library");
        return {'FINISHED'};
        
class M7A_GPENCIL_LIBRARY_item_add (Operator):
    bl_idname      = "gpencil.library_add_item";
    bl_label       = "Add Frame to the Library";
    bl_options     = {'REGISTER', 'UNDO', 'INTERNAL'};
    bl_description = "Add active frame to gpencil library";
    
    name : StringProperty(name="Name");

    def draw(self, context):
        self.layout.prop(self, "name");
        
    def invoke(self, context, _event):
        self.name = "";
        return context.window_manager.invoke_props_dialog(self, width=200);
        
    def execute(self, context):
        lc_data = context.active_object.data; lg_map = {};
        lc_map = lc_data['m7a_gpencil_library']['list'];
        
        if (self.name not in lc_map):
            lg_map['materials'] = lc_data.materials.keys();
            
            lg_map['layers'] = {};
            for l_idx, layer in enumerate(lc_data.layers):
                lg_map['layers'][layer.info] = {
                    'opacity': layer.opacity,
                    'blend_mode': layer.blend_mode,
                    'strokes': [],
                };
                
                for s_idx, stroke in enumerate(layer.active_frame.strokes):
                    gp_points = []; gp_vertgroup = [];
                    
                    for p_idx, point in enumerate(stroke.points):
                        
                        for g_idx in range(0, len(context.active_object.vertex_groups)):
                            try:
                                value = lc_data.layers[l_idx].active_frame.strokes[s_idx].points.weight_get(
                                    vertex_group_index=g_idx, point_index=p_idx,
                                );
                                if (value == -1): value = 1; g_idx += 1;
                                gp_vertgroup.append([int(g_idx), int(p_idx), value]);
                            except: pass
                        
                        gp_points.append({
                            "co": point.co,
                            "vertex_color": point.vertex_color,
                            "pressure": point.pressure,
                            "strength": point.strength,
                        })
                        
                    lg_map['layers'][layer.info]['strokes'].append({
                        'display_mode': stroke.display_mode,
                        'material_index': stroke.material_index,
                        'line_width': stroke.line_width,
                        'vertex_color_fill': stroke.vertex_color_fill,
                        'points': gp_points,
                        "vertex_group": gp_vertgroup,
                    });
                
            lc_map[self.name] = lg_map;
            
        else: self.report({'ERROR'}, "This name already exist.");
        gpencil_update_library(context.scene);
        
        return {'FINISHED'};
        
class M7A_GPENCIL_LIBRARY_item_remove (Operator):
    bl_idname      = "gpencil.library_remove_item";
    bl_label       = "Remove Frame to the Library";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Remove active frame from gpencil library";
    
    def execute(self, context):
        m7a_list = bpy.context.active_object.data['m7a_gpencil_list'];
        lc_map = context.active_object.data['m7a_gpencil_library']['list'];
        if (len(m7a_list) > 0):
            del lc_map[m7a_list[context.scene.gpencil_item_library]];
        gpencil_update_library(context.scene);
        return {'FINISHED'};
        
class M7A_GPENCIL_LIBRARY_copy_id (Operator):
    bl_idname      = "gpencil.library_copy_id";
    bl_label       = "Copy ID";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Copy ID of this Library";
    
    def execute(self, context):
        context.window_manager.clipboard = context.active_object.name;
        self.report({'INFO'}, "ID was copied.");
        return {'FINISHED'};
        
class M7A_GPENCIL_LIBRARY_item_load (Operator):
    bl_idname      = "gpencil.library_load_item";
    bl_label       = "Load Frame from the Library";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Load active frame from gpencil library";
    
    def execute(self, context):
        m7a_number = context.scene.gpencil_item_library;
        lc_obj = None;
        
        if (context.mode in {'POSE'}):
            if ("gpencil_library" in context.active_pose_bone):
                name = context.active_pose_bone["gpencil_library"];
                lc_obj = bpy.data.objects[name[0]];
            
        elif (context.active_object.type in {'GPENCIL'}):
            lc_obj = context.active_object;
            
        if (lc_obj != None):
            if ('m7a_gpencil_list' in lc_obj.data):
                m7a_list = lc_obj.data['m7a_gpencil_list'];
            else: m7a_list = 0;
            
            if not (m7a_number < 0) and not (m7a_number > len(m7a_list)) and not (len(m7a_list) < 1):
                
                lc_map = lc_obj.data['m7a_gpencil_library']['list'];
                lc_gpencil = lc_map[m7a_list[context.scene.gpencil_item_library]]
                
                gpencil_data = lc_obj.data;
                
                for l_idx, layer in enumerate(lc_gpencil['layers'].keys()):
                    if (layer in gpencil_data.layers.keys()):
                        gpencil_layer = gpencil_data.layers[layer];
                    else:
                        gpencil_layer = gpencil_data.layers.new(layer);
                        
                    for frame in gpencil_layer.frames:
                        if (frame.frame_number == context.scene.frame_current):
                            gpencil_layer.frames.remove(frame);
                    
                    gpencil_frame = gpencil_layer.frames.new(context.scene.frame_current);
                    
                    for s_idx, stroke in enumerate(lc_gpencil['layers'][layer]['strokes']):
                        gpencil_stroke = gpencil_frame.strokes.new();
                        gpencil_stroke.display_mode      = stroke['display_mode'];
                        gpencil_stroke.material_index    = stroke['material_index'];
                        gpencil_stroke.line_width        = stroke['line_width'];
                        gpencil_stroke.vertex_color_fill = stroke['vertex_color_fill'];
                        
                        for p_idx, point in enumerate(stroke['points']):
                            gpencil_stroke.points.add(1);
                            gpencil_point = gpencil_stroke.points[p_idx];
                            gpencil_point.co           = point['co'];
                            gpencil_point.vertex_color = point['vertex_color'];
                            gpencil_point.pressure     = point['pressure'];
                            gpencil_point.strength     = point['strength'];
                            
                            for vg in stroke['vertex_group']:
                                if (float(vg[2]) > 0.0):
                                    if (int(vg[1]) == p_idx) and (int(vg[0]) < len(context.active_object.vertex_groups)):
                                        group = context.active_object.vertex_groups[int(vg[0])];
                                        group.add([p_idx], float(vg[2]), "REPLACE");
                                        
                                        gpencil_frame.strokes[s_idx].points.weight_set(
                                            vertex_group_index=int(vg[0]), 
                                            point_index=p_idx,
                                            weight=float(vg[2]),
                                        );
                            
            else: self.report({'WARNING'}, "No item selected.");
        
#        /mat = bpy.data.materials.new(name="Black")
#        /bpy.data.materials.create_gpencil_data(mat)
#        /gpencil.data.materials.append(mat)
#        /mat.grease_pencil.show_fill = True
#        /mat.grease_pencil.fill_color = (1.0, 0.0, 1.0, 1.0)
#        /mat.grease_pencil.color = (0.0, 0.0, 1.0, 1.0)

        return {'FINISHED'};

class M7A_GPENCIL_LIBRARY_link (Operator):
    bl_idname      = "gpencil.library_link";
    bl_label       = "Connect GPencil Library";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Connect gpencil library to the bone";
    
    id : StringProperty(name="ID");
    disconnect: BoolProperty(default=False);
    
    def draw(self, context):
        if (self.disconnect == False): self.layout.prop(self, "id");
        else: self.layout.label(text="Are you sure you want to disconnect?");
        
    def invoke(self, context, _event):
        self.id = ""; wm = context.window_manager;
        return wm.invoke_props_dialog(self, width=200);
        
    def execute(self, context):
        if (self.disconnect == False):
            context.active_pose_bone["gpencil_library"] = [self.id];
            gpencil_update_library(context.scene);
        else:
            if ("gpencil_library" in context.active_pose_bone):
                del context.active_pose_bone["gpencil_library"];
            gpencil_update_library(context.scene);
        return {'FINISHED'};

class M7A_GPENCIL_LIBRARY_edit_element (Operator):
    bl_idname      = "gpencil.edit_element";
    bl_label       = "Edit GPencil";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Edit gpencil stroke";
    
    def execute(self, context):
        if ("gpencil_library" in context.active_pose_bone):
            a_obj = context.active_object;
            name = context.active_pose_bone["gpencil_library"];
            lc_obj = bpy.data.objects[name[0]];
            
            bpy.ops.object.mode_set(mode='OBJECT', toggle=False);
            bpy.ops.object.select_all(action='DESELECT');
            
            lc_obj.select_set(True);
            bpy.context.view_layer.objects.active = lc_obj;
            
            if ('m7a_gpencil_library' in lc_obj.data):
                lc_obj.data['m7a_gpencil_library']["active_bone"] = a_obj.name;
            
            bpy.ops.object.mode_set(mode='PAINT_GPENCIL', toggle=False);
            
        return {'FINISHED'};

class M7A_GPENCIL_LIBRARY_go_to_bone (Operator):
    bl_idname      = "gpencil.library_go_to_bone";
    bl_label       = "Edit GPencil";
    bl_options     = {'REGISTER', 'UNDO'};
    bl_description = "Edit gpencil stroke";
    
    def execute(self, context):
        a_obj = context.active_object;
        if ("m7a_gpencil_library" in a_obj.data):
            if ("active_bone" in a_obj.data['m7a_gpencil_library']):
                obj_name = a_obj.data['m7a_gpencil_library']["active_bone"];
                
                bpy.ops.object.mode_set(mode='OBJECT', toggle=False);
                bpy.ops.object.select_all(action='DESELECT');
                
                if (obj_name in bpy.data.objects):
                    bpy.data.objects[obj_name].select_set(True);
                    bpy.context.view_layer.objects.active = bpy.data.objects[obj_name];
                    
                    bpy.ops.object.mode_set(mode='POSE', toggle=False);
                else: del a_obj.data['m7a_gpencil_library']["active_bone"];
            
        return {'FINISHED'};

@persistent
def gpencil_update_library(scene):
    a_obj = bpy.context.active_object; lc_obj = None; m7a_list = [];
    bpy.context.scene.gpencil_list_library.clear();
    if (a_obj):
        if (a_obj.type == "ARMATURE"):
            if (bpy.context.mode in {'POSE'}):
                if ("gpencil_library" in bpy.context.active_pose_bone):
                    name = bpy.context.active_pose_bone["gpencil_library"];
                    lc_obj = bpy.data.objects[name[0]];
                    
        elif (a_obj.type == "GPENCIL"): lc_obj = a_obj;
            
        if (lc_obj != None) and ('m7a_gpencil_library' in lc_obj.data):
            for name in lc_obj.data['m7a_gpencil_library']["list"].keys():
                m7a_list.append(name);
            m7a_list.sort();
            for name in m7a_list:
                item = bpy.context.scene.gpencil_list_library.add();
                item.name = name;
            lc_obj.data['m7a_gpencil_list'] = m7a_list;

classes = [
    M7A_GPENCIL_LIBRARY_new, 
    M7A_GPENCIL_LIBRARY_remove,
    M7A_GPENCIL_LIBRARY_item_add,
    M7A_GPENCIL_LIBRARY_item_remove,
    M7A_GPENCIL_LIBRARY_item_load,
    M7A_GPENCIL_LIBRARY_copy_id,
    M7A_GPENCIL_LIBRARY_link,
    M7A_GPENCIL_LIBRARY_edit_element,
    M7A_GPENCIL_LIBRARY_go_to_bone,
    M7A_GPENCIL_UL_list,
];

def register():
    q_register_class(classes);
    
    Scene.gpencil_show_library = BoolProperty(name="Show GPencil Library");
    Scene.gpencil_show_poses   = BoolProperty(name="Show GPose Library");
    Scene.gpencil_list_library = CollectionProperty(type=m7a_props.M7A_GPENCIL_list);
    Scene.gpencil_item_library = IntProperty();
    
    bpy.app.handlers.load_post.append(gpencil_update_library);
    bpy.app.handlers.depsgraph_update_pre.append(gpencil_update_library);
    
def unregister():
    q_unregister_class(classes);
    
    r_remove_attr(Scene, "gpencil_show_library");
    r_remove_attr(Scene, "gpencil_show_poses");
    r_remove_attr(Scene, "gpencil_list_library");
    r_remove_attr(Scene, "gpencil_item_library");
    
